package system;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestSemicolonOperation {
	//echo 'testing: `echo test`;'; echo b
	//echo "testing: `echo test`;"; echo b
	//echo a ; echo 'asd;zxc|wtf'
	//echo a ; echo "asd;zxc|wtf"
	
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
