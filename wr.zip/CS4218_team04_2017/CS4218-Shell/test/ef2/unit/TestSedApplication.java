package ef2.unit;

import static org.junit.Assert.*;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.CdException;
import sg.edu.nus.comp.cs4218.exception.SedException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;
import sg.edu.nus.comp.cs4218.impl.app.CatApplication;
import sg.edu.nus.comp.cs4218.impl.app.SedApplication;

//Use Java properties "file.separator" and "path.separator" when working with file system. 
//Use �line.separator� property when working with newlines.

public class TestSedApplication {
    static SedApplication sedApp;
    final File homeDirectory = new File(System.getProperty("user.dir"));
    final String strHomeDirectory = System.getProperty("user.home");
    static ByteArrayInputStream testIn;
    static ByteArrayOutputStream testOut;

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Before
    public void setUp() throws Exception {
        sedApp = new SedApplication();
    }
    @BeforeClass
    public static void setUpOnce() {
        sedApp = new SedApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }
    @Test
    public void testSedRegenFirstTurnCaps() throws Exception {//[sed s/t/T/ test1.txt][first t turn T]
    	String fileName = "hotandsexy.txt";
    	String arg = "s/t/T/";
    	String[] txtFileLines = {"tree trunk to the temple that time"};
    	createTxtFile(fileName,txtFileLines);//createTxtFile(fileName,content[])
    	String[] inputArray = {arg,fileName};
        String expectedOutput = "Tree trunk to the temple that time"+ System.getProperty("line.separator");
        sedApp.run(inputArray, null, testOut);
        assertEquals( expectedOutput, testOut.toString());
        resetAndDeleteFile(fileName);
    }
    @Test
    public void testSedRegenAllTurnCaps() throws Exception {//[sed s/t/T/g test1.txt][all t turn T]
    	String fileName = "hotandsexy.txt";
    	String arg = "s/t/T/g";
    	String[] txtFileLines = {"tree trunk to the temple that time"};
    	createTxtFile(fileName,txtFileLines);//createTxtFile(fileName,content[])
    	String[] inputArray = {arg,fileName};
        String expectedOutput = "Tree Trunk To The Temple ThaT Time"+ System.getProperty("line.separator");
        sedApp.run(inputArray, null, testOut);
        assertEquals( expectedOutput, testOut.toString());
        resetAndDeleteFile(fileName);
    }
    @Test
    public void testSedRegenFirstTurnNothing() throws Exception {//[sed s/t// test1.txt][first t turn nothing]
    	String fileName = "hotandsexy.txt";
    	String arg = "s/t//";
    	String[] txtFileLines = {"tree trunk to the temple that time"};
    	createTxtFile(fileName,txtFileLines);//createTxtFile(fileName,content[])
    	String[] inputArray = {arg,fileName};
        String expectedOutput = "ree trunk to the temple that time"+ System.getProperty("line.separator");
        sedApp.run(inputArray, null, testOut);
        assertEquals( expectedOutput, testOut.toString());
        resetAndDeleteFile(fileName);
    }
    @Test
    public void testSedRegenAllTurnNothing() throws Exception {//[sed s/t//g test1.txt][all t turn nothing]
    	String fileName = "hotandsexy.txt";
    	String arg = "s/t//g";
    	String[] txtFileLines = {"tree trunk to the temple that time"};
    	createTxtFile(fileName,txtFileLines);//createTxtFile(fileName,content[])
    	String[] inputArray = {arg,fileName};
        String expectedOutput = "ree runk o he emple ha ime"+ System.getProperty("line.separator");
        sedApp.run(inputArray, null, testOut);
        assertEquals( expectedOutput, testOut.toString());
        resetAndDeleteFile(fileName);
    }
    @Test
    public void testSedFileNameWithSpace() throws Exception {
    	String newFileName = "hot chick"+".txt";
    	String arg = "s/t/T/";
    	String[] txtFileLines = {"tree trunk to the temple that time"};
    	createTxtFile(newFileName,txtFileLines);//createTxtFile(fileName,content[])
    	String[] inputArray = {arg,newFileName};
        String expectedOutput = "Tree trunk to the temple that time"+ System.getProperty("line.separator");
        sedApp.run(inputArray, null, testOut);
        assertEquals( expectedOutput, testOut.toString());
        resetAndDeleteFile(newFileName);

    }
	private void createTxtFile(String fileName, String[] txtFileLines) throws UnsupportedEncodingException, FileNotFoundException, IOException {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(
	         	new FileOutputStream(fileName), "utf-8"))) {
				for(int x=0; x < txtFileLines.length ;x++)
				{
					writer.write(txtFileLines[x]);
			        writer.write(System.lineSeparator());
				}
	        }
	}
	
	private void resetAndDeleteFile(String currFileName) {
		sedApp = new SedApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
		try {
			Path oldPath = FileSystems.getDefault().getPath(Environment.currentDirectory, currFileName);
            Files.deleteIfExists(oldPath);
        } catch (Exception e) {
            e.printStackTrace();
        }	
	}
}
