package ef2.unit;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.CdException;
import sg.edu.nus.comp.cs4218.impl.app.CdApplication;

public class TestCdApplication {
	
	//Use Java properties "file.separator" and "path.separator" when working with file system. 
	//Use �line.separator� property when working with newlines.
	
    private static CdApplication cdApp;
    private String[] fileNames = { "File1", "File2", "File3", "File4", "File5" };
    private ArrayList<Path> listOfFiles;

    final File homeDirectory = new File(System.getProperty("user.dir"));
    //final String strHomeDirectory = System.getProperty("user.dir");
    final String strHomeDirectory = System.getProperty("user.home");

    final File parentOfHomeDirectory = new File(homeDirectory.getParent());

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Before
    public void setUp() throws Exception {

        listOfFiles = new ArrayList<Path>();
        for (int x = 0; x < fileNames.length; x++) {
            Path path = Paths.get(fileNames[x]);
            Files.createDirectories(path);
            listOfFiles.add(path);
        }

        cdApp = new CdApplication();
    }

    @After
    public void after() throws Exception {

        for (int x = 0; x < listOfFiles.size(); x++) {
            Files.deleteIfExists(listOfFiles.get(x));
        }
    }

    @Test
    public void testCdToIncorrectFile() throws CdException, IOException {

        String[] inputArray = { "IncorrectFileName" };
        expectedEx.expect(CdException.class);
        expectedEx.expectMessage("The system cannot find the path specified. File Doesn't Exist.");
        cdApp.run(inputArray, null, null);
        Environment.currentDirectory = System.getProperty("user.dir");

    }

    @Test
    public void testCdToFile1() throws CdException, IOException {
        String[] inputArray = { fileNames[0] };
        cdApp.run(inputArray, null, null);

        File currDirectory = new File(Environment.currentDirectory);
        File expDirectory = new File(homeDirectory + File.separator + fileNames[0]);

        assertEquals(currDirectory, expDirectory);

        Environment.currentDirectory = System.getProperty("user.dir");
    }

    @Test
    public void testcdToParent1() throws CdException {

        String[] inputArray = { "../" };
        cdApp.run(inputArray, null, null);

        File currDirectory = new File(Environment.currentDirectory);
        File expDirectory = parentOfHomeDirectory;

        assertEquals(currDirectory, expDirectory);

        Environment.currentDirectory = System.getProperty("user.dir");
    }

    @Test
    public void testcdToParent2() throws CdException {

        String[] inputArray = { ".." };
        cdApp.run(inputArray, null, null);

        File currDirectory = new File(Environment.currentDirectory);
        File expDirectory = parentOfHomeDirectory;

        assertEquals(currDirectory, expDirectory);

        Environment.currentDirectory = System.getProperty("user.dir");
    }

    @Test
    public void testCdFullFormatDirectoryToFile1() throws CdException {
        String[] inputArray = { Environment.currentDirectory + File.separator  + fileNames[0] };
        cdApp.run(inputArray, null, null);

        File currDirectory = new File(Environment.currentDirectory);
        File expDirectory = new File(homeDirectory + File.separator  + fileNames[0]);

        assertEquals(currDirectory, expDirectory);

        Environment.currentDirectory = System.getProperty("user.dir");
    }

    @Test
    public void testCdToFile1ToExitToFile2() throws CdException {

        String[] inputArray = { Environment.currentDirectory + File.separator  + fileNames[0] + File.separator  + "../" };
        cdApp.run(inputArray, null, null);

        File currDirectory = new File(Environment.currentDirectory);
        File expDirectory = homeDirectory;

        assertEquals(currDirectory, expDirectory);

        Environment.currentDirectory = System.getProperty("user.dir");
    }
    
    @Test
    public void testCdWithMultipleFileSeparator() throws CdException {

        String[] inputArray = { Environment.currentDirectory + File.separator  +File.separator  +File.separator  +File.separator  + fileNames[0] + File.separator  + "../" };
        cdApp.run(inputArray, null, null);

        File currDirectory = new File(Environment.currentDirectory);
        File expDirectory = homeDirectory;

        assertEquals(currDirectory, expDirectory);

        Environment.currentDirectory = System.getProperty("user.dir");
    }
    
    @Test
    public void testCdWithApproxSymbol() throws CdException {

        String[] inputArray = {"~"};
        cdApp.run(inputArray, null, null);
        
		String userHome = System.getProperty("user.home");

        File currDirectory = new File(Environment.currentDirectory);
        File expDirectory = new File(userHome);

		
        assertEquals(currDirectory, expDirectory);

        Environment.currentDirectory = System.getProperty("user.dir");
    }
    @Test
    public void testCdWithFileSeparatorToRoot() throws CdException {
       
    	String rootDirectory = File.listRoots()[0].getAbsolutePath().toString();
        String[] inputArray = {File.separator + rootDirectory};
        cdApp.run(inputArray, null, null);
        
		File newFile = new File(rootDirectory);

        File currDirectory = new File(Environment.currentDirectory);
        File expDirectory = newFile;

		
        assertEquals(currDirectory, expDirectory);

        Environment.currentDirectory = System.getProperty("user.dir");
    }
    @Test
    public void testCdWithFileSeparator() throws CdException {
       
    	String rootDirectory = File.listRoots()[0].getAbsolutePath().toString();
        String[] inputArray = {File.separator + rootDirectory};
        cdApp.run(inputArray, null, null);
        
        File currDirectory = new File(Environment.currentDirectory);
        File expDirectory = new File(rootDirectory);

        assertEquals(currDirectory, expDirectory);

        Environment.currentDirectory = System.getProperty("user.dir");
    }

}
