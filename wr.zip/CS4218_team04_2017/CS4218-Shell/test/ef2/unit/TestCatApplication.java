package ef2.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFileAttributes;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sg.edu.nus.comp.cs4218.exception.CatException;
import sg.edu.nus.comp.cs4218.impl.app.CatApplication;

public class TestCatApplication {
    static CatApplication catApp;
    static ByteArrayInputStream testIn;
    static ByteArrayOutputStream testOut;
    static String NL = System.getProperty("line.separator");
    
    static int n = 2; //Any n >= 2: Create n files for testing purposes.
    
    @Test
    public void testCatAllArgsNull() {
        try {
            catApp.run(null, null, null);
            fail();
        } catch (CatException e) {
            assertEquals("cat: Null Pointer Exception", e.getMessage());
        }
    }
    
    @Test
    public void testCatArgsNullOrEmpty() {
        String input = "some text" + NL;
        testIn = new ByteArrayInputStream(input.getBytes());
        
        try {
            catApp.run(null, testIn, testOut);
            assertEquals("some text" + NL, testOut.toString());
            
            catApp.run(new String[] {}, testIn, testOut);
            assertEquals("some text" + NL, testOut.toString());
        } catch (CatException e) {
            e.printStackTrace();
        }
    }
    
    
    @Test
    public void testCatArgsAndStdOutNull() {
        String input = "some text" + NL;
        testIn = new ByteArrayInputStream(input.getBytes());
        
        try {
            catApp.run(null, testIn, null);
            fail();
        } catch (CatException e) {
            assertEquals("cat: Null Pointer Exception", e.getMessage());
        }
    }
    
    @Test
    public void testCatArgsAndStdInNull() {
        try {
            catApp.run(null, null, testOut);
            fail();
        } catch (CatException e) {
            assertEquals("cat: Null Pointer Exception", e.getMessage());
        }
    }
    
    @Test
    public void testCatSingleArgValid() {
        try {
            catApp.run(new String[] { "test1.txt" }, null, testOut);
            assertEquals("test1" + NL + "test1", testOut.toString());
        } catch (CatException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testCatSingleArgWithSpaceValid() {
        try {
            catApp.run(new String[] { "\"test test.txt\"" }, null, testOut);
            assertEquals("test test" + NL, testOut.toString());
        } catch (CatException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testCatSingleArgInvalid() {
        try {
            catApp.run(new String[] { "|\'\"" }, null, testOut);
            fail();
        } catch (CatException e) {
            assertEquals("cat: Invalid file path", e.getMessage());
        }
    }
    
    @Test
    public void testCatSingleArgWithInvalidSyntax() {
        try {
            catApp.run(new String[] { "\"test test\".txt" }, null, testOut);
            fail();
        } catch (CatException e) {
            assertEquals("cat: Invalid file path", e.getMessage());
        }
    }
    
    @Test
    public void testCatSingleArgUnreadable() {
        try {
            catApp.run(new String[] { "unreadable.txt" }, null, testOut);
            fail();
        } catch (CatException e) {
            assertEquals("cat: Could not read file", e.getMessage());
        }
    }
    
    @Test
    public void testCatSingleArgInvalidDir() {
        try {
            catApp.run(new String[] { File.separator }, null, testOut);
            fail();
        } catch (CatException e) {
            assertEquals("cat: This is a directory", e.getMessage());
        }
    }
    
    @Test
    public void testCatSingleArgSpaces() {
        try {
            catApp.run(new String[] { "   " }, null, testOut);
            fail();
        } catch (CatException e) {
            assertEquals("cat: Invalid file path", e.getMessage());
        }
    }
    
    @Test
    public void testCatMultipleArgsValid() {
        try {
            catApp.run(new String[] { "test1.txt", "test2.txt" }, null, testOut);
            assertEquals("test1" + NL + "test1test2" + NL + "test2", testOut.toString());
        } catch (CatException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testCatMultipleArgsMultipleWordsSingleQuoted() {
        try {
            catApp.run(new String[] { "\'test test.txt\'", "\'test test.txt\'" }, null, testOut);
            assertEquals("test test" + NL + "test test" + NL, testOut.toString());
        } catch (CatException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testCatMultipleArgsMultipleWordsDoubleQuoted() {
        try {
            catApp.run(new String[] { "\"test test.txt\"", "\"test test.txt\"" }, null, testOut);
            assertEquals("test test" + NL + "test test" + NL, testOut.toString());
        } catch (CatException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testCatMultipleArgsInvalid() {
        try {
            catApp.run(new String[] { "|", "|" }, null, testOut);
            fail();
        } catch (CatException e) {
            assertEquals("cat: Invalid file path", e.getMessage());
        }
    }
    
    @Test
    public void testCatMultipleArgsValidAndInvalid() {
        try {
            catApp.run(new String[] { "test1.txt", "|" }, null, testOut);
            fail();
        } catch (CatException e) {
            assertEquals("cat: Invalid file path", e.getMessage());
        }
    }
    
    @BeforeClass
    public static void setUpOnce() {
        catApp = new CatApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
        
        createFiles(n);
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
        deleteFiles();
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        if (testIn != null) {
            testIn.reset();
        }
        testOut.reset();
    }
    
    private static void createFiles(int n) {
        //Create n files for testing
        for (int i = 1; i <= n; i++) {
            try {
                PrintWriter writer = new PrintWriter("test" + i + ".txt");  // File contents:
                writer.println("test" + i);                                 // test 1 (new line)
                writer.print("test" + i);                                   // test 1 (No new line)
                writer.close();
            } catch (IOException ioe) {
               try {
                   File file = new File("test" + i + ".txt");
                   file.delete();
               } catch (Exception e) {
                   e.printStackTrace();
               }
            }
        }
        
        //Create file with space in name
        try {
            PrintWriter writer = new PrintWriter("test test.txt");  // File contents:
            writer.println("test test");                            // test test
            writer.close();
        } catch (IOException ioe) {
            try {
                File file = new File("test test.txt");
                file.delete();
            } catch (Exception e) {
                e.printStackTrace();
            }
         }
        
        //Create an unreadable text file
        try {
            PrintWriter writer = new PrintWriter("unreadable.txt");  
            writer.println("unreadable text");                                                             
            writer.close();
            
            Path path = Paths.get("unreadable.txt");
            PosixFileAttributeView view = Files.getFileAttributeView(path, PosixFileAttributeView.class);

            PosixFileAttributes attributes = view.readAttributes();
            Set<PosixFilePermission> permissions = attributes.permissions();
            permissions.remove(PosixFilePermission.OWNER_READ);
            view.setPermissions(permissions);
        } catch (Exception ioe) {
           try {
               File file = new File("unreadable.txt");
               file.delete();
           } catch (Exception e) {
               e.printStackTrace();
           }
        }
    }
    
    private static void deleteFiles() {
        //Delete n files that were created for testing
        for (int i = 1; i <= n; i++) {
            try {
                File file = new File("test" + i + ".txt");
                file.delete();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        //Delete test file with space in name
        try {
            File file = new File("test test.txt");
            file.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        //Delete unreadable file
        try {
            File file = new File("unreadable.txt");
            file.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
