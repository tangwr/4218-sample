package ef2.unit;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.PwdException;
import sg.edu.nus.comp.cs4218.impl.app.PwdApplication;

public class TestPwdApplication {
    static PwdApplication pwdApp;
    static ByteArrayOutputStream testOut;
    static String NL = System.getProperty("line.separator");

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Test
    public void testPwdWithEmptyArg() throws PwdException {
        pwdApp.run(new String[] {}, null, testOut);
        assertEquals(Environment.currentDirectory + NL, testOut.toString());
    }

    @BeforeClass
    public static void setUpOnce() {
        pwdApp = new PwdApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }

    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
        testOut.reset();
    }
}
