package ef2.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sg.edu.nus.comp.cs4218.exception.EchoException;
import sg.edu.nus.comp.cs4218.impl.app.EchoApplication;

public class TestEchoApplication {
    static EchoApplication echoApp;
    static ByteArrayOutputStream testOut;
    static String NL = System.getProperty("line.separator");
    
    @Test
    public void testEchoAllArgsNull() {
        try {
            echoApp.run(null, null, null);
            fail();
        } catch (EchoException e) {
            assertEquals("echo: Null arguments", e.getMessage());
        }
    }
    
    @Test
    public void testEchoStdOutNull() {
        try {
            echoApp.run(new String[] { "some text" }, null, null);
            fail();
        } catch (EchoException e) {
            assertEquals("echo: OutputStream not provided", e.getMessage());
        }
    }
    
    @Test
    public void testEchoArgLengthZero() {
        try {
            echoApp.run(new String[] { "" }, null, testOut);
            assertEquals(NL, testOut.toString());
        } catch (EchoException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoSingleArgSingleWord() {
        try {
            echoApp.run(new String[] { "test" }, null, testOut);
            assertEquals("test" + NL, testOut.toString());
        } catch (EchoException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoSingleArgMultipleWords() {
        try {
            echoApp.run(new String[] { "some text" }, null, testOut);
            assertEquals("some text" + NL, testOut.toString());
        } catch (EchoException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoMultipleArgsSingleWord() {
        try {
            echoApp.run(new String[] { "some", "text" }, null, testOut);
            assertEquals("some text" + NL, testOut.toString());
        } catch (EchoException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoMultipleArgsMultipleWords() {
        try {
            echoApp.run(new String[] { "a b", "c d" }, null, testOut);
            assertEquals("a b c d" + NL, testOut.toString());
        } catch (EchoException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoMultipleArgsMultipleWordsSingleQuoted() {
        try {
            echoApp.run(new String[] { "\'a b\'", "\'c d\'" }, null, testOut);
            assertEquals("a b c d" + NL, testOut.toString());
        } catch (EchoException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoMultipleArgsMultipleWordsDoubleQuoted() {
        try {
            echoApp.run(new String[] { "\"a b\"", "\"c d\"" }, null, testOut);
            assertEquals("a b c d" + NL, testOut.toString());
        } catch (EchoException e) {
            e.printStackTrace();
        }
    }
    
    @BeforeClass
    public static void setUpOnce() {
        echoApp = new EchoApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        testOut.reset();
    }
}
