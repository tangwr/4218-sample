/**
 * 
 */
package ef2.unit;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;

import sg.edu.nus.comp.cs4218.exception.HeadException;
import sg.edu.nus.comp.cs4218.impl.app.HeadApplication;

/**
 * @author pixelducky
 *
 */
public class TestHeadApplication {
	private static HeadApplication headApp;
	private static PrintStream stdout;
	private static ByteArrayInputStream stdin;
	private static ByteArrayOutputStream baos;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpOnce() throws Exception {
		headApp = new HeadApplication();
		baos = new ByteArrayOutputStream();
		stdout = new PrintStream(baos, true);
		System.setIn(stdin);
		System.setOut(stdout);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownOnce() throws Exception {
		System.setOut(null);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testHeadNullArguments() {
		try {
			headApp.run(null, null, null);
			fail();
		} catch (HeadException e) {
			assertEquals("head: null arguments", e.getMessage());
		}
	}

	// TODO
	@Test
	public void testHeadDefaultLineCountsWithoutFile() {
		String input;
		byte[] inputBytes;

		try {
			headApp.run(new String[] {}, stdin, stdout);
			fail();
		} catch (HeadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// TODO
	@Test
	public void testHeadSpecifiedLineCountsWithoutFile() {
		fail();
	}

	// TODO
	@Test
	public void testHeadIllegalLineCountsWithoutFile() {
		fail();
	}

	// TODO
	@Test
	public void testHeadDefaultLineCountsWithFile() {
		String input;
		byte[] inputBytes;

		try {
			headApp.run(new String[] {}, stdin, stdout);
			fail();
		} catch (HeadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// TODO
	@Test
	public void testHeadSpecifiedLineCountsWithFile() {
		fail();
	}

	// TODO
	@Test
	public void testHeadIllegalLineCountsWithFile() {
		fail();
	}

	// TODO
	@Test
	public void testHeadSpecifiedLineCountsWithInvalidFile() {
		fail();
	}

}
