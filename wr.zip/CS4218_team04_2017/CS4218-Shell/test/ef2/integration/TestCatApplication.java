package ef2.integration;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestCatApplication {
    static ShellImpl shell;
    static ByteArrayOutputStream testOut;
    static String NL = System.getProperty("line.separator");
    
    static int n = 2; //Any n >= 2: Create n files for testing purposes.
    
    @Test
    public void testCatNoArg() {
        try {
            shell.parseAndEvaluate("cat", testOut);
            fail();
        } catch (ShellException e) {
            e.printStackTrace();
        } catch (AbstractApplicationException e) {
            assertEquals("cat: Null Pointer Exception", e.getMessage());
        }
    }
    
    @Test
    public void testCatNoArgWithSpaces() {
        try {
            shell.parseAndEvaluate("cat   ", testOut);
            fail();
        } catch (ShellException e) {
            e.printStackTrace();
        } catch (AbstractApplicationException e) {
            assertEquals("cat: Null Pointer Exception", e.getMessage());
        }
    }
    
    @Test
    public void testCatSingleArgValid() {
        try {
            shell.parseAndEvaluate("cat test1.txt", testOut);
            assertEquals("test1" + NL + "test1", testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testCatSingleArgInValid() {
        try {
            shell.parseAndEvaluate("cat ^", testOut);
            fail();
        } catch (ShellException e) {
            e.printStackTrace();
        } catch (AbstractApplicationException e) {
            assertEquals("cat: Could not read file", e.getMessage());
        }
    }
    
    @Test
    public void testCatMultipleArgsValid() {
        try {
            shell.parseAndEvaluate("cat test1.txt test2.txt", testOut);
            assertEquals("test1" + NL + "test1test2" + NL + "test2", testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testCatMultipleArgsInvalid() {
        try {
            shell.parseAndEvaluate("cat test1.txt ^", testOut);
            fail();
        } catch (ShellException e) {
            e.printStackTrace();
        } catch (AbstractApplicationException e) {
            assertEquals("cat: Could not read file", e.getMessage());
        }
    }
    
    @Test
    public void testCatWithCommandSubstitution() {
        try {
            shell.parseAndEvaluate("cat `echo test1.txt` test2.txt", testOut);
            assertEquals("test1" + NL + "test1test2" + NL + "test2", testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @BeforeClass
    public static void setUpOnce() {
        shell = new ShellImpl();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
        createFiles(n);
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
        deleteFiles();
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        testOut.reset();
    }
    
    private static void createFiles(int n) {
        //Create n files for testing
        for (int i = 1; i <= n; i++) {
            try {
                PrintWriter writer = new PrintWriter("test" + i + ".txt");  // File contents:
                writer.println("test" + i);                                 // test 1 (new line)
                writer.print("test" + i);                                   // test 1 (No new line)
                writer.close();
            } catch (IOException ioe) {
               try {
                   File file = new File("test" + i + ".txt");
                   file.delete();
               } catch (Exception e) {
                   e.printStackTrace();
               }
            }
        }
    }
    
    private static void deleteFiles() {
        //Delete n files that were created for testing
        for (int i = 1; i <= n; i++) {
            try {
                File file = new File("test" + i + ".txt");
                file.delete();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
