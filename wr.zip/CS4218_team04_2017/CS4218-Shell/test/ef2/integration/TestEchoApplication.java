package ef2.integration;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestEchoApplication {
    static ShellImpl shell;
    static ByteArrayOutputStream testOut;
    static String NL = System.getProperty("line.separator");
    
    @Test
    public void testEchoNoArg() {
        try {
            shell.parseAndEvaluate("echo", testOut);
            assertEquals(NL + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoNoArgWithSpaces() {
        try {
            shell.parseAndEvaluate("echo   ", testOut);
            assertEquals(NL + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoSingleArgUnquoted() {
        try {
            shell.parseAndEvaluate("echo test", testOut);
            assertEquals("test" + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoSingleArgSingleQuoted() {
        try {
            shell.parseAndEvaluate("echo \'some text\'", testOut);
            assertEquals("some text" + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoSingleArgDoubleQuoted() {
        try {
            shell.parseAndEvaluate("echo \"some text\"", testOut);
            assertEquals("some text" + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoMultipleArgsUnquoted() {
        try {
            shell.parseAndEvaluate("echo some text", testOut);
            assertEquals("some text" + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoMultipleArgsSingleQuoted() {
        try {
            shell.parseAndEvaluate("echo \'some text\' \'more text\'", testOut);
            assertEquals("some text more text" + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoMultipleArgsDoubleQuoted() {
        try {
            shell.parseAndEvaluate("echo \"some text\" \"more text\"", testOut);
            assertEquals("some text more text" + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoWithCommandSubstitutionSingleQuoted() {
        try {
            shell.parseAndEvaluate("echo 'this is space `echo \"nbsp\"` and `echo \"2nd space\"`'", testOut);
            assertEquals("this is space `echo \"nbsp\"` and `echo \"2nd space\"`" + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testEchoWithCommandSubstitutionDoubleQuoted() {
        try {
            shell.parseAndEvaluate("echo \"this is space `echo \"nbsp\"` and `echo \"2nd space\"`\"", testOut);
            assertEquals("this is space nbsp and 2nd space" + NL, testOut.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @BeforeClass
    public static void setUpOnce() {
        shell = new ShellImpl();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        testOut.reset();
    }
}
