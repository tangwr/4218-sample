/**
 * 
 */
package sg.edu.nus.comp.cs4218.impl.app;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Paths;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.TailException;

/**
 * @author somebody
 *
 */
public class TailApplication implements Application {
	private static final String CHAR_WHITESPACE = " ";
	private static final String CHAR_PIPE = "|";
	private static final String STRING_SEPARATOR = CHAR_WHITESPACE + CHAR_PIPE + CHAR_WHITESPACE;
	private static final String NEWLINE = System.getProperty("line.separator");

	private static final int NO_ARGUMENTS_SPECIFIED = 0;
	private static final int ONE_ARGUMENT_SPECIFIED = 1;
	private static final int TWO_ARGUMENT_SPECIFIED = 2;
	private static final int THREE_ARGUMENT_SPECIFIED = 3;
	private static final int DEFAULT_LINE_COUNT = 10;

	private static final String ERROR_NULL_ARGS = "null arguments";
	private static final String ERROR_NULL_STDIN = "stdin is null";
	private static final String ERROR_NULL_STDOUT = "stdout is null";
	private static final String ERROR_NULL_ALL = ERROR_NULL_ARGS + STRING_SEPARATOR + ERROR_NULL_STDIN
			+ STRING_SEPARATOR + ERROR_NULL_STDOUT;
	private static final String ERROR_ILLEGAL_OFFSET = "illegal offset -- %s";
	private static final String ERROR_READING = "Error reading %s";
	private static final String ERROR_PERMISSION_DENIED = "%s: Permission denied";
	private static final String ERROR_INVALID_FILE_OR_DIR = "%s: No such file or directory";
	private static final String ERROR_INVALID_COMMAND_FORMAT = "invalid command format";
	private static final String ERROR_USAGE = "usage: tail [-n lines] [file]";

	public TailApplication() {

	}

	/**
	 * Runs the head application with the specified arguments.
	 * 
	 * @param args
	 *            Array of arguments for the application. Each array element is
	 *            the path to a file. If no files are specified stdin is used.
	 * @param stdin
	 *            An InputStream. The input for the command is read from this
	 *            InputStream if no files are specified.
	 * @param stdout
	 *            An OutputStream. The output of the command is written to this
	 *            OutputStream.
	 * 
	 * @throws TailException
	 *             If the file(s) specified do not exist or are unreadable.
	 * @throws AbstractApplicationException
	 */
	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws TailException {

		if (hasNullInputs(args, stdin, stdout)) {
			throw new TailException(ERROR_NULL_ALL);
		}

		if (args.length == NO_ARGUMENTS_SPECIFIED) {
			try {
				readFromStdin(stdin, stdout, DEFAULT_LINE_COUNT);
			} catch (IOException ioe) {
				throw new TailException("IOException"); // TODO refactor
			} catch (StandardStreamsNotFoundException ssnfe) {
				throw new TailException(ssnfe.getMessage());
			}

			return;
		}

		if (args.length == ONE_ARGUMENT_SPECIFIED) {

			try {
				readFromFile(stdout, DEFAULT_LINE_COUNT, args[0]);
			} catch (IOException ioe) {
				throw new TailException("IOException"); // TODO refactor
			} catch (FileNotExistException fne) {
				throw new TailException(fne.getMessage());
			} catch (FileReadErrorException fre) {
				throw new TailException(fre.getMessage());
			} catch (FilePermissionDeniedException fpd) {
				throw new TailException(fpd.getMessage());
			} catch (StandardStreamsNotFoundException ssnfe) {
				throw new TailException(ssnfe.getMessage());
			}

			return;
		}

		if (args.length == TWO_ARGUMENT_SPECIFIED) {

			try {
				int lineCount = getLineCount(args);
				readFromStdin(stdin, stdout, lineCount);
			} catch (LineCountArgumentNotFoundException lcanfe) {
				throw new TailException(lcanfe.getMessage());
			} catch (NumberFormatException nfe) {
				throw new TailException(String.format(ERROR_ILLEGAL_OFFSET, nfe.getMessage()));
			} catch (IOException e) {
				throw new TailException("IOException"); // TODO refactor
			} catch (StandardStreamsNotFoundException ssnfe) {
				throw new TailException(ssnfe.getMessage());
			}

		} else if (args.length == THREE_ARGUMENT_SPECIFIED) {

			try {
				int lineCount = getLineCount(args);
				String filePath = args[2];
				readFromFile(stdout, lineCount, filePath);
			} catch (LineCountArgumentNotFoundException lcanfe) {
				throw new TailException(lcanfe.getMessage());
			} catch (NumberFormatException nfe) {
				throw new TailException(String.format(ERROR_ILLEGAL_OFFSET, nfe.getMessage()));
			} catch (IOException e) {
				throw new TailException("IOException");
			} catch (FileNotExistException fne) {
				throw new TailException(fne.getMessage());
			} catch (FileReadErrorException fre) {
				throw new TailException(fre.getMessage());
			} catch (FilePermissionDeniedException fpd) {
				throw new TailException(fpd.getMessage());
			} catch (StandardStreamsNotFoundException ssnfe) {
				throw new TailException(ssnfe.getMessage());
			}

		} else if (args.length > THREE_ARGUMENT_SPECIFIED) {
			throw new TailException(ERROR_INVALID_COMMAND_FORMAT + NEWLINE + ERROR_USAGE);
		}

	}

	private boolean hasNullInputs(String[] args, InputStream stdin, OutputStream stdout) {
		return hasNoArguments(args) && hasNoStandardStreams(stdin, stdout);
	}

	private boolean hasNoStandardStreams(InputStream stdin, OutputStream stdout) {
		return stdin == null || stdout == null;
	}

	private boolean hasNoArguments(String[] args) {
		return args == null || args.length == NO_ARGUMENTS_SPECIFIED;
	}

	private boolean fileNotExist(String arg) {
		return Files.notExists(Paths.get(arg));
	}

	private boolean isDirectory(String arg) {
		return Files.isDirectory(Paths.get(arg));
	}

	private boolean fileNotReadable(String arg) {
		return !Files.isReadable(Paths.get(arg));
	}

	// TODO modify to make use of Channels
	private void readFromStdin(InputStream stdin, OutputStream stdout, int lineCount)
			throws StandardStreamsNotFoundException, IOException {

		if (hasNoStandardStreams(stdin, stdout)) {
			throw new StandardStreamsNotFoundException(ERROR_NULL_STDIN + STRING_SEPARATOR + ERROR_NULL_STDOUT);
		}

		// variation from head

		for (int i = 0; i < lineCount; i++) {
			try {
				int intCount;
				while ((intCount = stdin.read()) != -1) {
					stdout.write(intCount);
				}

			} catch (IOException ioe) {
				throw ioe;
			}
		}
	}

	private void readFromFile(OutputStream stdout, int lineCount, String filePath) throws FileNotExistException,
			FileReadErrorException, FilePermissionDeniedException, StandardStreamsNotFoundException, IOException {
		if (fileNotExist(filePath)) {
			throw new FileNotExistException(String.format(ERROR_INVALID_FILE_OR_DIR, filePath));
		}

		if (isDirectory(filePath)) {
			throw new FileReadErrorException(String.format(ERROR_READING, filePath));
		}

		if (fileNotReadable(filePath)) {
			throw new FilePermissionDeniedException(String.format(ERROR_PERMISSION_DENIED, filePath));
		}

		if (stdout == null) {
			throw new StandardStreamsNotFoundException(ERROR_NULL_STDOUT);
		}

		try (RandomAccessFile file = new RandomAccessFile(filePath, "r")) {
			long length = file.length();
			
			long specifiedPosition = length - (lineCount * 3);
			if (specifiedPosition < 0) {
				specifiedPosition = 0;
			}

			file.seek(specifiedPosition);

			String line;
			while ((line = file.readLine()) != null) {
				stdout.write(line.getBytes());
				stdout.write(NEWLINE.getBytes());
			}

		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	}

	private boolean hasLineCountArgument(String[] args) throws NumberFormatException {
		return args[0].equals("-n");
	}

	private int getLineCount(String[] args) throws LineCountArgumentNotFoundException, NumberFormatException {
		if (!hasLineCountArgument(args)) {
			throw new LineCountArgumentNotFoundException(ERROR_INVALID_COMMAND_FORMAT + NEWLINE + ERROR_USAGE);
		}

		try {
			int lineCount = Integer.parseInt(args[1]);
			return lineCount;
		} catch (NumberFormatException nfe) { // error when value <= 0
			throw new NumberFormatException(args[1]);
		}

	}

	class FileNotExistException extends Exception {
		/**
		 * 
		 */
		private static final long serialVersionUID = 3128081714713548969L;

		/**
		 * @param message
		 */
		public FileNotExistException(String message) {
			super(message);
		}

	}

	class FileReadErrorException extends Exception {
		/**
		 * 
		 */
		private static final long serialVersionUID = 5069233516932295482L;

		/**
		 * @param message
		 */
		public FileReadErrorException(String message) {
			super(message);
		}

	}

	class FilePermissionDeniedException extends Exception {
		/**
		 * 
		 */
		private static final long serialVersionUID = -6651052877769570267L;

		/**
		 * @param message
		 */
		public FilePermissionDeniedException(String message) {
			super(message);
		}

	}

	class StandardStreamsNotFoundException extends Exception {

		/**
		 * 
		 */
		private static final long serialVersionUID = 8186393968776118338L;

		/**
		 * @param message
		 */
		public StandardStreamsNotFoundException(String message) {
			super(message);
		}

	}

	class LineCountArgumentNotFoundException extends Exception {

		/**
		 * 
		 */
		private static final long serialVersionUID = -3169422289271681420L;

		/**
		 * @param message
		 */
		public LineCountArgumentNotFoundException(String message) {
			super(message);
		}

	}

}
