/**
 * 
 */
package sg.edu.nus.comp.cs4218.exception;

/**
 * @author pixelducky
 *
 */
public class HeadException extends AbstractApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3608957686975123140L;

	/**
	 * @param message
	 */
	public HeadException(String message) {
		super("head: " + message);
	}

}
