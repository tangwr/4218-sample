package sg.edu.nus.comp.cs4218.impl.app;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.exception.DateException;

public class DateApplication implements Application {
	
	public DateApplication(){}

	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws DateException {
		Calendar cal = Calendar.getInstance();
		String output = "";
		
		try {
			output = cal.getTime().toString() + "\n";
			stdout.write(output.getBytes());
		} catch (IOException e) {
			throw new DateException("IOException");
		}
	}
}
