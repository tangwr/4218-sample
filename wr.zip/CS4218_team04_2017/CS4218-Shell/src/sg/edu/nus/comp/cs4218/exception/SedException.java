package sg.edu.nus.comp.cs4218.exception;

public class SedException extends AbstractApplicationException {

	public SedException(String message) {
		super("cd: " + message);
		// TODO Auto-generated constructor stub
	}
}

	
