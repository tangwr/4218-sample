package sg.edu.nus.comp.cs4218.exception;

public class PwdException extends AbstractApplicationException {
	//private static final long serialVersionUID = 2333796686823942499L;

	public PwdException(String message) {
		super("cd: " + message);
		// TODO Auto-generated constructor stub
	}
}



