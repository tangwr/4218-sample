package sg.edu.nus.comp.cs4218.impl.app;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.CdException;

public class CdApplication implements Application {
	// cd /c/users/chiang-dell/desktop/development/cs4218_team04_2017/cs4218-shell
	public CdApplication() {
	}

	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws CdException {
		
		if(args.length==0)//Example : [cd ]
		{
			returnToHomeDirectory();
		}
		else
		{
			String dirName = args[0];

			if( dirName.substring(0, 1).equals("~"))//Example : [cd ~] [cd ~RUBBISHTEXT]
			{
				returnToHomeDirectory();
			}
			else if (args[0].equals("/")) // Example : [cd /] 
			{
				returnToRootDirectory();
			} 
			else if (dirName.substring(0, 1).equals("/")) // Example : [cd /c/users/] [cd /c/users/chiang-dell/..]
			{
				returnToRootThenOther(dirName);
			} 
			else 
			{
				goToDirectory(dirName); // Example : [cd src] [cd src/BLAH/BLAH/BLAH] [cd ../] [cd ..] [cd "test test"]
			}
		}
		

	}

	private void returnToHomeDirectory() {
		String root = System.getProperty("user.home");
		File newFile = new File(root);
		changeDirectory(newFile);
	}

	private void goToDirectory(String dirName) throws CdException {
		File newFile = new File(dirName);
		if (newFile.isAbsolute() == false) // forcibly making all File to Full dir
		{
			newFile = new File(Environment.currentDirectory, dirName);
		}
		checkFileExistence(newFile);
		checkDirectoryExistence(newFile);
		changeDirectory(newFile);
	}

	private void returnToRootThenOther(String dirName) throws CdException { 
				
		String rootDirName = File.listRoots()[0].getAbsolutePath();
		String[] rootDirNameSplit = rootDirName.split(":");

		String goinDirName = dirName;
		String dropSlashGoingDirName = goinDirName.substring(1);
		String[] goinDirNameSplit = dropSlashGoingDirName.split("/");

		if (rootDirNameSplit[0].toLowerCase().equals(goinDirNameSplit[0].toLowerCase())) 
		{
			String defaultRootName = rootDirName; // -> C:\ <-
			String goHere = defaultRootName;

			for (int x = 1; x < goinDirNameSplit.length ; x++) {
				goHere += goinDirNameSplit[x] +File.separator;
			}
			File newFile = new File(goHere);

			checkFileExistence(newFile);
			checkDirectoryExistence(newFile);
			changeDirectory(newFile);

		}

	}

	private void changeDirectory(File newFile) {
		try {
			Environment.currentDirectory = newFile.getCanonicalPath();
		} catch (IOException e) {
		}
	}

	private void checkFileExistence(File newFile) throws CdException {

		if (newFile.exists() == false) {
			throw new CdException("The system cannot find the path specified. File Doesn't Exist.");
		}

	}

	private void checkDirectoryExistence(File newFile) throws CdException {
		if (newFile.isDirectory() == false) {
			throw new CdException("The system cannot find the path specified. Directory Doesn't Exist.");
		}
	}

	private void returnToRootDirectory() { 
		String root = File.listRoots()[0].getAbsolutePath().toString();
		File newFile = new File(root);
		changeDirectory(newFile);

	}
	public static void MsgLog(File openThisFile) throws IOException {
		System.out.println("Class:CdApplication.java - Method:MsgLog - ROOT: " + File.listRoots()[0].getAbsolutePath().toString());
		System.out.println("Class:CdApplication.java - Method:MsgLog - path: " + openThisFile.getPath());
		System.out.println("Class:CdApplication.java - Method:MsgLog - absolute path: " + openThisFile.getAbsolutePath());
		System.out.println("Class:CdApplication.java - Method:MsgLog - canonical path: " + openThisFile.getCanonicalPath());
		System.out.println("Class:CdApplication.java - Method:MsgLog - user directory: " + System.getProperty("user.dir"));

	}

}
