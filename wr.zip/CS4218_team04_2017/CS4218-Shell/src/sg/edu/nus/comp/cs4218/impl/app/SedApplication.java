package sg.edu.nus.comp.cs4218.impl.app;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.app.Sed;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.CatException;
import sg.edu.nus.comp.cs4218.exception.CdException;
import sg.edu.nus.comp.cs4218.exception.SedException;

public class SedApplication implements Sed{
	// cd /c/users/chiang-dell/desktop/development
	// sed s/t/T/ test1.txt
	String regexp ="";
	String replacement="";
	String allG="";
	File txtFile;
	String[] splittedReplacement;
	OutputStream stdout;
	InputStream stdin;
	public SedApplication(){}
	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws SedException {
		this.stdout = stdout;
		this.stdin = stdin;
		//	cd /c/users/chiang-dell/desktop/development
		// TEST : sed s/t/T test.txt 							[not accepted][supported][need T/ follow bash]
		// TEST : sed s/t/T/ development/test1.txt 				[not accepted][supported][no such dir follow bash]
		// TEST : sed s/t/T/ /development/test1.txt 			[not accepted][supported][no such dir follow bash]
		// TEST : sed s/t/T/ ../development/test1.txt 			[not accepted][from diff directory][supported]
		// TEST : sed s/t/T/g/ test1.txt 						[not accepted][supported][no need /, just g]
		// TEST : sed s/t/ test1.txt 							[not accepted][wrong replacement rule]

		// TEST : sed s/t/T/ ../development/test1.txt 			[accepted][from same directory][supported]
		// TEST : sed s/t/T/ test1.txt 							[accepted][supported][first t turn T]
		// TEST : sed s/t/T/g test1.txt 						[accepted][supported][all t turn T]
		// TEST : sed s/t// test1.txt 							[accepted][supported][first t turn nothing]
		// TEST : sed s/t//g test1.txt 							[accepted][supported][all t turn nothing]

		// TEST : sed s/t/T/ ../development/"test1 test1".txt 	[accepted][not supported][space havent fix]
		// TEST : sed s/t/T/ ../development/"test1 test1.txt" 	[accepted][not supported][space havent fix]
		// TEST : sed s/t/t/ ../development/test1\ test1.txt 	[accepted][not supported][christina say this command invalid]
		
		// TEST : cat test1.txt | sed s/t/T/ "test1 test1".txt 	[accepted][not supported]["test1 test1 will be executed"]
		
		if (args == null || args.length == 0) {
			throw new SedException("Exception Caught");
		}
		else if(args.length==1 && stdin!=null)
		{
			txtFile = checkTextFileExistence(stdin.toString());
			String replacementSyntax = args[0];
			splittedReplacement = checkReplacementSyntax(replacementSyntax);

			if(splittedReplacement.length==2 || splittedReplacement.length==3) //Example : [sed s/t/T/ ../development/test1.txt] [sed s/t/T/ test1.txt]
			{//Example : [sed s/t// test1.txt] 
				//System.out.println("length 2 and 3");
				checkS(splittedReplacement[0]);
				regexp = splittedReplacement[1];
				replacement = correctReplacement(splittedReplacement);
				try {
					Scanner sc = new Scanner(new FileReader(txtFile));
					while(sc.hasNext()){
						String content = replaceFirstSubStringFromStdin(sc.nextLine());
						byte[] byteString  = content.getBytes();
						try {
							stdout.write(byteString);
						} catch (IOException e) {}
						
						//System.out.println(matcher.replaceFirst(replacement));
				    }
					sc.close();
				} catch (FileNotFoundException e) {}
				
			}
			else if(splittedReplacement.length==4) //Example : [sed s/t/T/g test1.txt] [sed s/t//g test1.txt]
			{
				//System.out.println("length 4");
				checkS(splittedReplacement[0]);
				regexp = splittedReplacement[1];
				replacement = splittedReplacement[2];
				allG = splittedReplacement[3];
				if(allG.equals("g"))
				{
					try {
						Scanner sc = new Scanner(new FileReader(txtFile));
						while(sc.hasNext()){
							String content = replaceAllSubstringsInStdin(sc.nextLine());
							byte[] byteString  = content.getBytes();
							try {
								stdout.write(byteString);
							} catch (IOException e) {}
					    }
						sc.close();
					} catch (FileNotFoundException e) {}
				}
				else
				{
					throw new SedException(replaceSubstringWithInvalidReplacement(""));

					//throw new SedException("Incorrect replacement rule, correct example: sed s/t/T/g test1.txt ");
				
				}
			}
			else
			{
				
				throw new SedException(replaceSubstringWithInvalidReplacement(""));

				//throw new SedException("Incorrect replacement rule");
			}
			
		}
		else if(args.length==2)
		{
			String replacementSyntax = args[0];
			String textFile = args[1];
			txtFile = checkTextFileExistence(textFile);
			splittedReplacement = checkReplacementSyntax(replacementSyntax);
						
			if(splittedReplacement.length==2 || splittedReplacement.length==3) //Example : [sed s/t/T/ ../development/test1.txt] [sed s/t/T/ test1.txt]
			{//Example : [sed s/t// test1.txt] 
				//System.out.println("length 2 and 3");
				checkS(splittedReplacement[0]);
				regexp = splittedReplacement[1];
				replacement = correctReplacement(splittedReplacement);
				try {
					Scanner sc = new Scanner(new FileReader(txtFile));
					while(sc.hasNext()){
						String content = replaceFirstSubStringInFile(sc.nextLine());
						byte[] byteString  = content.getBytes();
						try {
							stdout.write(byteString);
						} catch (IOException e) {}
						
						//System.out.println(matcher.replaceFirst(replacement));
				    }
					sc.close();
				} catch (FileNotFoundException e) {}
			}
			else if(splittedReplacement.length==4) //Example : [sed s/t/T/g test1.txt] [sed s/t//g test1.txt]
			{
				//System.out.println("length 4");
				checkS(splittedReplacement[0]);
				regexp = splittedReplacement[1];
				replacement = splittedReplacement[2];
				allG = splittedReplacement[3];
				if(allG.equals("g"))
				{
					try {
						Scanner sc = new Scanner(new FileReader(txtFile));
						while(sc.hasNext()){
							String content = replaceAllSubstringsInFile(sc.nextLine());
							byte[] byteString  = content.getBytes();
							try {
								stdout.write(byteString);
							} catch (IOException e) {}
					    }
						sc.close();
					} catch (FileNotFoundException e) {}
				}
				else
				{
					throw new SedException(replaceSubstringWithInvalidReplacement(""));

					//throw new SedException("Incorrect replacement rule, correct example: sed s/t/T/g test1.txt ");
				}
			}
			else
			{
				throw new SedException(replaceSubstringWithInvalidReplacement(""));

				//throw new SedException("Incorrect replacement rule, correct example: sed s/t/T/g test1.txt ");
			}
			
		}
		else
		{
			throw new SedException("Exception Caught");
		}

	}
	@Override
	public String replaceFirstSubStringInFile(String args) {
		Pattern pattern = Pattern.compile(regexp);
		Matcher matcher = pattern.matcher(args);
		return matcher.replaceFirst(replacement) + System.getProperty("line.separator");
	}
	@Override
	public String replaceAllSubstringsInFile(String args) {
		Pattern pattern = Pattern.compile(regexp);
		Matcher matcher = pattern.matcher(args);
		return matcher.replaceAll(replacement) + System.getProperty("line.separator");
	}
	@Override
	public String replaceFirstSubStringFromStdin(String args) {
		Pattern pattern = Pattern.compile(regexp);
		Matcher matcher = pattern.matcher(args);
		return matcher.replaceFirst(replacement) + System.getProperty("line.separator");
	}
	@Override
	public String replaceAllSubstringsInStdin(String args) {
		Pattern pattern = Pattern.compile(regexp);
		Matcher matcher = pattern.matcher(args);
		return matcher.replaceAll(replacement) + System.getProperty("line.separator");
	}
	@Override
	public String replaceSubstringWithInvalidReplacement(String args) {
		return "Invalid Replacement";

	}
	@Override
	public String replaceSubstringWithInvalidRegex(String args) {
		return "Invalid Regex";
	}
	private String[] checkReplacementSyntax(String replacementSyntax) throws SedException {		
		
		String validSymbol1 = "/";
		String validSymbol2 = "|"; 
		String currSymbol = "";
		currSymbol = extractSymbol(replacementSyntax,validSymbol1,validSymbol2);
		
		String[] splitReplacement = replacementSyntax.split(currSymbol); //split by currSymbol
		//for(int x=0;x<splitReplacement.length;x++){System.out.println(splitReplacement[x]);}
		checkTerminationSymbol(replacementSyntax,currSymbol,splitReplacement);
		return splitReplacement;
		
	}
	private void checkTerminationSymbol(String replacementSyntax,String currSymbol,String[] splitReplacement) throws SedException {
		//cd /c/users/chiang-dell/desktop/development
		//sed s/t/T/g/ test1.txt [unaccepted]
		//sed s/t/ test1.txt [unaccepted]
		
		//sed s/t/T/g test1.txt [accepted]
		//sed s/t/T/ test1.txt [accepted]
		//sed s/t//g test1.txt [accepted]
		//sed s/t// test1.txt [accepted]
		//System.out.println(splitReplacement.length);
		
		if(splitReplacement.length==4)
		{
			if(replacementSyntax.substring(replacementSyntax.length()-1,replacementSyntax.length()).equals(currSymbol))
			{
				throw new SedException(replaceSubstringWithInvalidRegex(""));
				//throw new SedException("Incorrect, last index should not be terminal symbol");
			}
		}
		else if(splitReplacement.length==3)
		{
			if(replacementSyntax.substring(replacementSyntax.length()-1,replacementSyntax.length()).equals(currSymbol)==false)
			{
				throw new SedException(replaceSubstringWithInvalidRegex(""));
				//throw new SedException("Incorrect, last index should be terminal symbol");
			}
		}
		else if(splitReplacement.length==2) //sed s/t// test1.txt [accepted][two cont symbols //]
		{
			String twoContinuousTerminalSymbols = currSymbol+currSymbol;
			if(replacementSyntax.substring(replacementSyntax.length()-2,replacementSyntax.length()).equals(twoContinuousTerminalSymbols)==false)
			{
				throw new SedException(replaceSubstringWithInvalidRegex(""));	
				//throw new SedException("Incorrect, last index should be terminal symbol Example : sed s/t// test1.txt");
			}
		}
		else
		{
			throw new SedException(replaceSubstringWithInvalidRegex(""));
			//throw new SedException("Something is wrong");
		}
	}
	private void checkS(String substring) throws SedException {
		if(substring.equals("s")==false)
		{
			throw new SedException("Incorrect replacement rule, example *s*/t/T");
		}		
	}
	private String extractSymbol(String strSymbol,String validSymbol1,String validSymbol2) throws SedException {
		
		if(strSymbol.length()<2)
		{
			throw new SedException("Incorrect replacement rule, only accept : / or |");
		}
		else
		{
			strSymbol = strSymbol.substring(1, 2);
			if(strSymbol.equals(validSymbol1))
			{
				return validSymbol1;
			}
			else if(strSymbol.equals(validSymbol2))
			{
				return validSymbol2;
			}
			else
			{
				throw new SedException("Incorrect gluing character, should only be / or |");
			}
		}
				
	}
	private File checkTextFileExistence(String fileName) throws SedException {
		//cd /c/users/chiang-dell/desktop/development
		//TEST : sed s/t/T/ ../development/test1.txt [accepted]
		//TEST : sed s/t/T/ ../development/"test1 test1".txt [accepted]
		String[] splitFileNames = fileName.split("/");
		File newFile=null;

		if(splitFileNames.length==1)
		{
			String currDir = Environment.currentDirectory;
			newFile = new File(currDir,splitFileNames[0]);
		}
		else if(splitFileNames.length==3 
				&& splitFileNames[0].equals("..") 
				&& splitFileNames[1].equals(new File(Environment.currentDirectory).getName().toLowerCase()))
		{
			String currDir = Environment.currentDirectory;
			newFile = new File(currDir,splitFileNames[2]);
		}
		else
		{
			throw new SedException("No such file or directory");
		}

		checkFileExistence(newFile);
		return newFile;
	}
	private void checkFileExistence(File newFile) throws SedException {
		if (newFile.exists() == false) {
			throw new SedException("The system cannot find the path specified. File Doesn't Exist.");
		}
	}
	private void print(String arg)
	{
		System.out.println(arg);
	}
	private String correctReplacement(String[] splittedReplacement2) {
		if(splittedReplacement.length==2){return "";}
		else{return splittedReplacement[2];}
	}
	private ArrayList<String> walkThroughReplacement(String replacementSyntax,String currSymbol)
	{
		ArrayList<String> contextList = new ArrayList<String>();
		for(int x=0;x<replacementSyntax.length();x++)
		{
			if(replacementSyntax.substring(x, x+1).equals(currSymbol))
			{
				if(replacementSyntax.substring(0, x).equals(currSymbol))
				{
					contextList.add("");
				}
				else
				{
					contextList.add(replacementSyntax.substring(0, x));
					replacementSyntax = replacementSyntax.substring(x+1,replacementSyntax.length());
					x=0;
				}
				
			}
		}
		
		//System.out.println(contextList);
		return contextList;
	}
}