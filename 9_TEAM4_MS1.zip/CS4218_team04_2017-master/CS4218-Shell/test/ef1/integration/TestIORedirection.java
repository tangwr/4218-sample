package ef1.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestIORedirection {
    static ShellImpl shell;
    static ByteArrayOutputStream testOut;
    static final String NL = System.getProperty("line.separator");
    static final String FS = System.getProperty("file.separator");
    
    static int n = 2; //Any n >= 2: Create n files for testing purposes.
    
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();
    
    @Test
    public void testCatWithValidInputRedirectionUnquoted() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("cat < redirection test" + FS + "test 1.txt", testOut);
        assertEquals("test 1" + NL + "test 1", testOut.toString());
    }
    
    @Test
    public void testCatWithInvalidInputRedirectionSingleQuoted() throws AbstractApplicationException, ShellException {
        expectedEx.expect(ShellException.class);
        expectedEx.expectMessage("Invalid syntax encountered.");
        shell.parseAndEvaluate("cat < 'test 1.txt'", testOut);
    }
    
    @Test
    public void testCatWithInvalidInputRedirectionDoubleQuoted() throws AbstractApplicationException, ShellException {
        expectedEx.expect(ShellException.class);
        expectedEx.expectMessage("Invalid syntax encountered.");
        shell.parseAndEvaluate("cat < \"test 1.txt\"", testOut);
    }
    
    @Test
    public void testCatWithInvalidInputRedirection() throws AbstractApplicationException, ShellException {
        expectedEx.expect(ShellException.class);
        expectedEx.expectMessage("The system cannot find the file specified");
        shell.parseAndEvaluate("cat < non-existent-file", testOut);
    }
    
    @Test
    public void testCatWithValidInputEmptyOutputRedirection() throws AbstractApplicationException, ShellException {
        expectedEx.expect(ShellException.class);
        expectedEx.expectMessage("Invalid syntax encountered");
        shell.parseAndEvaluate("cat < redirection test" + FS + "test 1.txt >", testOut);
    }
    
    @Test
    public void testCatWithSameRedirectionFile() throws AbstractApplicationException, ShellException {
        expectedEx.expect(ShellException.class);
        expectedEx.expectMessage("Input redirection file same as output redirection file");
        shell.parseAndEvaluate("cat < redirection test" + FS + "test 1.txt > redirection test" + FS + "test 1.txt", testOut);
    }
    
    @Test
    public void testCatWithEmptyInputOutputRedirection() throws AbstractApplicationException, ShellException {
        expectedEx.expect(ShellException.class);
        expectedEx.expectMessage("Invalid syntax encountered");
        shell.parseAndEvaluate("cat < >", testOut);
    }
    
    @Test
    public void testCatWithValidInputOutputRedirectionUnquoted() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("cat < redirection test" + FS + "test 1.txt > redirection test" + FS + "test 1-output.txt", testOut);
        assertEquals("", testOut.toString());
        File file1 = new File(Environment.currentDirectory + FS + "redirection test" + FS + "test 1.txt");
        File file2 = new File(Environment.currentDirectory + FS + "redirection test" + FS + "test 1-output.txt");
        assertTrue(isSameContent(file1, file2));
    }
    
    @Test
    public void testCatWithValidInputOutputRedirectionSingleQuoted() throws AbstractApplicationException, ShellException {
        expectedEx.expect(ShellException.class);
        expectedEx.expectMessage("Invalid syntax encountered.");
        shell.parseAndEvaluate("cat < redirection test" + FS + "test 1.txt > 'redirection test" + FS + "test 1-output.txt'", testOut);
    }
    
    @Test
    public void testCatWithValidInputOutputRedirectionDoubleQuoted() throws AbstractApplicationException, ShellException {
        expectedEx.expect(ShellException.class);
        expectedEx.expectMessage("Invalid syntax encountered.");
        shell.parseAndEvaluate("cat < redirection test" + FS + "test 1.txt > \"redirection test" + FS + "test 1-output.txt\"", testOut);
    }
    
    @Test
    public void testCatWithValidInputInvalidOutputRedirection() throws AbstractApplicationException, ShellException {
        expectedEx.expect(ShellException.class);
        expectedEx.expectMessage("Invalid syntax encountered.");
        shell.parseAndEvaluate("cat < redirection test" + FS + "test 1.txt > 'non-existent-file'", testOut);
    }

    private boolean isSameContent(File file1, File file2) {
        try {
            BufferedReader reader1 = new BufferedReader(new FileReader(file1));
            BufferedReader reader2 = new BufferedReader(new FileReader(file2));
            
            String line1 = null;
            String line2 = null;
            boolean flag = true;
            while ((flag == true) && ((line1 = reader1.readLine()) != null)
                    && ((line2 = reader2.readLine()) != null)) {
                if (!line1.contentEquals(line2)) {
                    flag = false;
                    break;
                }
            }
            reader1.close();
            reader2.close();
            return flag;
       } catch (Exception e) {
           System.err.println("Unable to compare files");
           return false;
       }
    }
    
    @BeforeClass
    public static void setUpOnce() {
        shell = new ShellImpl();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
        createFiles(n);
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
        deleteFiles();
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        testOut.reset();
    }
    
    //Create n files in /redirection test/ directory
    private static void createFiles(int n) {
        Path path = Paths.get(Environment.currentDirectory + FS + "redirection test");
        try {
            Files.createDirectories(path);
        } catch (IOException e) {
            System.err.println("Test directory already exists.");
        }
        
        for (int j = 1; j <= n; j++) {
            try {
                String filepath = Environment.currentDirectory + FS + "redirection test" + FS + "test " + j + ".txt";
                PrintWriter writer = new PrintWriter(filepath);              // File contents:
                writer.println("test " + j);                                 // test 1 (new line)
                writer.print("test " + j);                                   // test 1 (No new line)
                writer.close();
            } catch (IOException ioe) {
                System.err.println("Test file already exists.");
            }
        }
    }
    
    //Delete n files in /redirection test/ directory
    private static void deleteFiles() {
        Path directory = Paths.get(Environment.currentDirectory + "/redirection test");
        try {
            Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
               @Override
               public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                   Files.delete(file);
                   return FileVisitResult.CONTINUE;
               }

               @Override
               public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                   Files.delete(dir);
                   return FileVisitResult.CONTINUE;
               }
            });
        } catch (IOException e) {
            System.err.println("Error encountered when deleting redirection test directory.");
            e.printStackTrace();
        }
    }
}