package ef1.unit;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.io.PrintWriter;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.impl.app.GrepApplication;

public class TestGrepApplication {
    static GrepApplication grepApp;
    static ByteArrayInputStream testIn;
    static ByteArrayOutputStream testOut;
    private static final String NL = System.getProperty("line.separator");
    private static final String TEST_DATA_1 = "test 1" + NL + "test 2" + NL + "test 3" + NL + "3 test" + NL + "2 test"
            + NL + "1 test" + NL + "\\b test" + NL + "\\t test" + NL + "\\n test" + NL + "\\f test" + NL + "\\r test"
            + NL + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
    private static final String TEST_DATA_2 = "test 1" + NL + "test 2" + NL + "test 3" + NL + "\\b test" + NL + "\\t test" 
            + NL + "\\n test" + NL + "\\f test" + NL + "\\r test" + NL + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
    
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();
    
    @Test
    public void testGrepFromStdin() {
        grepApp = new GrepApplication(new ByteArrayInputStream((TEST_DATA_1).getBytes()));
        String cmd = "grep ^t";
        String expected = "test 1" + NL + "test 2" + NL + "test 3" + NL;
        assertEquals(expected, grepApp.grepFromStdin(cmd));
    }

    @Test
    public void testGrepFromOneFile() {
        String cmd = "grep ^t test1.txt";
        String expected = "test 1" + NL + "test 2" + NL + "test 3" + NL;
        assertEquals(expected, grepApp.grepFromOneFile(cmd));
    }
    @Test
    public void testGrepSpecialCharacterFromOneFile1() {
        String cmd = "grep \\* test1.txt";
        String expected = "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
        assertEquals(expected, grepApp.grepFromOneFile(cmd));
    }
    @Test
    public void testGrepSpecialCharacterFromOneFile2() {
        String cmd = "grep \\( test1.txt";
        String expected = "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
        assertEquals(expected, grepApp.grepFromOneFile(cmd));
    }
    
    @Test
    public void testGrepThroughStdinMultipleFile() {
        String cmd = "grep ^t test1.txt test2.txt";
        String expected = "test1.txt:test 1" + NL + "test1.txt:test 2" + NL + "test1.txt:test 3" 
                    + NL + "test2.txt:test 1" + NL + "test2.txt:test 2" + NL + "test2.txt:test 3";
        assertEquals(expected, grepApp.grepFromMultipleFiles(cmd));
    }
    
    @Test
    public void testGrepInvalidPatternInStdin() {
        grepApp = new GrepApplication(new ByteArrayInputStream((TEST_DATA_1).getBytes()));
        String cmd = "grep (";
        String expected = "grep: Invalid pattern specified";
        assertEquals(expected, grepApp.grepInvalidPatternInStdin(cmd));
    }
    
    @Test
    public void testGrepInvalidPatternInFile() {
        String cmd = "grep ( test1.txt";
        String expected = "grep: Invalid pattern specified";
        assertEquals(expected, grepApp.grepInvalidPatternInStdin(cmd));
    }
    
    @Test
    public void testGrepRunWithStdinAndFile() throws AbstractApplicationException {
        testIn = new ByteArrayInputStream((TEST_DATA_1).getBytes());
        String expected = "test 3" + NL;
        grepApp.run(new String[] { "3", "test2.txt" }, testIn, testOut);
        assertEquals(expected, testOut.toString());
    }
    
    @Test
    public void testGrepRunWithNullStdin() throws AbstractApplicationException {
        expectedEx.expect(AbstractApplicationException.class);
        expectedEx.expectMessage("Null Pointer Exception");
        grepApp.run(new String[] { "3" }, null, testOut);
    }
    
    @Test
    public void testGrepRunWithNullStdout() throws AbstractApplicationException {
        expectedEx.expect(AbstractApplicationException.class);
        expectedEx.expectMessage("Null Pointer Exception");
        grepApp.run(new String[] { "3", "non-existent-file" }, testIn, null);
    }
    
    @Test
    public void testGrepRunWithNullStdinNullStdout() throws AbstractApplicationException {
        expectedEx.expect(AbstractApplicationException.class);
        expectedEx.expectMessage("Null Pointer Exception");
        grepApp.run(new String[] { "3" }, null, null);
    }
    
    @Test
    public void testGrepRunWithInvalidFile() throws AbstractApplicationException {
        expectedEx.expect(AbstractApplicationException.class);
        expectedEx.expectMessage("Invalid file path");
        grepApp.run(new String[] { "3", "non-existent-file" }, null, testOut);
    }
    
    @BeforeClass
    public static void setUpOnce() {
        grepApp = new GrepApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
        
        createFiles();
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
        deleteFiles();
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        if (testIn != null) {
            testIn.reset();
        }
        testOut.reset();
    }
    
    private static void createFiles() {
        try {
            PrintWriter writer1 = new PrintWriter("test1.txt");
            writer1.print(TEST_DATA_1);
            writer1.close();
            PrintWriter writer2 = new PrintWriter("test2.txt");
            writer2.print(TEST_DATA_2);
            writer2.close();
        } catch (Exception e) {
            deleteFiles();
        }
    }

    private static void deleteFiles() {
        File file1 = new File("test1.txt");
        file1.delete();
        File file2 = new File("test2.txt");
        file2.delete();
    }
}
