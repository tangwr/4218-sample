package ef1.unit;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestGlobbing {
    static ShellImpl shell;
    static final String NL = System.getProperty("line.separator");
    
    static int n = 2; //Any n >= 2: Create n files for testing purposes.
    
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();
    
    @Test
    public void testGlobNoPaths() throws AbstractApplicationException, ShellException {
        String command = shell.globNoPaths("echo *");
        String expected = "echo ";
        for (int i = 1; i <= n; i++) {
            expected += "test " + i + ".txt";
            if (i != n) expected += " ";
        }
        assertEquals(expected, command);
    }
    
    @Test
    public void testGlobOneFile() throws AbstractApplicationException, ShellException {
        String command = shell.globOneFile("echo *.test");
        String expected = "echo ";
        for (int i = 1; i <= n; i++) {
            expected += "testfile" + i + ".test";
            if (i != n) expected += " ";
        }
        assertEquals(expected, command);
    }
    
    @Test
    public void testGlobFilesDirectoriesDirWithSpaceNoEffect() throws AbstractApplicationException, ShellException {
        String command = shell.globFilesDirectories("echo glob test 1/*.txt");
        String expected = "echo glob test 1/*.txt";
        assertEquals(expected, command);
    }
    
    @Test
    public void testGlobFilesDirectoriesGlobFileInDir() throws AbstractApplicationException, ShellException {
        String command = shell.globFilesDirectories("echo 'glob test 1'/*.txt");
        String expected = "echo ";
        for (int i = 1; i <= n; i++) {
            expected += "glob test 1/test " + i + ".txt";
            if (i != n) expected += " ";
        }
        assertEquals(expected, command);
    }
    
    @Test
    public void testGlobFilesDirectoriesGlobFileWithSpaceNoEffect() throws AbstractApplicationException, ShellException {
        String command = shell.globFilesDirectories("echo */test 1.txt");
        String expected = "echo */test 1.txt";
        assertEquals(expected, command);
    }
    
    @Test
    public void testGlobFilesDirectoriesGlobFileInCurrDir() throws AbstractApplicationException, ShellException {
        String command = shell.globFilesDirectories("echo */'test 1.txt'");
        String expected = "echo glob test 1/test 1.txt glob test 2/test 1.txt";
        assertEquals(expected, command);
    }
    
    @Test
    public void testGlobWithException() throws AbstractApplicationException, ShellException {
        String command = shell.globFilesDirectories("echo non-existent/*");
        assertEquals("echo non-existent/*", command);
    }
    
    @Test
    public void testGlobWithExceptionInvalidFileName() throws AbstractApplicationException, ShellException {
        String command = shell.globFilesDirectories("echo invalid:name/*");
        assertEquals("echo invalid:name/*", command);
    }
    
    @BeforeClass
    public static void setUpOnce() {
        shell = new ShellImpl();
        createFiles(n);
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
        deleteFiles();
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    private static void createFiles(int n) {
        //Create n files for testing
        for (int i = 1; i <= n; i++) {
            try {
                PrintWriter writer = new PrintWriter("test " + i + ".txt");  // File contents:
                writer.println("test" + i);                                 // test 1 (new line)
                writer.print("test" + i);                                   // test 1 (No new line)
                writer.close();
            } catch (IOException ioe) {
               try {
                   File file = new File("test " + i + ".txt");
                   file.delete();
               } catch (Exception e) {
                   e.printStackTrace();
               }
            }
        }
        
        //Create n + 1 files in current directory with .test as extension
        for (int i = 1; i <= n; i++) {
            File file = new File("testfile" + i + ".test");
            try {
                file.createNewFile();
            } catch (IOException ioe) {
                System.err.println("Test file already exists.");
            }
        }
        
        //Create n files in /glob test 1/ and /glob test 2/ directory
        for (int i = 1; i <= 2; i++) {
            Path path = Paths.get(Environment.currentDirectory + "/glob test " + i);
            try {
                Files.createDirectories(path);
            } catch (IOException e) {
                System.err.println("Test directory already exists.");
            }
            
            for (int j = 1; j <= n; j++) {
                try {
                    path = Paths.get(Environment.currentDirectory + "/glob test " + i + "/test " + j + ".txt");
                    Files.createFile(path);
                } catch (IOException ioe) {
                    System.err.println("Test file already exists.");
                }
            }
        }
    }
    
    private static void deleteFiles() {
        //Delete n files that were created for testing
        for (int i = 1; i <= n; i++) {
            try {
                File file = new File("test " + i + ".txt");
                file.delete();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        for (int i = 1; i <= n; i++) {
            try {
                File file = new File("testfile" + i + ".test");
                file.delete();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        //Recursively delete /glob test 1/ and /glob test 2/ directory and files
        for (int i = 1; i <= 2; i++) {
            Path directory = Paths.get(Environment.currentDirectory + "/glob test " + i);
            try {
                Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
                   @Override
                   public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                       Files.delete(file);
                       return FileVisitResult.CONTINUE;
                   }
    
                   @Override
                   public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                       Files.delete(dir);
                       return FileVisitResult.CONTINUE;
                   }
                });
            } catch (IOException e) {
                System.err.println("Error encountered when deleting glob test " + i + " directory.");
                e.printStackTrace();
            }
        }
    }
}
