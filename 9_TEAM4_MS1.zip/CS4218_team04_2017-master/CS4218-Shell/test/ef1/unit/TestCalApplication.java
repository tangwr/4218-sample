package ef1.unit;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;

import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.CalException;
import sg.edu.nus.comp.cs4218.impl.app.CalApplication;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class TestCalApplication {

	private static final String NL = System.getProperty("line.separator");
	private static final String FEB_2024 = "   February 2024" + NL + 
			"Su Mo Tu We Th Fr Sa" + NL + 
			"             1  2  3" + NL +
			" 4  5  6  7  8  9 10" + NL +
			"11 12 13 14 15 16 17" + NL +
			"18 19 20 21 22 23 24" + NL +
			"25 26 27 28 29" + NL;
	private static final String FEB_2023 = "   February 2023" + NL + 
			"Su Mo Tu We Th Fr Sa" + NL +
			"          1  2  3  4" + NL +
	        " 5  6  7  8  9 10 11" + NL +
	        "12 13 14 15 16 17 18" + NL +
	        "19 20 21 22 23 24 25" + NL +
	        "26 27 28" + NL;
	private static final String NOV_2024 = "   November 2024" + NL + 
			"Su Mo Tu We Th Fr Sa" + NL +
			"                1  2" + NL + 
			" 3  4  5  6  7  8  9" + NL +
			"10 11 12 13 14 15 16" + NL +
			"17 18 19 20 21 22 23" + NL +
			"24 25 26 27 28 29 30" + NL;
	private static final String DEC_2024_M = "   December 2024" + NL + 
			"Mo Tu We Th Fr Sa Su" + NL +
			"                   1" + NL +
			" 2  3  4  5  6  7  8" + NL +
			" 9 10 11 12 13 14 15" + NL +
			"16 17 18 19 20 21 22" + NL +
			"23 24 25 26 27 28 29" + NL +
			"30 31" + NL;
	private static final String YEAR_2020 = "\t\t\t\t\t\t\t\t2020" + NL + NL +
			"   January              February               March" + NL +
			"Su Mo Tu We Th Fr Sa   Su Mo Tu We Th Fr Sa   Su Mo Tu We Th Fr Sa" + NL +
			"          1  2  3  4                      1    1  2  3  4  5  6  7" + NL +
			" 5  6  7  8  9 10 11    2  3  4  5  6  7  8    8  9 10 11 12 13 14" + NL +
			"12 13 14 15 16 17 18    9 10 11 12 13 14 15   15 16 17 18 19 20 21" + NL +
			"19 20 21 22 23 24 25   16 17 18 19 20 21 22   22 23 24 25 26 27 28" + NL +
			"26 27 28 29 30 31      23 24 25 26 27 28 29   29 30 31" + NL +
			"26 27 28 29 30 31      23 24 25 26 27 28 29   29 30 31" + NL +
			NL +
			"   April                  May                    June" + NL +
			"Su Mo Tu We Th Fr Sa   Su Mo Tu We Th Fr Sa   Su Mo Tu We Th Fr Sa" + NL +
			"          1  2  3  4                   1  2       1  2  3  4  5  6" + NL +
			" 5  6  7  8  9 10 11    3  4  5  6  7  8  9    7  8  9 10 11 12 13" + NL +
			"12 13 14 15 16 17 18   10 11 12 13 14 15 16   14 15 16 17 18 19 20" + NL +
			"19 20 21 22 23 24 25   17 18 19 20 21 22 23   21 22 23 24 25 26 27" + NL +
			"26 27 28 29 30         24 25 26 27 28 29 30   28 29 30" + NL +
			"                       31" + NL +
			"   July                   August                 September" + NL +
			"Su Mo Tu We Th Fr Sa   Su Mo Tu We Th Fr Sa   Su Mo Tu We Th Fr Sa" + NL +
			"          1  2  3  4                      1          1  2  3  4  5" + NL +
			" 5  6  7  8  9 10 11    2  3  4  5  6  7  8    6  7  8  9 10 11 12" + NL +
			"12 13 14 15 16 17 18    9 10 11 12 13 14 15   13 14 15 16 17 18 19" + NL +
			"19 20 21 22 23 24 25   16 17 18 19 20 21 22   20 21 22 23 24 25 26" + NL +
			"26 27 28 29 30 31      23 24 25 26 27 28 29   27 28 29 30" + NL +
			"                       30 31" + NL +
			"   October                November               December" + NL +
			"Su Mo Tu We Th Fr Sa   Su Mo Tu We Th Fr Sa   Su Mo Tu We Th Fr Sa" + NL +
			"             1  2  3    1  2  3  4  5  6  7          1  2  3  4  5" + NL +
			" 4  5  6  7  8  9 10    8  9 10 11 12 13 14    6  7  8  9 10 11 12" + NL +
			"11 12 13 14 15 16 17   15 16 17 18 19 20 21   13 14 15 16 17 18 19" + NL +
			"18 19 20 21 22 23 24   22 23 24 25 26 27 28   20 21 22 23 24 25 26" + NL +
			"25 26 27 28 29 30 31   29 30                  27 28 29 30 31" + NL;
	private static final String YEAR_7_M = "\t\t\t\t\t\t\t\t7" + NL + NL +
			"   January                February               March" + NL +
			"Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su" + NL +
			"                1  2       1  2  3  4  5  6       1  2  3  4  5  6" + NL +
			" 3  4  5  6  7  8  9    7  8  9 10 11 12 13    7  8  9 10 11 12 13" + NL +
			"10 11 12 13 14 15 16   14 15 16 17 18 19 20   14 15 16 17 18 19 20" + NL +
			"17 18 19 20 21 22 23   21 22 23 24 25 26 27   21 22 23 24 25 26 27" + NL +
			"24 25 26 27 28 29 30   28                     28 29 30 31" + NL +
			"31" + NL +
			"   April                  May                    June" + NL +
			"Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su" + NL +
			"             1  2  3    2  3  4  5  6  7  8          1  2  3  4  5" + NL +
			" 4  5  6  7  8  9 10    9 10 11 12 13 14 15    6  7  8  9 10 11 12" + NL +
			"11 12 13 14 15 16 17   16 17 18 19 20 21 22   13 14 15 16 17 18 19" + NL +
			"18 19 20 21 22 23 24   23 24 25 26 27 28 29   20 21 22 23 24 25 26" + NL +
			"25 26 27 28 29 30      30 31                  27 28 29 30" + NL +
			NL +
			"   July                   August                 September" + NL +
			"Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su" + NL +
			"             1  2  3    1  2  3  4  5  6  7             1  2  3  4" + NL +
			" 4  5  6  7  8  9 10    8  9 10 11 12 13 14    5  6  7  8  9 10 11" + NL +
			"11 12 13 14 15 16 17   15 16 17 18 19 20 21   12 13 14 15 16 17 18" + NL +
			"18 19 20 21 22 23 24   22 23 24 25 26 27 28   19 20 21 22 23 24 25" + NL +
			"25 26 27 28 29 30 31   29 30 31               26 27 28 29 30" + NL +
			NL +
			"   October                November               December" + NL +
			"Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su   Mo Tu We Th Fr Sa Su" + NL +
			"                1  2       1  2  3  4  5  6             1  2  3  4" + NL +
			" 3  4  5  6  7  8  9    7  8  9 10 11 12 13    5  6  7  8  9 10 11" + NL +
			"10 11 12 13 14 15 16   14 15 16 17 18 19 20   12 13 14 15 16 17 18" + NL +
			"17 18 19 20 21 22 23   21 22 23 24 25 26 27   19 20 21 22 23 24 25" + NL +
			"24 25 26 27 28 29 30   28 29 30               26 27 28 29 30 31" + NL +
			"31" + NL;
	
	private static CalApplication calApp;
	private static ByteArrayOutputStream result;
	private Calendar date;

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();
    
	@BeforeClass
	public static void setUpOnce() {
		calApp = new CalApplication();
		result = new ByteArrayOutputStream();
		System.setOut(new PrintStream(result));
	}

	@AfterClass
	public static void tearDownOnce() {
        System.setOut(null);
	}

	@After
	public void tearDown() {
		result.reset();
	}

	@Test
	public void testCal() throws AbstractApplicationException {
		String args[] = {};
		calApp.run(args, null, result);
		String expected = getMonthDisplay(false);
		assertEquals(expected, result.toString());
	}
	@Test
	public void testCalWithFormatM() throws AbstractApplicationException {
		String args[] = {"-m"};
		calApp.run(args, null, result);
		String expected = getMonthDisplay(true);
		assertEquals(expected, result.toString());
	}
	@Test
	public void testCalYear() throws AbstractApplicationException {
		String args[] = {"2020"};
		calApp.run(args, null, result);
		assertEquals(YEAR_2020, result.toString());
	}
	@Test
	public void testCalYearWithFormatM() throws AbstractApplicationException {
		String args[] = {"7"};
		calApp.run(args, null, result);
		assertEquals(YEAR_7_M, result.toString());
	}
	@Test
	public void testCalWithFebLeapYear() throws AbstractApplicationException {
		String args[] = {"2 2024"};
		calApp.run(args, null, result);
		assertEquals(FEB_2024, result.toString());
	}
	@Test
	public void testCalWithFebNonLeapYear() throws AbstractApplicationException {
		String args[] = {"2 2023"};
		calApp.run(args, null, result);
		assertEquals(FEB_2023, result.toString());
	}
	@Test
	public void testCalWithMonthAndYear() throws AbstractApplicationException {
		String args[] = {"11 2024"};
		calApp.run(args, null, result);
		assertEquals(NOV_2024, result.toString());
	}
	@Test
	public void testCalWithMonthAndYearWithFormatM() throws AbstractApplicationException {
		String args[] = {"12 2024"};
		calApp.run(args, null, result);
		assertEquals(DEC_2024_M, result.toString());
	}
	@Test
	public void testCalWithInvalidYear1() throws AbstractApplicationException {
		String args[] = {"0"};
        expectedEx.expect(CalException.class);
        expectedEx.expectMessage("bad year");
		calApp.run(args, null, result);
	}
	@Test
	public void testCalWithInvalidYear2() throws AbstractApplicationException {
		String args[] = {"a"};
        expectedEx.expect(CalException.class);
        expectedEx.expectMessage("bad year");
		calApp.run(args, null, result);
	}
	@Test
	public void testCalWithInvalidYear3() throws AbstractApplicationException {
		String args[] = {"3 a"};
        expectedEx.expect(CalException.class);
        expectedEx.expectMessage("bad year");
		calApp.run(args, null, result);
	}
	@Test
	public void testCalWithInvalidMonth1() throws AbstractApplicationException {
		String args[] = {"a 2017"};
        expectedEx.expect(CalException.class);
        expectedEx.expectMessage("bad month");
		calApp.run(args, null, result);
	}
	@Test
	public void testCalWithInvalidMonth2() throws AbstractApplicationException {
		String args[] = {"13 2017"};
        expectedEx.expect(CalException.class);
        expectedEx.expectMessage("bad month");
		calApp.run(args, null, result);
	}
	@Test
	public void testCalWithInvalidFormat() throws AbstractApplicationException {
		String args[] = {"-z"};
        expectedEx.expect(CalException.class);
        expectedEx.expectMessage("invalid format");
		calApp.run(args, null, result);
	}

	private String getMonthDisplay(boolean m) {
		String display = "   ";
		date = Calendar.getInstance();
		date.set(Calendar.DAY_OF_MONTH, 1);
		int month = 0;
		String[] filler = {"", " ", " ", " ", " ", " ", " "};
		String[] temp = date.getTime().toString().split(" ");
		String[] day;
		String[] months = {"", "January", "February", "March", "April", "May", "June", "July"
				, "August", "September", "October", "November", "December"};
		int[] days = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		
		if (m) {
			day = new String[]{"Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"};
		} else {
			day = new String[]{"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};
		}
		for (int i=0; i<months.length; i++) {
			if (months[i].startsWith(temp[1].trim())){
				display += months[i] + " " + temp[temp.length-1] + NL;
				month = i;
				break;
			}
		}
		display += day[0];
		for (int i=1; i<day.length; i++) {
			display += " " + day[i];
		}
		display += NL;
		
		int count = 0;
		boolean run = false;
		while (count<days[month]){
			for (int i=0; i<7; i++){
				if (temp[0].startsWith(day[i]))
					run = true;
				if (run) {
					count++;
					if (count < 10) {
						display += " ";
					} else if (count > days[month]) {
						break;
					}
					display += filler[i] + count;
				} else
					display += filler[i] + "  ";
			}
			display += NL;
		}
		return display;
	}

}
