package ef1.unit;

import static org.junit.Assert.assertEquals;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;
import sg.edu.nus.comp.cs4218.impl.app.GrepApplication;
import sg.edu.nus.comp.cs4218.impl.app.SortApplication;

public class TestSortApplication {
	
		//pairwise test suite			  [number]  [-n]  [s.char]  [capital]  [small]  
		// TEST 1 : sort exist.txt 		<--    0	TRUE	FALSE	 TRUE		FALSE
		// TEST 2 : sort exist.txt 		<--    0	TRUE	TRUE     FALSE		TRUE
		// TEST 3 : sort exist.txt 		<--    0	FALSE	FALSE	 TRUE   	FALSE
		// TEST 4 : sort exist.txt 		<--    0	FALSE	TRUE     FALSE		TRUE
		// TEST 5 : sort exist.txt 		<-- -9999	TRUE	FALSE	 TRUE		FALSE
		// TEST 6 : sort exist.txt 		<-- -9999	TRUE	TRUE	 FALSE 		TRUE
		// TEST 7 : sort exist.txt 		<-- -9999	FALSE	FALSE	 TRUE		FALSE
		// TEST 8 : sort exist.txt 		<-- -9999	FALSE	TRUE	 FALSE		TRUE
		// TEST 9 : sort exist.txt 		<--  9999	TRUE	FALSE    TRUE 		FALSE
		// TEST 10: sort exist.txt 		<--  9999	TRUE	TRUE     FALSE		TRUE
		// TEST 11: sort exist.txt 		<--  9999	FALSE	FALSE    TRUE		FALSE
		// TEST 12: sort exist.txt 		<--  9999	FALSE	TRUE	 FALSE 		TRUE
		
		//individual test suite
		// TEST 1 : sort exist.txt 		<--                                    					[normal sort]
		// TEST 2 : sort exist.txt 		<-- 							  [specialchar]			[normal sort]
		// TEST 3 : sort exist.txt 		<-- 					  [number]						[normal sort]
		// TEST 4 : sort exist.txt 		<-- 					  [number][specialchar]			[normal sort]
		// TEST 5 : sort exist.txt 		<-- 			[big case]		             			[normal sort]
		// TEST 6 : sort exist.txt 		<-- 			[big case]        [specialchar]	  		[normal sort]
		// TEST 7 : sort exist.txt 		<-- 			[big case][number]						[normal sort]			
		// TEST 8 : sort exist.txt 		<-- 			[big case][number][specialchar]			[normal sort]
		// TEST 9 : sort exist.txt 		<-- [small case]										[normal sort]
		// TEST 10: sort exist.txt 		<-- [small case]				  [specialchar]			[normal sort]
		// TEST 11: sort exist.txt 		<-- [small case]          [number]						[normal sort]
		// TEST 12: sort exist.txt 		<-- [small case]		  [number][specialchar]			[normal sort]
		// TEST 13: sort exist.txt 		<-- [small case][big case]        						[normal sort]
		// TEST 14: sort exist.txt 		<-- [small case][big case]        [specialchar]			[normal sort]
		// TEST 15: sort exist.txt 		<-- [small case][big case][number]						[normal sort]
		// TEST 16: sort exist.txt 		<-- [small case][big case][number][specialchar]			[normal sort]
		
		//Exhaustive Sequence test suite
		// TEST 1 : sort exist.txt 		<-- [small case][big case][number][specialchar]			[normal sort]
		// TEST 2 : sort exist.txt 		<-- [small case][big case][specialchar][number]			[normal sort]
		// TEST 3 : sort exist.txt 		<-- [small case][number][big case][specialchar]			[normal sort]
		// TEST 4 : sort exist.txt 		<-- [small case][number][specialchar][big case]			[normal sort]
		// TEST 5 : sort exist.txt 		<-- [small case][specialchar][big case][number]			[normal sort]
		// TEST 6 : sort exist.txt 		<-- [small case][specialchar][number][big case]			[normal sort]
		// TEST 7 : sort exist.txt 		<-- [big case][small case][specialchar][number]			[normal sort]
		// TEST 8 : sort exist.txt 		<-- [big case][small case][number][specialchar]			[normal sort]
		// TEST 9 : sort exist.txt 		<-- [big case][number][specialchar][small case]			[normal sort]
		// TEST 10: sort exist.txt 		<-- [big case][number][small case][specialchar]			[normal sort]
		// TEST 11: sort exist.txt 		<-- [big case][specialchar][number][small case]			[normal sort]
		// TEST 12: sort exist.txt 		<-- [big case][specialchar][small case][number]			[normal sort]
		// TEST 13: sort exist.txt 		<-- [number][small case][big case][specialchar]			[normal sort]
		// TEST 14: sort exist.txt 		<-- [number][small case][specialchar][big case]			[normal sort]
		// TEST 15: sort exist.txt 		<-- [number][big case][small case][specialchar]			[normal sort]
		// TEST 16: sort exist.txt 		<-- [number][big case][specialchar][small case]			[normal sort]
		// TEST 17: sort exist.txt 		<-- [number][specialchar][small case][big case]			[normal sort]
		// TEST 18: sort exist.txt 		<-- [number][specialchar][big case][small case]			[normal sort]
		// TEST 19: sort exist.txt 		<-- [specialchar][small case][number][big case]			[normal sort]
		// TEST 20: sort exist.txt 		<-- [specialchar][small case][big case][number]			[normal sort]
		// TEST 21: sort exist.txt 		<-- [specialchar][big case][number][small case]			[normal sort]
		// TEST 22: sort exist.txt 		<-- [specialchar][big case][small case][number]			[normal sort]
		// TEST 23: sort exist.txt 		<-- [specialchar][number][big case][small case]			[normal sort]
		// TEST 24: sort exist.txt 		<-- [specialchar][number][small case][big case]			[normal sort]


    static SortApplication sortApp;
    static ByteArrayInputStream testIn;
    static ByteArrayOutputStream testOut;
	static ShellImpl shell;

    static ArrayList<Path> listOfPaths=new ArrayList<Path>();
    static final String NL = System.getProperty("line.separator");
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		for(int x=0;x<listOfPaths.size();x++)
		{
			resetAndDeleteFile(listOfPaths.get(x));
		}
		for(int x=1;x<13;x++)
		{
			resetAndDeleteFile(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise" + x+".txt"));
		}
		for(int x=1;x<17;x++)
		{
			resetAndDeleteFile(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual" + x+".txt"));
		}
		for(int x=1;x<25;x++)
		{
			resetAndDeleteFile(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive" + x+".txt"));
		}
	}

	@Before
	public void setUp() throws Exception {
		sortApp = new SortApplication();
	}

	@Test //TEST 1 pairwise: sort exist.txt 		<--    0	TRUE	FALSE	 TRUE		FALSE
	public void testSortPairWise1() throws Exception {
    	createTxtFile("sortPairwise1.txt",new String[]{"0","0","0","A","Z","B"});//createTxtFile(fileName,content[])
    	//String input = "0"+ NL +"0"+ NL +"0"+ NL +"A"+ NL +"Z"+ NL +"B";
		//InputStream stdin = new ByteArrayInputStream(input.getBytes());
    	sortApp.run(new String[]{"sortNormal1.txt -n"}, null, testOut);
        assertEquals(  "0"+ NL + "0" + NL + "0" + NL + "A" + NL + "B" + NL +"Z",sortApp.sortCapitalNumbers(""));
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise1.txt"));
	}
	@Test // TEST 2 pairwise: sort exist.txt 		<--    0	TRUE	TRUE     FALSE		TRUE
	public void testSortPairWise2() throws Exception {
    	createTxtFile("sortPairwise2.txt",new String[]{"0","0","0","!","@","#","a","b","c"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal2.txt -n"}, null, testOut);
        assertEquals(  "!"+ NL + "#" + NL + "@" + NL + "0" + NL + "0" + NL + "0" + NL + "a" + NL + "b" + NL + "c",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortNormal2.txt"));
	}
	@Test //TEST 3 pairwise: sort exist.txt 		<--    0	FALSE	FALSE	 TRUE   	FALSE
	public void testSortPairWise3() throws Exception {
    	createTxtFile("sortPairwise3.txt",new String[]{"0","0","0","A","P","S"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal3.txt"}, null, testOut);
        assertEquals(  "0"+ NL + "0" + NL + "0" + NL + "A" + NL + "P" + NL + "S",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise3.txt"));
	}
	@Test // TEST 4 pairwise: sort exist.txt 		<--    0	FALSE	TRUE     FALSE		TRUE
	public void testSortPairWise4() throws Exception {
    	createTxtFile("sortPairwise4.txt",new String[]{"0","0","0","@","^","(","a","c","b"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal4.txt"}, null, testOut);
        assertEquals(  "<" + NL + "@" + NL + "^" + NL + "0" + NL + "0" + NL + "0" + NL + "a" + NL + "b" + NL + "c",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise4.txt"));
	}
	@Test // TEST 5 pairwise: sort exist.txt 		<-- -9999	TRUE	FALSE	 TRUE		FALSE
	public void testSortPairWise5() throws Exception {
    	createTxtFile("sortPairwise5.txt",new String[]{"A","B","C","-3","-2","-1"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal5.txt -n"}, null, testOut);
        assertEquals(  "-3"+ NL + "-2" + NL + "-1" + "A"+ NL + "B" + NL + "C",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise5.txt"));
	}
	@Test // TEST 6 pairwise: sort exist.txt 		<-- -9999	TRUE	TRUE	 FALSE 		TRUE
	public void testSortPairWise6() throws Exception {
    	createTxtFile("sortPairwise6.txt",new String[]{"#","$","!","-100","-10","-10000","asdf","zasd","qasd"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal6.txt -n"}, null, testOut);
        assertEquals(   "-10000" + NL + "-100" + NL + "-10" + NL + "!" + NL + "#" + NL + "$" + NL + "asdf" + NL + "qasd" + NL + "zasd",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise6.txt"));
	}
	@Test // TEST 7 pairwise: sort exist.txt 		<-- -9999	FALSE	FALSE	 TRUE		FALSE
	public void testSortPairWise7() throws Exception {
    	createTxtFile("sortPairwise7.txt",new String[]{"-13","-1","-654123","POKEMON","SANDY","Stormy"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal7.txt"}, null, testOut);
        assertEquals(  "-1"+ NL + "-13" + NL + "-654123"+ NL + "POKEMON" + NL + "SANDY" + NL + "Stormy" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise7.txt"));
	}
	@Test // TEST 8 pairwise: sort exist.txt 		<-- -9999	FALSE	TRUE	 FALSE		TRUE
	public void testSortPairWise8() throws Exception {
    	createTxtFile("sortPairwise8.txt",new String[]{"-123","-12343","-1","^%","##$","*&&","asdq","dfdfs","qwe"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal8.txt"}, null, testOut);
        assertEquals(  "##$"+ NL + "*&&" + NL + "^%" + NL + "-1" + NL + "-123" + NL + "-12343" + NL + "asdq"+ NL + "dfdfs" + NL + "qwe",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise8.txt"));
	}
	@Test // TEST 9 pairwise: sort exist.txt 		<--  9999	TRUE	FALSE    TRUE 		FALSE
	public void testSortPairWise9() throws Exception {
    	createTxtFile("sortPairwise9.txt",new String[]{"999","234","1239984","KJLJF","WHITE","ASD"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal9.txt -n"}, null, testOut);
        assertEquals(  "234"+ NL + "999" + NL + "1239984"+ NL + "ASD"+ NL + "KJLJF"+ NL + "WHITE",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise9.txt"));
	}
	@Test // TEST 10 pairwise: sort exist.txt 		<--  9999	TRUE	TRUE     FALSE		TRUE
	public void testSortPairWise10() throws Exception {
    	createTxtFile("sortPairwise10.txt",new String[]{"812","1728","08972","!@#","##$","&&*","qokw","asdq","qokllsd"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal10.txt -n"}, null, testOut);
        assertEquals("!@#" + NL + "##$" + NL + "&&*" + NL + "812" + NL + "1728" + NL + "08972" + NL + "asdq" + NL+ "qokllsd" + NL + "qokw" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise10.txt"));
	}
	@Test // TEST 11 pairwise: sort exist.txt 		<--  9999	FALSE	FALSE    TRUE		FALSE
	public void testSortPairWise11() throws Exception {
    	createTxtFile("sortPairwise11.txt",new String[]{"123123","123122","124444587","PPOLKD","JQLK","JUQIWE"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal11.txt"}, null, testOut);
        assertEquals(  "123122"+ NL + "123123" + NL + "124444587" + NL + "JQLK" + NL + "JUQIWE" + NL + "PPOLKD",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise11.txt"));
	}
	@Test // TEST 12 pairwise: sort exist.txt 		<--  9999	FALSE	TRUE	 FALSE 		TRUE
	public void testSortPairWise12() throws Exception {
    	createTxtFile("sortPairwise12.txt",new String[]{"44489","13345","48856","!@#","$$$","!!@#","jkakhd","qweasdf","qljlsa"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal12.txt"}, null, testOut);
        assertEquals(  "!!@#"+ NL + "!@#" + NL + "$$$" + NL + "13345" + NL + "44489" + NL + "48856" + NL + "jkakhd" + NL + "qljlsa" + NL + "qweasdf",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortPairwise12.txt"));
	}
	
	@Test // TEST 1 individual:[none]
	public void testSortIndividual1() throws Exception {
    	createTxtFile("sortIndividual1.txt",new String[]{""});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortNormal12.txt"}, null, testOut);
        assertEquals("",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual1.txt"));
	}
	@Test // TEST 2 individual:[specialchar]
	public void testSortIndividual2() throws Exception {
    	createTxtFile("sortIndividual2.txt",new String[]{"!@#","$$$","!!@#","!@#$%%","(*&&&"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual2.txt"}, null, testOut);
        assertEquals("!!@#"+NL+"!@#"+NL+"!@#$%%"+NL+"$$$"+NL+"(*&&&" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual2.txt"));
	}
	@Test // TEST 3 individual:[number]
	public void testSortIndividual3() throws Exception {
    	createTxtFile("sortIndividual3.txt",new String[]{"44489","13345","48856","11","-2","0","1","44","23"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual3.txt -n"}, null, testOut);
        assertEquals( "-2"+NL+"0"+NL+"1"+NL+"11"+NL+"23"+NL+"44"+NL+"13345"+NL+"44489"+NL+"48856",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual3.txt"));
	}
	@Test // TEST 4 individual:[number][specialchar]
	public void testSortIndividual4() throws Exception {
    	createTxtFile("sortIndividual4.txt",new String[]{"44489","13345","48856","!@#","$$$","!!@#"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual4.txt -n"}, null, testOut);
        assertEquals( "!!@#"+NL+"!@#"+NL+"$$$"+NL+"13345"+NL+"44489"+NL+"48856" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual4.txt"));
	}
	@Test // TEST 5 individual:[big case]
	public void testSortIndividual5() throws Exception {
    	createTxtFile("sortIndividual5.txt",new String[]{"DONKEY","KEYCHAIN","CHAINSAW","SAWWY"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual5.txt"}, null, testOut);
        assertEquals( "CHAINSAW" + NL + "DONKEY" + NL + "KEYCHAIN" + NL + "SAWWY" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual5.txt"));
	}
	@Test // TEST 6 individual:[big case][specialchar]	
	public void testSortIndividual6() throws Exception {
    	createTxtFile("sortIndividual6.txt",new String[]{"HOTCHICK","THRONG","BIKINI","SUN","**","!@#","#"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual6.txt"}, null, testOut);
        assertEquals( "!@#" + NL + "#" + NL + "**" + NL + "BIKINI" + NL + "HOTCHICK" + NL + "SUN" + NL + "THRONG" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual6.txt"));
	}
	@Test // TEST 7 individual:[big case][number]
	public void testSortIndividual7() throws Exception {
    	createTxtFile("sortIndividual7.txt",new String[]{"HOtchICK","THroNG","BIkiNI","Sun","99","41","12"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual7.txt -n"}, null, testOut);
        assertEquals( "12" + NL + "41" + NL + "99" + NL + "BIkiNI" + NL + "HOtchICK" + NL + "Sun" + NL + "THroNG" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual7.txt"));
	}
	@Test // TEST 8 individual:[big case][number][specialchar]	
	public void testSortIndividual8() throws Exception {
    	createTxtFile("sortIndividual8.txt",new String[]{"HOtchICK","THroNG","BIkiNI","Sun","99","41","12","**","!@#","#"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual8.txt"}, null, testOut);
        assertEquals( "!@#"+NL+"#"+NL+"**"+NL+"BIkiNI"+NL+ "HOtchICK"+NL+"Sun"+NL+"THroNG"+NL+"12"+NL+"41"+NL+"99",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual8.txt"));
	}
	@Test // TEST 9 individual:[small case]
	public void testSortIndividual9() throws Exception {
    	createTxtFile("sortIndividual9.txt",new String[]{"elephant","sink","beAch","boAt","corAl","blUe","rain"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual9.txt"}, null, testOut);
        assertEquals( "beAch"+NL+"blUe"+NL+"boAt"+NL+"corAl"+NL+"elephant"+NL+"rain"+NL+"sink",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual9.txt"));
	}
	@Test // TEST 10 individual:[small case][specialchar]
	public void testSortIndividual10() throws Exception {
    	createTxtFile("sortIndividual10.txt",new String[]{"life","is","tough","probably","next","life","would","be","better",")","(","**","&&","--"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual10.txt"}, null, testOut);
        assertEquals( "&&"+NL+"("+NL+")"+NL+"**"+NL+"--"+NL+"be"+NL+"better"+NL+"is"+NL+"life"+NL+"life"+NL+"next"+NL+"probably"+NL+"tough"+NL+"would" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual10.txt"));
	}
	@Test // TEST 11 individual:[small case][number]
	public void testSortIndividual11() throws Exception {
    	createTxtFile("sortIndividual11.txt",new String[]{"life","is","tough","probably","next","life","would","be","better","99","41","12"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual11.txt"}, null, testOut);
        assertEquals( "be"+NL+"better"+NL+"is"+NL+"life"+NL+"life"+NL+"next"+NL+"probably"+NL+"tough"+NL+"would"+NL+"12"+NL+"41"+NL+"99" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual11.txt"));
	}
	@Test // TEST 12 individual:[small case][number][specialchar]	
	public void testSortIndividual12() throws Exception {
    	createTxtFile("sortIndividual12.txt",new String[]{"life","is","tough","probably","next","life","would","be","better","99","41","12",")","(","**","&&","--"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual12.txt"}, null, testOut);
        assertEquals( "&&"+NL+"("+NL+")"+NL+"**"+NL+"--"+NL+"be"+NL+"better"+NL+"is"+NL+"life"+NL+"life"+NL+"next"+NL+"probably"+NL+"tough"+NL+"would"+NL+"12"+NL+"41"+NL+"99" ,testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual12.txt"));
	}
	@Test // TEST 13 individual:[small case][big case]   
	public void testSortIndividual13() throws Exception {
    	createTxtFile("sortIndividual13.txt",new String[]{"life","is","tough","probably","next","life","would","be","better","HOtchICK","THroNG","BIkiNI","Sun"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual13.txt"}, null, testOut);
        assertEquals( "BIkiNI"+NL+ "HOtchICK"+NL+"Sun"+NL+"THroNG"+NL+"be"+NL+"better"+NL+"is"+NL+"life"+NL+"life"+NL+"next"+NL+"probably"+NL+"tough"+NL+"would",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual13.txt"));
	}
	@Test // TEST 14 individual:[small case][big case][specialchar]
	public void testSortIndividual14() throws Exception {
    	createTxtFile("sortIndividual14.txt",new String[]{"life","is","tough","probably","next","life","would","be","better","HOtchICK","THroNG","BIkiNI","Sun",")","(","**","&&","--"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual14.txt"}, null, testOut);
        assertEquals( "&&"+NL+"("+NL+")"+NL+"**"+NL+"--"+NL+"BIkiNI"+NL+ "HOtchICK"+NL+"Sun"+NL+"THroNG"+NL+"be"+NL+"better"+NL+"is"+NL+"life"+NL+"life"+NL+"next"+NL+"probably"+NL+"tough"+NL+"would",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual14.txt"));
	}
	@Test // TEST 15 individual:[small case][big case][number]
	public void testSortIndividual15() throws Exception {
    	createTxtFile("sortIndividual15.txt",new String[]{"life","is","tough","probably","next","life","would","be","better","HOtchICK","THroNG","BIkiNI","Sun","4455","23","124","23","77"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual15.txt"}, null, testOut);
        assertEquals( "BIkiNI"+NL+ "HOtchICK"+NL+"Sun"+NL+"THroNG"+NL+"be"+NL+"better"+NL+"is"+NL+"life"+NL+"life"+NL+"next"+NL+"probably"+NL+"tough"+NL+"would"+ NL + "23" +NL+ "23" +NL + "77" + NL + "124" + NL + "4455",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual15.txt"));
	}
	@Test // TEST 16 individual:[small case][big case][number][specialchar]	
	public void testSortIndividual16() throws Exception {
    	createTxtFile("sortIndividual16.txt",new String[]{"life","is","tough","probably","next","life","would","be","better","HOtchICK","THroNG","BIkiNI","Sun","4455","23","124","23","77",")","(","**","&&","--"});//createTxtFile(fileName,content[])
    	sortApp.run(new String[]{"sortIndividual16.txt"}, null, testOut);
        assertEquals( "&&"+NL+"("+NL+")"+NL+"**"+NL+"--"+NL+"BIkiNI"+NL+ "HOtchICK"+NL+"Sun"+NL+"THroNG"+NL+"be"+NL+"better"+NL+"is"+NL+"life"+NL+"life"+NL+"next"+NL+"probably"+NL+"tough"+NL+"would"+ NL + "23" +NL+ "23" +NL + "77" + NL + "124" + NL + "4455",testOut.toString() );
    	listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortIndividual16.txt"));
	}
	
	@Test// TEST 1 : sort exist.txt 		<-- [small case][big case][number][specialchar]			[normal sort]
	public void testSortExhaustive1() throws Exception{
		createTxtFile("sortExhaustive1.txt",new String[]{"p","a","l","s","A","S","L","O","5","65","32","5","!","#$@","!@@","//"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive1.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "!@@"  + NL + "#$@"   + NL + "//" + NL + 
					  "5" + NL + "5" + NL + "32"  + NL + "65"+ NL + 
					  "A" + NL + "L"  + NL + "O"   + NL + "S" + NL +
					  "a" + NL + "l"  + NL + "p"   + NL + "s", testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive1.txt"));
	}
	@Test// TEST 2 : sort exist.txt 		<-- [small case][big case][specialchar][number]			[normal sort]
	public void testSortExhaustive2() throws Exception{
		createTxtFile("sortExhaustive2.txt",new String[]{"p","a","l","s","A","S","L","O","!","#","$","%","5","65","32","5"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive2.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "5" + NL + "5"  + NL + "32"  + NL + "65" + NL +
					  "A" + NL +  "L" + NL +  "O"  + NL + "S" + NL +
					  "a" + NL + "l"  + NL + "p"   + NL + "s", testOut.toString() );		
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive2.txt"));
	}
	@Test// TEST 3 : sort exist.txt 		<-- [small case][number][big case][specialchar]			[normal sort]
	public void testSortExhaustive3() throws Exception{
		createTxtFile("sortExhaustive3.txt",new String[]{"p","a","l","s","5","65","32","5","A","S","L","O",")","!","@","&"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive3.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "&"  + NL + ")"   + NL + "@" + NL +
					  "5" + NL + "65" + NL + "32"  + NL + "5" + NL +
					  "A" + NL + "L"  + NL + "O"   + NL + "S" + NL +
					  "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );	
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive3.txt"));
	}
	@Test// TEST 4 : sort exist.txt 		<-- [small case][number][specialchar][big case]			[normal sort]
	public void testSortExhaustive4() throws Exception{
		createTxtFile("sortExhaustive4.txt",new String[]{"p","a","l","s","5","65","32","5","!","#","$","%","A","S","L","O"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive4.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "5" + NL + "2" + NL + "32"  + NL + "65" + NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
					  "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive4.txt"));
	}
	@Test// TEST 5 : sort exist.txt 		<-- [small case][specialchar][big case][number]			[normal sort]
	public void testSortExhaustive5() throws Exception{
		createTxtFile("sortExhaustive5.txt",new String[]{"p","a","l","s","!","#","$","%","A","S","L","O","51","65","32","52"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive5.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive5.txt"));
	}
	@Test// TEST 6 : sort exist.txt 		<-- [small case][specialchar][number][big case]			[normal sort]
	public void testSortExhaustive6() throws Exception{
		createTxtFile("sortExhaustive6.txt",new String[]{"pOPLE","aAD","lSD","sVV","!","#","$","%","5SD1","6Q5","302","52","A","S","L","O"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive6.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "5SD1" + NL + "6Q5" + NL + "52"  + NL + "302"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "aAD" + NL + "lSD"  + NL + "pOPLE"   + NL + "sVV" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive6.txt"));
	}
	@Test// TEST 7 : sort exist.txt 		<-- [big case][small case][specialchar][number]			[normal sort]
	public void testSortExhaustive7() throws Exception{
		createTxtFile("sortExhaustive7.txt",new String[]{"A","S","L","O","p","a","l","s","!","#","$","%","51","65","32","52"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive7.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive7.txt"));
	}
	@Test// TEST 8 : sort exist.txt 		<-- [big case][small case][number][specialchar]			[normal sort]
	public void testSortExhaustive8() throws Exception{
		createTxtFile("sortExhaustive8.txt",new String[]{"A","S","L","O","p","a","l","s","51","65","32","52","!","#","$","%"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive8.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
				  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
			      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
			      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive8.txt"));
	}
	@Test// TEST 9 : sort exist.txt 		<-- [big case][number][specialchar][small case]			[normal sort]
	public void testSortExhaustive9() throws Exception{
		createTxtFile("sortExhaustive9.txt",new String[]{"A","S","L","O","p","a","l","s","!","#","$","%","51","65","32","52"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive9.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
				  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
			      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
			      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive9.txt"));
	}
	@Test// TEST 10: sort exist.txt 		<-- [big case][number][small case][specialchar]			[normal sort]
	public void testSortExhaustive10() throws Exception{
		createTxtFile("sortExhaustive10.txt",new String[]{"A","S","L","O","51","65","32","52","pAD","qeasASDa","l","s","!","#","$","%"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive10.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
				  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
			      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
			      "l" + NL + "pAD"  + NL + "qeasASDa"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive10.txt"));
	}
	@Test// TEST 11: sort exist.txt 		<-- [big case][specialchar][number][small case]			[normal sort]
	public void testSortExhaustive11() throws Exception{
		createTxtFile("sortExhaustive11.txt",new String[]{"GFQA","SSDS","QL","CO","!","#","$","%","51","65","32","52","p","a","l","s"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive11.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
				      "CO" + NL + "GFQA"  + NL + "QL"   + NL + "SSDS"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive11.txt"));
	}
	@Test// TEST 12: sort exist.txt 		<-- [big case][specialchar][small case][number]			[normal sort]
	public void testSortExhaustive12() throws Exception{
		createTxtFile("sortExhaustive12.txt",new String[]{"A","S","L","O","!","#","$","%","p","a","l","s","51","65","32","52"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive12.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive12.txt"));
	}
	@Test// TEST 13: sort exist.txt 		<-- [number][small case][big case][specialchar]			[normal sort]
	public void testSortExhaustive13() throws Exception{
		createTxtFile("sortExhaustive13.txt",new String[]{"51","65","32","52","p","a","l","s","A","S","L","O","!","#","$","%"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive13.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive13.txt"));
	}
	@Test// TEST 14: sort exist.txt 		<-- [number][small case][specialchar][big case]			[normal sort]
	public void testSortExhaustive14() throws Exception{
		createTxtFile("sortExhaustive14.txt",new String[]{"52311","6asdf5","31232","5132","qwep","fasdfa","lasdf","s","!","#","$","%","A","S","L","O"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive14.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
				  "6asdf5" + NL + "5132" + NL + "31232"  + NL + "52311"+ NL +
			      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
			      "fasdfa" + NL + "lasdf"  + NL + "qwep"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive14.txt"));
	}
	@Test// TEST 15: sort exist.txt 		<-- [number][big case][small case][specialchar]			[normal sort]
	public void testSortExhaustive15() throws Exception{
		createTxtFile("sortExhaustive15.txt",new String[]{"51","65","32","52","A","S","L","O","p","a","l","s","!","#","$","%"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive15.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
				  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
			      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
			      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive15.txt"));
	}
	@Test// TEST 16: sort exist.txt 		<-- [number][big case][specialchar][small case]			[normal sort]
	public void testSortExhaustive16() throws Exception{
		createTxtFile("sortExhaustive16.txt",new String[]{"531","605","3112","52","A","S","L","O","!","#","$","%","p","a","l","s"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive16.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
				  "52" + NL + "531" + NL + "605"  + NL + "3112"+ NL +
			      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
			      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive16.txt"));
	}
	@Test// TEST 17: sort exist.txt 		<-- [number][specialchar][small case][big case]			[normal sort]
	public void testSortExhaustive17() throws Exception{
		createTxtFile("sortExhaustive17.txt",new String[]{"51","65","32","52","!","#","$","%","p","a","l","s","A","S","L","O"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive17.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive17.txt"));
	}
	@Test// TEST 18: sort exist.txt 		<-- [number][specialchar][big case][small case]			[normal sort]
	public void testSortExhaustive18() throws Exception{
		createTxtFile("sortExhaustive18.txt",new String[]{"51","65","32","52","!","#","$","%","A","S","L","O","p","a","l","s"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive18.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive18.txt"));
	}
	@Test// TEST 19: sort exist.txt 		<-- [specialchar][small case][number][big case]			[normal sort]
	public void testSortExhaustive19() throws Exception{
		createTxtFile("sortExhaustive19.txt",new String[]{"!","#!@","$12","%af","p","a","l","s","51","65","32","52","A","S","L","O"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive19.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#!@"  + NL + "$12"   + NL + "%af" + NL +
					  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive19.txt"));
	}
	@Test// TEST 20: sort exist.txt 		<-- [specialchar][small case][big case][number]			[normal sort]
	public void testSortExhaustive20() throws Exception{
		createTxtFile("sortExhaustive20.txt",new String[]{"!","#","$","%","p","a","l","s","A","S","L","O","51","65","32","52"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive20.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
					  "32" + NL + "51" + NL + "52"  + NL + "65"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive20.txt"));
	}
	@Test// TEST 21: sort exist.txt 		<-- [specialchar][big case][number][small case]			[normal sort]
	public void testSortExhaustive21() throws Exception{
		createTxtFile("sortExhaustive21.txt",new String[]{"!123","!#","$","%","A","S","L","O","65","32","532","5112","p","a","l","s"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive21.txt -n"}, null, testOut);
		assertEquals( "!#" + NL + "!123"  + NL + "$"   + NL + "%" + NL +
					  "32" + NL + "65" + NL + "532"  + NL + "5112"+ NL +
				      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
				      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive21.txt"));
	}
	@Test// TEST 22: sort exist.txt 		<-- [specialchar][big case][small case][number]			[normal sort]
	public void testSortExhaustive22() throws Exception{
		createTxtFile("sortExhaustive22.txt",new String[]{"!","#","$","%","A","S","L","O","p","a","l","s","65","32","52","511"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive22.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
				  "32" + NL + "52" + NL + "65"  + NL + "511"+ NL +
			      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
			      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive22.txt"));
	}
	@Test// TEST 23: sort exist.txt 		<-- [specialchar][number][big case][small case]			[normal sort]
	public void testSortExhaustive23() throws Exception{
		createTxtFile("sortExhaustive23.txt",new String[]{"!","#","$","%","65","32","52","511","A","S","L","O","p","a","l","s"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive23.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
				  "32" + NL + "52" + NL + "65"  + NL + "511"+ NL +
			      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
			      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive23.txt"));
	}
	@Test// TEST 24: sort exist.txt 		<-- [specialchar][number][small case][big case]			[normal sort]
	public void testSortExhaustive24() throws Exception{
		createTxtFile("sortExhaustive24.txt",new String[]{"!","#","$","%","65","32","52","511","p","a","l","s","A","S","L","O"});//createTxtFile(fileName,content[])
		sortApp.run(new String[]{"sortExhaustive24.txt -n"}, null, testOut);
		assertEquals( "!" + NL + "#"  + NL + "$"   + NL + "%" + NL +
				  "32" + NL + "52" + NL + "65"  + NL + "511"+ NL +
			      "A" + NL + "L"  + NL + "O"   + NL + "S"  + NL +
			      "a" + NL + "l"  + NL + "p"   + NL + "s" , testOut.toString() );
		listOfPaths.add(FileSystems.getDefault().getPath(Environment.currentDirectory, "sortExhaustive24.txt"));
	}
	@BeforeClass
    public static void setUpOnce() {
        sortApp = new SortApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }
	private void createTxtFile(String fileName, String[] txtFileLines) throws UnsupportedEncodingException, FileNotFoundException, IOException {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(
	         	new FileOutputStream(fileName), "utf-8"))) {
				for(int x=0; x < txtFileLines.length ;x++){
					writer.write(txtFileLines[x]);
					if(x+1!=txtFileLines.length)
					{
				        writer.write(System.lineSeparator());
					}
				}
	        }
	}
	private static void resetAndDeleteFile(Path oldPath) {
		sortApp = new SortApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
		try {
            Files.deleteIfExists(oldPath);
        } catch (Exception e) {
            e.printStackTrace();
        }	
	}
}
