package ef2.unit;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFileAttributes;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.exception.CatException;
import sg.edu.nus.comp.cs4218.impl.app.CatApplication;

public class TestCatApplication {
    static CatApplication catApp;
    static ByteArrayInputStream testIn;
    static ByteArrayOutputStream testOut;
    static final String NL = System.getProperty("line.separator");
    
    static int n = 2; //Any n >= 2: Create n files for testing purposes.
    
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();
    
    @Test
    public void testCatAllArgsNull() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("Null Pointer Exception");
        catApp.run(null, null, null);
    }
    
    @Test
    public void testCatAllArgsValid() throws CatException {
        testIn = new ByteArrayInputStream(("some text" + NL).getBytes());
        catApp.run(new String[] { "test1.txt" }, testIn, testOut);
        assertEquals("test1" + NL + "test1", testOut.toString());
    }
    
    @Test
    public void testCatArgNull() throws CatException {
        testIn = new ByteArrayInputStream(("some text" + NL).getBytes());
        catApp.run(null, testIn, testOut);
        assertEquals("some text" + NL, testOut.toString());
    }
    
    @Test
    public void testCatArgEmpty() throws CatException {
        testIn = new ByteArrayInputStream(("some text" + NL).getBytes());
        catApp.run(new String[] {}, testIn, testOut);
        assertEquals("some text" + NL, testOut.toString());
    }
    
    @Test
    public void testCatArgsAndStdOutNull() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("Null Pointer Exception");
        testIn = new ByteArrayInputStream(("some text" + NL).getBytes());
        catApp.run(null, testIn, null);
    }
    
    @Test
    public void testCatArgsAndStdInNull() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("Null Pointer Exception");
        catApp.run(null, null, testOut);
    }
    
    @Test
    public void testCatSingleArgValid() throws CatException {
        catApp.run(new String[] { "test1.txt" }, null, testOut);
        assertEquals("test1" + NL + "test1", testOut.toString());
    }
    
    @Test
    public void testCatSingleArgWithSpaceValid() throws CatException {
        catApp.run(new String[] { "\"test test.txt\"" }, null, testOut);
        assertEquals("test test" + NL, testOut.toString());
    }
    
    @Test
    public void testCatSingleArgInvalid() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("Invalid file path");
        catApp.run(new String[] { "|\'\"" }, null, testOut);
    }
    
    @Test
    public void testCatSingleArgWithInvalidSyntax() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("Invalid file path");
        catApp.run(new String[] { "\"test test\".txt" }, null, testOut);
    }
    
    @Test
    public void testCatSingleArgUnreadable() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("Could not read file");
        catApp.run(new String[] { "unreadable.txt" }, null, testOut);
    }
    
    @Test
    public void testCatSingleArgInvalidDir() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("This is a directory");
        catApp.run(new String[] { File.separator }, null, testOut);
    }
    
    @Test
    public void testCatSingleArgSpaces() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("Invalid file path");
        catApp.run(new String[] { "   " }, null, testOut);
    }
    
    @Test
    public void testCatMultipleArgsValid() throws CatException {
        catApp.run(new String[] { "test1.txt", "test2.txt" }, null, testOut);
        assertEquals("test1" + NL + "test1test2" + NL + "test2", testOut.toString());
    }
    
    @Test
    public void testCatMultipleArgsMultipleWordsSingleQuoted() throws CatException {
        catApp.run(new String[] { "\'test test.txt\'", "\'test test.txt\'" }, null, testOut);
        assertEquals("test test" + NL + "test test" + NL, testOut.toString());
    }
    
    @Test
    public void testCatMultipleArgsMultipleWordsDoubleQuoted() throws CatException {
        catApp.run(new String[] { "\"test test.txt\"", "\"test test.txt\"" }, null, testOut);
        assertEquals("test test" + NL + "test test" + NL, testOut.toString());
    }
    
    @Test
    public void testCatMultipleArgsInvalid() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("Invalid file path");
        catApp.run(new String[] { "|", "|" }, null, testOut);
    }
    
    @Test
    public void testCatMultipleArgsValidAndInvalid() throws CatException {
        expectedEx.expect(CatException.class);
        expectedEx.expectMessage("Invalid file path");
        catApp.run(new String[] { "test1.txt", "|" }, null, testOut);
    }
    
    @BeforeClass
    public static void setUpOnce() {
        catApp = new CatApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
        
        createFiles(n);
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
        deleteFiles();
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        if (testIn != null) {
            testIn.reset();
        }
        testOut.reset();
    }
    
    private static void createFiles(int n) {
        //Create n files for testing
        for (int i = 1; i <= n; i++) {
            try {
                PrintWriter writer = new PrintWriter("test" + i + ".txt");  // File contents:
                writer.println("test" + i);                                 // test 1 (new line)
                writer.print("test" + i);                                   // test 1 (No new line)
                writer.close();
            } catch (IOException ioe) {
               try {
                   File file = new File("test" + i + ".txt");
                   file.delete();
               } catch (Exception e) {
                   e.printStackTrace();
               }
            }
        }
        
        //Create file with space in name
        try {
            PrintWriter writer = new PrintWriter("test test.txt");  // File contents:
            writer.println("test test");                            // test test
            writer.close();
        } catch (IOException ioe) {
            try {
                File file = new File("test test.txt");
                file.delete();
            } catch (Exception e) {
                e.printStackTrace();
            }
         }
        
        //Create an unreadable text file
        try {
            PrintWriter writer = new PrintWriter("unreadable.txt");  
            writer.println("unreadable text");                                                             
            writer.close();
            
            Path path = Paths.get("unreadable.txt");
            PosixFileAttributeView view = Files.getFileAttributeView(path, PosixFileAttributeView.class);

            PosixFileAttributes attributes = view.readAttributes();
            Set<PosixFilePermission> permissions = attributes.permissions();
            permissions.remove(PosixFilePermission.OWNER_READ);
            view.setPermissions(permissions);
        } catch (Exception ioe) {
           try {
               File file = new File("unreadable.txt");
               file.delete();
           } catch (Exception e) {
               e.printStackTrace();
           }
        }
    }
    
    private static void deleteFiles() {
        //Delete n files that were created for testing
        for (int i = 1; i <= n; i++) {
            try {
                File file = new File("test" + i + ".txt");
                file.delete();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        //Delete test file with space in name
        try {
            File file = new File("test test.txt");
            file.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        //Delete unreadable file
        try {
            File file = new File("unreadable.txt");
            file.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
