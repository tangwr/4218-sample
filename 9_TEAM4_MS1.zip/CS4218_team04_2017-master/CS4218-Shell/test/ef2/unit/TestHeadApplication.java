/**
 * 
 */
package ef2.unit;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sg.edu.nus.comp.cs4218.exception.HeadException;
import sg.edu.nus.comp.cs4218.impl.app.HeadApplication;

/**
 * @author pixelducky
 *
 */
public class TestHeadApplication {
	private static HeadApplication headApp;
	private static PrintStream stdout;
	private static ByteArrayInputStream stdin;
	private static ByteArrayOutputStream baos;
	private static final String NEWLINE = System.getProperty("line.separator");

	private static final String FOUR_LINES = "line 1" + NEWLINE + "line 2" + NEWLINE + "line 3" + NEWLINE + "line 4";
	private static final String TEN_LINES = FOUR_LINES + NEWLINE + "line 5" + NEWLINE + "line 6" + NEWLINE + "line 7"
			+ NEWLINE + "line 8" + NEWLINE + "line 9" + NEWLINE + "line 10";
	private static final String THIRTEEN_LINES = TEN_LINES + NEWLINE + "line 11" + NEWLINE + "line 12" + NEWLINE
			+ "line 13";
	private static final String FILENAME_1 = "testHeadDefaultLineCountsWithFile";
	private static final String FILENAME_2 = "testHeadSpecifiedLineCountsWithFile";
	private static final String FILENAME_3 = "testHeadSpecifiedLineCountsWithInvalidFile";
	private static final String FILENAME_4 = "noSuchFile";

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpOnce() throws Exception {
		headApp = new HeadApplication();
		baos = new ByteArrayOutputStream();
		stdout = new PrintStream(baos);
		System.setIn(stdin);
		System.setOut(stdout);
		deleteAllFiles();
	}

	private static void deleteAllFiles() {
		try {
			Files.delete(Paths.get(FILENAME_1));
			Files.delete(Paths.get(FILENAME_2));
			Files.delete(Paths.get(FILENAME_3));
		} catch (IOException e) {
		}
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownOnce() throws Exception {
		System.setOut(null);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		// create file with 13 lines
		createFile(FILENAME_1, TEN_LINES);
		createFile(FILENAME_2, THIRTEEN_LINES);
		createFile(FILENAME_3, "unreadable text");
		baos.reset();
	}

	private void createFile(String name, String data) throws FileNotFoundException {
		PrintWriter writer = new PrintWriter(name);
		writer.print(data);
		writer.close();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		deleteAllFiles();
	}

	@Test
	public void testHeadNullStandardStreams() {
		try {
			headApp.run(null, null, null);
		} catch (HeadException e) {
			assertEquals("head: stdin is null | stdout is null", e.getMessage());
		}
	}

	// Boundary values
	@Test
	public void testHeadNoArgs1() {
		try {
			stdin = new ByteArrayInputStream(FOUR_LINES.getBytes());
			headApp.run(null, stdin, stdout);
			assertEquals(FOUR_LINES, baos.toString());
		} catch (HeadException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testHeadNoArgs2() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			headApp.run(null, stdin, stdout);
			assertEquals(TEN_LINES, baos.toString());
		} catch (HeadException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testHeadNoArgs3() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			headApp.run(null, stdin, stdout);
			assertEquals(TEN_LINES, baos.toString());
		} catch (HeadException e) {
			e.printStackTrace();
		}

	}

	// Boundary Values
	@Test
	public void testHeadSpecifiedLineCountsWithoutFile1() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			headApp.run(new String[] { "-n", "10" }, stdin, stdout);
			assertEquals(TEN_LINES, baos.toString());
		} catch (HeadException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testHeadSpecifiedLineCountsWithoutFile2() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			headApp.run(new String[] { "-n", "13" }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (HeadException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testHeadSpecifiedLineCountsWithoutFile3() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			headApp.run(new String[] { "-n", "14" }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (HeadException e) {
			e.printStackTrace();
		}
	}

	// Boundary Values
	@Test
	public void testHeadIllegalLineCountsWithoutFile1() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			headApp.run(new String[] { "-n", "0" }, stdin, stdout);
		} catch (HeadException e) {
			assertEquals("head: illegal line count -- 0", e.getMessage());
		}
	}

	@Test
	public void testHeadIllegalLineCountsWithoutFile2() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			headApp.run(new String[] { "-n", "-0" }, stdin, stdout);
		} catch (HeadException e) {
			assertEquals("head: illegal line count -- -0", e.getMessage());
		}
	}

	@Test
	public void testHeadIllegalLineCountsWithoutFile3() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			headApp.run(new String[] { "-n", "-1" }, stdin, stdout);
		} catch (HeadException e) {
			assertEquals("head: illegal line count -- -1", e.getMessage());
		}
	}

	@Test
	public void testHeadIllegalLineCountsWithoutFile4() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			headApp.run(new String[] { "-n", "a" }, stdin, stdout);
		} catch (HeadException e) {
			assertEquals("head: illegal line count -- a", e.getMessage());
		}
	}

	@Test
	public void testHeadIllegalLineCountsWithoutFile5() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			headApp.run(new String[] { "-n", "a1" }, stdin, stdout);
		} catch (HeadException e) {
			assertEquals("head: illegal line count -- a1", e.getMessage());
		}
	}

	@Test
	public void testHeadDefaultLineCountsWithFile() {
		try {
			headApp.run(new String[] { FILENAME_1 }, stdin, stdout);
			assertEquals(TEN_LINES, baos.toString());
		} catch (HeadException he) {
			he.printStackTrace();
		}
	}

	// Boundary Values
	@Test
	public void testHeadSpecifiedLineCountsWithFile1() {
		try {
			headApp.run(new String[] { "-n", "10", FILENAME_2 }, stdin, stdout);
			assertEquals(TEN_LINES, baos.toString());
		} catch (HeadException he) {
			he.printStackTrace();
		}
	}

	@Test
	public void testHeadSpecifiedLineCountsWithFile2() {
		try {
			headApp.run(new String[] { "-n", "13", FILENAME_2 }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (HeadException he) {
			he.printStackTrace();
		}
	}

	@Test
	public void testHeadSpecifiedLineCountsWithFile3() {
		try {
			headApp.run(new String[] { "-n", "14", FILENAME_2 }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (HeadException he) {
			he.printStackTrace();
		}
	}

	@Test
	public void testHeadIllegalLineCountsWithFile1() {
		try {
			headApp.run(new String[] { "-n", "-0", FILENAME_2 }, stdin, stdout);
		} catch (HeadException he) {
			assertEquals("head: illegal line count -- -0", he.getMessage());
		}
	}

	@Test
	public void testHeadIllegalLineCountsWithFile2() {
		try {
			headApp.run(new String[] { "-n", "-1", FILENAME_2 }, stdin, stdout);
		} catch (HeadException he) {
			assertEquals("head: illegal line count -- -1", he.getMessage());
		}
	}

	@Test
	public void testHeadIllegalLineCountsWithFile3() {
		try {
			headApp.run(new String[] { "-n", "a", FILENAME_2 }, stdin, stdout);
		} catch (HeadException he) {
			assertEquals("head: illegal line count -- a", he.getMessage());
		}
	}

	@Test
	public void testHeadIllegalLineCountsWithFile4() {
		try {
			headApp.run(new String[] { "-n", "a1", FILENAME_2 }, stdin, stdout);
		} catch (HeadException he) {
			assertEquals("head: illegal line count -- a1", he.getMessage());
		}
	}

	@Test
	public void testHeadSpecifiedLineCountsWithInvalidFile1() throws IOException {
		try {
			File file = new File(FILENAME_3);
			file.setReadable(false);
			
			headApp.run(new String[] { "-n", "1", FILENAME_3 }, stdin, stdout);
		} catch (HeadException he) {
			assertEquals("head: " + FILENAME_3 + ": Permission denied", he.getMessage());
		}
	}

	@Test
	public void testHeadSpecifiedLineCountsWithInvalidFile2() {
		try {
			headApp.run(new String[] { "-n", "1", FILENAME_4 }, stdin, stdout);
		} catch (HeadException he) {
			assertEquals("head: " + FILENAME_4 + ": No such file or directory", he.getMessage());
		}
	}
}
