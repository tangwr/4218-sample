/**
 * 
 */
package ef2.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFileAttributes;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sg.edu.nus.comp.cs4218.exception.HeadException;
import sg.edu.nus.comp.cs4218.exception.TailException;
import sg.edu.nus.comp.cs4218.impl.app.TailApplication;

/**
 * @author pixelducky
 *
 */
public class TestTailApplication {
	private static TailApplication tailApp;
	private static PrintStream stdout;
	private static ByteArrayInputStream stdin;
	private static ByteArrayOutputStream baos;
	private static final String NEWLINE = System.getProperty("line.separator");

	private static final String FOUR_LINES = "line 1" + NEWLINE + "line 2" + NEWLINE + "line 3" + NEWLINE + "line 4";
	private static final String TEN_LINES = FOUR_LINES + NEWLINE + "line 5" + NEWLINE + "line 6" + NEWLINE + "line 7"
			+ NEWLINE + "line 8" + NEWLINE + "line 9" + NEWLINE + "line 10";
	private static final String THIRTEEN_LINES = TEN_LINES + NEWLINE + "line 11" + NEWLINE + "line 12" + NEWLINE
			+ "line 13";
	
	private static final String TRUNCATED_LINES = "line 4" + NEWLINE + "line 5" + NEWLINE + "line 6" + NEWLINE + "line 7"
			+ NEWLINE + "line 8" + NEWLINE + "line 9" + NEWLINE + "line 10" + NEWLINE + "line 11" + NEWLINE + "line 12"
			+ NEWLINE + "line 13";

	private static final String FILENAME_1 = "testTailDefaultLineCountsWithFile"; 
	private static final String FILENAME_2 = "testTailSpecifiedLineCountsWithFile";
	private static final String FILENAME_3 = "testTailSpecifiedLineCountsWithInvalidFile";
	private static final String FILENAME_4 = "noSuchFile";

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpOnce() throws Exception {
		tailApp = new TailApplication();
		baos = new ByteArrayOutputStream();
		stdout = new PrintStream(baos);
		System.setIn(stdin);
		System.setOut(stdout);
		deleteAllFiles();
	}

	private static void deleteAllFiles() {
		try {
			Files.delete(Paths.get(FILENAME_1));
			Files.delete(Paths.get(FILENAME_2));
			Files.delete(Paths.get(FILENAME_3));
		} catch (IOException e) {
		}
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownOnce() throws Exception {
		System.setOut(null);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		// create file with 13 lines
		createFile(FILENAME_1, THIRTEEN_LINES);
		createFile(FILENAME_2, THIRTEEN_LINES);
		createFile(FILENAME_3, "unreadable text");
		baos.reset();
	}

	private void createFile(String name, String data) throws FileNotFoundException {
		PrintWriter writer = new PrintWriter(name);
		writer.print(data);
		writer.close();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		deleteAllFiles();
	}

	@Test
	public void testTailNullStandardStreams() {
		try {
			tailApp.run(null, null, null);
		} catch (TailException e) {
			assertEquals("tail: stdin is null | stdout is null", e.getMessage());
		}
	}

	// Boundary values
	@Test
	public void testTailNoArgs1() {
		try {
			stdin = new ByteArrayInputStream(FOUR_LINES.getBytes());
			tailApp.run(null, stdin, stdout);
			assertEquals(FOUR_LINES, baos.toString());
		} catch (TailException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testTailNoArgs2() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			tailApp.run(null, stdin, stdout);
			assertEquals(TEN_LINES, baos.toString());
		} catch (TailException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testTailNoArgs3() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			tailApp.run(null, stdin, stdout);
			assertEquals(TRUNCATED_LINES, baos.toString());
		} catch (TailException e) {
			e.printStackTrace();
		}

	}

	// Boundary Values
	@Test
	public void testTailSpecifiedLineCountsWithoutFile1() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			tailApp.run(new String[] { "-n", "-13" }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (TailException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithoutFile2() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			tailApp.run(new String[] { "-n", "-14" }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (TailException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithoutFile3() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			tailApp.run(new String[] { "-n", "10" }, stdin, stdout);
			assertEquals(TRUNCATED_LINES, baos.toString());
		} catch (TailException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithoutFile4() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			tailApp.run(new String[] { "-n", "13" }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (TailException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithoutFile5() {
		try {
			stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
			tailApp.run(new String[] { "-n", "14" }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (TailException e) {
			e.printStackTrace();
		}
	}

	// Boundary Values
	@Test
	public void testTailIllegalOffsetWithoutFile1() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			tailApp.run(new String[] { "-n", "-0" }, stdin, stdout);
		} catch (TailException e) {
			assertEquals("tail: illegal offset -- -0", e.getMessage());
		}
	}
	
	@Test
	public void testTailIllegalOffsetWithoutFile2() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			tailApp.run(new String[] { "-n", "a" }, stdin, stdout);
		} catch (TailException e) {
			assertEquals("tail: illegal offset -- a", e.getMessage());
		}
	}
	
	@Test
	public void testTailIllegalOffsetWithoutFile3() {
		try {
			stdin = new ByteArrayInputStream(TEN_LINES.getBytes());
			tailApp.run(new String[] { "-n", "a1" }, stdin, stdout);
		} catch (TailException e) {
			assertEquals("tail: illegal offset -- a1", e.getMessage());
		}
	}

	@Test
	public void testTailDefaultLineCountsWithFile() {
		try {
			tailApp.run(new String[] { FILENAME_1 }, stdin, stdout);
			assertEquals(TRUNCATED_LINES, baos.toString());
		} catch (TailException he) {
			he.printStackTrace();
		}

	}

	// Boundary Values
	@Test
	public void testTailSpecifiedLineCountsWithFile1() {
		try {
			tailApp.run(new String[] { "-n", "-13", FILENAME_2 }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (TailException he) {
			he.printStackTrace();
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithFile2() {
		try {
			tailApp.run(new String[] { "-n", "-14", FILENAME_2 }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (TailException he) {
			he.printStackTrace();
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithFile3() {
		try {
			tailApp.run(new String[] { "-n", "10", FILENAME_2 }, stdin, stdout);
			assertEquals(TRUNCATED_LINES, baos.toString());
		} catch (TailException he) {
			he.printStackTrace();
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithFile4() {
		try {
			tailApp.run(new String[] { "-n", "13", FILENAME_2 }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (TailException he) {
			he.printStackTrace();
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithFile5() {
		try {
			tailApp.run(new String[] { "-n", "14", FILENAME_2 }, stdin, stdout);
			assertEquals(THIRTEEN_LINES, baos.toString());
		} catch (TailException he) {
			he.printStackTrace();
		}
	}

	@Test
	public void testTailIllegalOffsetWithFile1() {
		try {
			tailApp.run(new String[] { "-n", "-0", FILENAME_2 }, stdin, stdout);
		} catch (TailException he) {
			assertEquals("tail: illegal line count -- -0", he.getMessage());
		}
	}

	@Test
	public void testTailIllegalOffsetWithFile2() {
		try {
			baos.reset();
			tailApp.run(new String[] { "-n", "a", FILENAME_2 }, stdin, stdout);
		} catch (TailException he) {
			assertEquals("tail: illegal offset -- a", he.getMessage());
		}
	}

	@Test
	public void testTailIllegalOffsetWithFile3() {
		try {
			baos.reset();
			tailApp.run(new String[] { "-n", "a1", FILENAME_2 }, stdin, stdout);
		} catch (TailException he) {
			assertEquals("tail: illegal offset -- a1", he.getMessage());
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithInvalidFile1() throws IOException {
		try {
			File file = new File(FILENAME_3);
			file.setReadable(false);
			
			tailApp.run(new String[] { "-n", "1", FILENAME_3 }, stdin, stdout);
		} catch (TailException he) {
			assertEquals("tail: " + FILENAME_3 + ": Permission denied", he.getMessage());
		}
	}

	@Test
	public void testTailSpecifiedLineCountsWithInvalidFile2() {
		try {
			tailApp.run(new String[] { "-n", "1", FILENAME_4 }, stdin, stdout);
		} catch (TailException he) {
			assertEquals("tail: " + FILENAME_4 + ": No such file or directory", he.getMessage());
		}
	}
}
