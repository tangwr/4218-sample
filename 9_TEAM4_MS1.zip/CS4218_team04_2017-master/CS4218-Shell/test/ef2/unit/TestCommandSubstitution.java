package ef2.unit;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestCommandSubstitution {
    static ShellImpl shell;
    static final String NEW_LINE = System.getProperty("line.separator");
    
    static int n = 2; //Any n >= 2: Create n files for testing purposes.
    
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();
    
    @Test
    public void testValidEchoCommandSubstitution() throws AbstractApplicationException, ShellException {
        String command = shell.performCommandSubstitution("cat `echo test1.txt` test2.txt");
        assertEquals("cat test1.txt test2.txt", command);
    }
    
    @Test
    public void testMultipleValidEchoCommandSubstitutionDoubleQuoted() throws AbstractApplicationException, ShellException {
        String command = shell.performCommandSubstitution("echo \"this is space `echo \"nbsp\"` and `echo \"2nd space\"`\"");
        assertEquals("echo \"this is space nbsp and 2nd space\"", command);
    }
    
    @Test
    public void testMultipleValidEchoCommandSubstitutionSingleQuoted() throws AbstractApplicationException, ShellException {
        String command = shell.performCommandSubstitution("echo 'this is space `echo \"nbsp\"` and `echo \"2nd space\"`'");
        assertEquals("echo 'this is space `echo \"nbsp\"` and `echo \"2nd space\"`'", command);
    }
    
    @Test
    public void testValidCatCommandSubstitution() throws AbstractApplicationException, ShellException {
        String command = shell.performCommandSubstitution("echo `cat test1.txt` test2.txt");
        assertEquals("echo test1test1 test2.txt", command);
    }
    
    @Test
    public void testMultipleValidCatCommandSubstitutionDoubleQuoted() throws AbstractApplicationException, ShellException {
        String command = shell.performCommandSubstitution("echo \"this is space `cat test1.txt` and `cat test2.txt`\"");
        assertEquals("echo \"this is space test1test1 and test2test2\"", command);
    }
    
    @Test
    public void testMultipleValidCatCommandSubstitutionSingleQuoted() throws AbstractApplicationException, ShellException {
        String command = shell.performCommandSubstitution("echo 'this is space `cat test1.txt` and `cat test2.txt`'");
        assertEquals("echo 'this is space `cat test1.txt` and `cat test2.txt`'", command);
    }
    
    @Test
    public void testInvalidCommandSubstitution() throws AbstractApplicationException, ShellException {
        String command = shell.performCommandSubstitution("cat `invalid_command` test2.txt");
        assertEquals("cat shell: invalid_command: Invalid app. test2.txt", command);
    }
    
    @Test
    public void testMultipleInvalidCommandSubstitution() throws AbstractApplicationException, ShellException {
        String command = shell.performCommandSubstitution("cat `invalid_command` `invalid_command`");
        assertEquals("cat shell: invalid_command: Invalid app. shell: invalid_command: Invalid app.", command);
    }
    
    @Test
    public void testValidCommandSubstitutionEmptyBackQuotes() throws AbstractApplicationException, ShellException {
        String command = shell.performCommandSubstitution("cat `` test2.txt");
        assertEquals("cat  test2.txt", command);
    }
    
    @BeforeClass
    public static void setUpOnce() {
        shell = new ShellImpl();
        createFiles(n);
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
        deleteFiles();
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    private static void createFiles(int n) {
        //Create n files for testing
        for (int i = 1; i <= n; i++) {
            try {
                PrintWriter writer = new PrintWriter("test" + i + ".txt");  // File contents:
                writer.println("test" + i);                                 // test 1 (new line)
                writer.print("test" + i);                                   // test 1 (No new line)
                writer.close();
            } catch (IOException ioe) {
               try {
                   File file = new File("test" + i + ".txt");
                   file.delete();
               } catch (Exception e) {
                   e.printStackTrace();
               }
            }
        }
    }
    
    private static void deleteFiles() {
        //Delete n files that were created for testing
        for (int i = 1; i <= n; i++) {
            try {
                File file = new File("test" + i + ".txt");
                file.delete();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
