package ef2.unit;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import sg.edu.nus.comp.cs4218.exception.DateException;
import sg.edu.nus.comp.cs4218.impl.app.DateApplication;

public class TestDateApplication {

	private static ByteArrayOutputStream result;
	private static final String NL = System.getProperty("line.separator");
	private static DateApplication dateApp;
	private String date;
	
	@BeforeClass
	public static void setUpOnce() {
		dateApp = new DateApplication();
		result = new ByteArrayOutputStream();
		System.setOut(new PrintStream(result));
	}

	@AfterClass
	public static void tearDownOnce() {
        System.setOut(null);
	}

	@After
	public void tearDown() {
		result.reset();
	}

	@Test
	public void testDateWithArgs() throws DateException {
		date = Calendar.getInstance().getTime().toString();
		dateApp.run(new String[] {"not", "that", "it", "matters"}, null, result);
		assertEquals(date + NL, result.toString());
	}
	
	@Test
	public void testDateWithoutArgs() throws DateException {
		date = Calendar.getInstance().getTime().toString();
		dateApp.run(new String[] {}, null, result);
		assertEquals(date + NL, result.toString());
	}
}
