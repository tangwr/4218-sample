package ef2.unit;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.exception.EchoException;
import sg.edu.nus.comp.cs4218.impl.app.EchoApplication;

public class TestEchoApplication {
    static EchoApplication echoApp;
    static ByteArrayOutputStream testOut;
    static final String NEW_LINE = System.getProperty("line.separator");
    
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();
    
    @Test
    public void testEchoAllArgsNull() throws EchoException {
        expectedEx.expect(EchoException.class);
        expectedEx.expectMessage("Null arguments");
        echoApp.run(null, null, null);
    }
    
    @Test
    public void testEchoStdOutNull() throws EchoException {
        expectedEx.expect(EchoException.class);
        expectedEx.expectMessage("OutputStream not provided");
        echoApp.run(new String[] { "some text" }, null, null);
    }
    
    @Test
    public void testEchoArgLengthZero() throws EchoException {
        echoApp.run(new String[] { }, null, testOut);
        assertEquals(NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoArgSpaces() throws EchoException {
        echoApp.run(new String[] { "   " }, null, testOut);
        assertEquals("   " + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoSingleArgSingleWord() throws EchoException {
        echoApp.run(new String[] { "test" }, null, testOut);
        assertEquals("test" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoSingleArgMultipleWords() throws EchoException {
        echoApp.run(new String[] { "some text" }, null, testOut);
        assertEquals("some text" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoMultipleArgsSingleWord() throws EchoException {
        echoApp.run(new String[] { "some", "text" }, null, testOut);
        assertEquals("some text" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoMultipleArgsMultipleWords() throws EchoException {
        echoApp.run(new String[] { "a b", "c d" }, null, testOut);
        assertEquals("a b c d" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoMultipleArgsMultipleWordsSingleQuoted() throws EchoException {
        echoApp.run(new String[] { "\'a b\'", "\'c d\'" }, null, testOut);
        assertEquals("'a b' 'c d'" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoMultipleArgsMultipleWordsDoubleQuoted() throws EchoException {
        echoApp.run(new String[] { "\"a b\"", "\"c d\"" }, null, testOut);
        assertEquals("\"a b\" \"c d\"" + NEW_LINE, testOut.toString());
    }
    
    @BeforeClass
    public static void setUpOnce() {
        echoApp = new EchoApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        testOut.reset();
    }
}
