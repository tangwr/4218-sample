/**
 * 
 */
package ef2.unit;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.exception.WcException;
import sg.edu.nus.comp.cs4218.impl.app.WcApplication;

/**
 * @author pixelducky
 *
 */
public class TestWcApplication {

	private static final String STRING_EXCEPTION_HEADER = "wc: %s";
	private static final String STRING_STANDARD_STREAMS_IS_NULL = String.format(STRING_EXCEPTION_HEADER,
			"stdin is null | stdout is null");
	private static final String STRING_STDOUT_IS_NULL = String.format(STRING_EXCEPTION_HEADER,
			"stdout is null");
	private static final String STRING_NO_SUCH_FILE_OR_DIRECTORY = String.format(STRING_EXCEPTION_HEADER,
			"%s: open: No such file or directory");
	private static final String STRING_IS_A_DIRECTORY = String.format(STRING_EXCEPTION_HEADER,
			"%s: read: Is a directory");
	private static final String STRING_PERMISSION_DENIED = String.format(STRING_EXCEPTION_HEADER,
			"%s: open: Permission denied");
	private static final String STRING_ILLEGAL_OPTION = String.format(STRING_EXCEPTION_HEADER, "illegal option -- %s");
	private static final String STRING_USAGE = String.format(STRING_EXCEPTION_HEADER, "usage: wc [-lmw] [file ...]");
	private static final String NEWLINE = System.getProperty("line.separator");
	private static final String TAB = "\t";
	private static final String COMMAND_WC = "wc";
	private static final String HYPHEN = "-";
	private static final String WHITESPACE = " ";
	private static final String OPTION_LINE_COUNT = HYPHEN + "l";
	private static final String OPTION_WORD_COUNT = HYPHEN + "w";
	private static final String OPTION_CHARACTER_COUNT = HYPHEN + "m";
	private static final String OPTIONS_DEFAULT = OPTION_LINE_COUNT + WHITESPACE + OPTION_WORD_COUNT + WHITESPACE
			+ OPTION_CHARACTER_COUNT;

	private static final String ONE_CHAR = "a";
	private static final String ONE_WORD = "line";
	private static final String FOUR_LINES = "line 1" + NEWLINE + "line 2" + NEWLINE + "line 3" + NEWLINE + "line 4";
	private static final String TEN_LINES = FOUR_LINES + NEWLINE + "line 5" + NEWLINE + "line 6" + NEWLINE + "line 7"
			+ NEWLINE + "line 8" + NEWLINE + "line 9" + NEWLINE + "line 10";
	private static final String THIRTEEN_LINES = TEN_LINES + NEWLINE + "line 11" + NEWLINE + "line 12" + NEWLINE
			+ "line 13";

	private static final String RESULT_THIRTEENLINES = "\t12\t26\t94";
	private static final String RESULT_THIRTEENLINES_WITH_FILENAME = "\t12\t26\t94 %s";
	private static final String RESULT_MULTIPLE_FILES = "\t1\t1\t1 %s" + NEWLINE + "\t1\t1\t4 %s" + NEWLINE
			+ "\t12\t26\t94 %s" + NEWLINE + "\t14\t28\t99 total";

	private static WcApplication wcApp;
	private static PrintStream stdout;
	private static ByteArrayInputStream stdin;
	private static ByteArrayOutputStream baos;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpOnce() throws Exception {
		wcApp = new WcApplication();
		baos = new ByteArrayOutputStream();
		stdout = new PrintStream(baos);
		System.setIn(stdin);
		System.setOut(stdout);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownOnce() throws Exception {
		System.setOut(null);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		wcApp = new WcApplication();
		baos.reset();
		thrownException = ExpectedException.none();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Rule
	public ExpectedException thrownException = ExpectedException.none();

	@Rule
	public ErrorCollector collector = new ErrorCollector();

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printNewlineCountInFile(java.lang.String)}.
	 */

	@Test
	public void testPrintNewlineCountInFileWithManyLines() {
		String fileName = "testPrintNewlineCountInFileWithManyLines";
		String command = fileName;
		collector.checkThat(true, equalTo(createFile(fileName, THIRTEEN_LINES)));
		collector.checkThat(wcApp.printNewlineCountInFile(command), equalTo("\t12 " + fileName));
		collector.checkThat(true, equalTo(deleteFile(fileName)));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printWordCountInFile(java.lang.String)}.
	 */
	@Test
	public void testPrintWordCountInFileWithManyLines() {
		String fileName = "testPrintWordCountInFileWithManyLines";
		String command = fileName;
		collector.checkThat(true, equalTo(createFile(fileName, THIRTEEN_LINES)));
		collector.checkThat(wcApp.printWordCountInFile(command), equalTo("\t26 " + fileName));
		collector.checkThat(true, equalTo(deleteFile(fileName)));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printCharacterCountInFile(java.lang.String)}.
	 */
	@Test
	public void testPrintCharacterCountInFileWithManyLines() {
		String fileName = "testPrintCharacterCountInFileWithManyLines";
		String command = fileName;
		collector.checkThat(true, equalTo(createFile(fileName, THIRTEEN_LINES)));
		collector.checkThat(wcApp.printCharacterCountInFile(command), equalTo("\t94 " + fileName));
		collector.checkThat(true, equalTo(deleteFile(fileName)));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printAllCountsInFile(java.lang.String)}.
	 */
	@Test
	public void testPrintAllCountsInFileWithManyLines() {
		String fileName = "testPrintAllCountsInFileWithManyLines";
		String command = fileName;
		collector.checkThat(true, equalTo(createFile(fileName, THIRTEEN_LINES)));
		collector.checkThat(wcApp.printAllCountsInFile(command), equalTo(RESULT_THIRTEENLINES + WHITESPACE + fileName));
		collector.checkThat(true, equalTo(deleteFile(fileName)));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printNewlineCountInFile(java.lang.String)}.
	 */

	@Test
	public void testPrintNewlineCountInFileWithSingleCharacter() {
		String fileName = "testPrintNewlineCountInFileWithSingleCharacter";
		String command = fileName;
		collector.checkThat(true, equalTo(createFile(fileName, ONE_CHAR)));
		collector.checkThat(wcApp.printNewlineCountInFile(command), equalTo("\t1 " + fileName));
		collector.checkThat(true, equalTo(deleteFile(fileName)));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printWordCountInFile(java.lang.String)}.
	 */
	@Test
	public void testPrintWordCountInFileWithSingleCharacter() {
		String fileName = "testPrintWordCountInFileWithSingleCharacter";
		String command = fileName;
		collector.checkThat(true, equalTo(createFile(fileName, ONE_CHAR)));
		collector.checkThat(wcApp.printWordCountInFile(command), equalTo("\t1 " + fileName));
		collector.checkThat(true, equalTo(deleteFile(fileName)));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printCharacterCountInFile(java.lang.String)}.
	 */
	@Test
	public void testPrintCharacterCountInFileWithSingleCharacter() {
		String fileName = "testPrintCharacterCountInFileWithSingleCharacter";
		String command = fileName;
		collector.checkThat(true, equalTo(createFile(fileName, ONE_CHAR)));
		collector.checkThat(wcApp.printCharacterCountInFile(command), equalTo("\t1 " + fileName));
		collector.checkThat(true, equalTo(deleteFile(fileName)));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printAllCountsInFile(java.lang.String)}.
	 */
	@Test
	public void testPrintAllCountsInFileWithSingleCharacter() {
		String fileName = "testPrintAllCountsInFileWithSingleCharacter";
		String command = fileName;
		collector.checkThat(true, equalTo(createFile(fileName, ONE_CHAR)));
		collector.checkThat(wcApp.printAllCountsInFile(command), equalTo("\t1\t1\t1 " + fileName));
		collector.checkThat(true, equalTo(deleteFile(fileName)));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printNewlineCountInStdin(java.lang.String)}.
	 */
	@Test
	public void testPrintNewlineCountInStdinWithManyLines() {
		stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
		String command = OPTION_LINE_COUNT;
		assertEquals("\t12", wcApp.printNewlineCountInStdin(stdin, command));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printWordCountInStdin(java.lang.String)}.
	 */
	@Test
	public void testPrintWordCountInStdinWithManyLines() {
		stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
		String command = OPTION_WORD_COUNT;
		assertEquals("\t26", wcApp.printWordCountInStdin(stdin, command));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printCharacterCountInStdin(java.lang.String)}.
	 */
	@Test
	public void testPrintCharacterCountInStdinWithManyLines() {
		stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
		String command = OPTION_CHARACTER_COUNT;
		assertEquals("\t94", wcApp.printCharacterCountInStdin(stdin, command));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#printAllCountsInStdin(java.lang.String)}.
	 */
	@Test
	public void testprintAllCountsInStdinWithManyLines() {
		stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
		String command = OPTIONS_DEFAULT;

		/**
		 * if testing a file written with vim containing similar string, it will
		 * always result in having an extra new line character due to POSIX
		 * standards
		 */
		assertEquals(RESULT_THIRTEENLINES, wcApp.printAllCountsInStdin(stdin, command));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	@Test //
	public void testWcNullArgsNullStdout() {
		try {
			wcApp.run(null, null, null);
		} catch (WcException e) {
			assertEquals(STRING_STDOUT_IS_NULL, e.getMessage());
		}
		thrownException.expect(WcException.class);
		thrownException.expectMessage(String.format(STRING_EXCEPTION_HEADER, "stdin is null | stdout is null"));
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	@Test // TODO
	public void testWcEmptyArgsNullStdout() {
		String outputMessage = String.format(STRING_EXCEPTION_HEADER, "stdin is null | stdout is null");
		try {
			wcApp.run(new String[] {}, null, null);
		} catch (WcException e) {
			assertEquals(STRING_STDOUT_IS_NULL, e.getMessage());
		}

	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	@Test
	public void testWcNoOptionsNoFile() {
		stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
		String[] arguments = { "" };
		try {
			wcApp.run(arguments, stdin, stdout);
			assertEquals(RESULT_THIRTEENLINES, baos.toString());
		} catch (WcException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	@Test
	public void testWcNoOptionsWithSingleFile() {
		String fileName = "testWcNoOptionsWithSingleFile";
		String[] args = { fileName };

		try {
			collector.checkThat(true, equalTo(createFile(fileName, ONE_CHAR)));
			wcApp.run(args, stdin, stdout);
			collector.checkThat(baos.toString(), equalTo("\t1\t1\t1 " + fileName));
			collector.checkThat(true, equalTo(deleteFile(fileName)));
		} catch (WcException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}

	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	@Test
	public void testWcNoOptionsWithManyFiles() {
		String fileName = "testWcNoOptionsWithManyFiles";
		String fileOne = fileName + "1";
		String fileTwo = fileName + "2";
		String fileThree = fileName + "3";
		String[] args = { fileOne, fileTwo, fileThree };

		try {
			collector.checkThat(true, equalTo(createFile(fileOne, ONE_CHAR)));
			collector.checkThat(true, equalTo(createFile(fileTwo, ONE_WORD)));
			collector.checkThat(true, equalTo(createFile(fileThree, THIRTEEN_LINES)));
			wcApp.run(args, stdin, stdout);
			collector.checkThat(baos.toString(),
					equalTo(String.format(RESULT_MULTIPLE_FILES, fileOne, fileTwo, fileThree)));
			collector.checkThat(true, equalTo(deleteFile(fileOne)));
			collector.checkThat(true, equalTo(deleteFile(fileTwo)));
			collector.checkThat(true, equalTo(deleteFile(fileThree)));
		} catch (WcException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	
	public void testWcNoOptionsWithSingleFileWithoutPermission() {
		String fileName = "testWcNoOptionsWithSingleFileWithoutPermission";
		String outputMessage = String.format(STRING_PERMISSION_DENIED, fileName);
		try {
			collector.checkThat(createFile(fileName, THIRTEEN_LINES), equalTo(true));
			collector.checkThat(setFileWithNoReadAccess(fileName), equalTo(true));
			wcApp.run(new String[] { fileName }, stdin, stdout);

		} catch (WcException e) {
			boolean containsMessage = e.getMessage().contains(outputMessage);
			collector.checkThat(containsMessage, equalTo(true));
		} finally {
			collector.checkThat(true, equalTo(deleteFile(fileName)));
		}

	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	@Test
	public void testWcNoOptionsWithSingleNonExistingFile() throws WcException {
		String fileName = "testWcNoOptionsWithSingleInvalidFile";
		String outputMessage = String.format(STRING_NO_SUCH_FILE_OR_DIRECTORY, fileName);
		try {
			wcApp.run(new String[] { fileName }, stdin, stdout);

		} catch (WcException e) {
			boolean containsMessage = e.getMessage().contains(outputMessage);
			collector.checkThat(containsMessage, equalTo(true));
		}
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	@Test
	public void testWcHasOptionsWithoutFile() {
		stdin = new ByteArrayInputStream(THIRTEEN_LINES.getBytes());
		String[] arguments = { "-l", "-w", "-m" };
		try {
			wcApp.run(arguments, stdin, stdout);
			assertEquals(RESULT_THIRTEENLINES, baos.toString());
		} catch (WcException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	@Test
	public void testWcHasOptionsWithSingleFile() {
		String fileName = "testWcHasOptionsWithSingleFile";
		String outputMessage = String.format(RESULT_THIRTEENLINES_WITH_FILENAME, fileName);
		String[] arguments = { "-l", "-w", "-m", fileName };
		try {
			collector.checkThat(true, equalTo(createFile(fileName, THIRTEEN_LINES)));
			wcApp.run(arguments, stdin, stdout);
			collector.checkThat(baos.toString(), equalTo(outputMessage));
			collector.checkThat(true, equalTo(deleteFile(fileName)));
		} catch (WcException e) {
			// TODO Auto-generated catch block
			fail(e.getMessage());
		}
	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	
	public void testWcHasOptionsWithSingleFileWithoutPermission() throws WcException {
		String fileName = "testWcHasOptionsWithSingleFileWithoutPermission";
		String outputMessage = String.format(STRING_PERMISSION_DENIED, fileName);
		String[] arguments = { "-l", "-w", "-m", fileName };
		try {
			collector.checkThat(true, equalTo(createFile(fileName, THIRTEEN_LINES)));
			collector.checkThat(setFileWithNoReadAccess(fileName), equalTo(true));
			wcApp.run(arguments, stdin, stdout);
			collector.checkThat(baos.toString(), equalTo(outputMessage));
			collector.checkThat(true, equalTo(deleteFile(fileName)));
		} catch (WcException e) {
			// TODO Auto-generated catch block
			collector.checkThat(e.getMessage(), equalTo(outputMessage));
		}

	}

	/**
	 * Test method for
	 * {@link sg.edu.nus.comp.cs4218.impl.app.WcApplication#run(java.lang.String[], java.io.InputStream, java.io.OutputStream)}.
	 */
	public void testWcHasOptionsWithSomeNonExistingFiles() throws WcException {
		fail("Not yet implemented");
	}

	private boolean deleteFile(String fileName) {
		try {
			Files.delete(Paths.get(fileName));
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	private boolean createFile(String fileName, String content) {
		try (PrintWriter writer = new PrintWriter(fileName)) {
			writer.print(content);
			return true;
		} catch (FileNotFoundException fnfe) {
			return false;
		} catch (SecurityException se) {
			return false;
		}
	}

	private boolean setFileWithNoReadAccess(String fileName) {
		Set<PosixFilePermission> permissions = new HashSet<PosixFilePermission>();

		permissions.add(PosixFilePermission.OWNER_WRITE);
		permissions.add(PosixFilePermission.OWNER_EXECUTE);

		permissions.add(PosixFilePermission.GROUP_WRITE);
		permissions.add(PosixFilePermission.GROUP_EXECUTE);

		permissions.add(PosixFilePermission.OTHERS_WRITE);
		permissions.add(PosixFilePermission.OTHERS_EXECUTE);

		try {
			Files.setPosixFilePermissions(Paths.get(fileName), permissions);
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			return false;
		}
	}

}
