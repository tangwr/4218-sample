package ef2.unit;

import static org.junit.Assert.*;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.SedException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;
import sg.edu.nus.comp.cs4218.impl.app.SedApplication;

//Use Java properties "file.separator" and "path.separator" when working with file system. 
//Use �line.separator� property when working with newlines.

public class TestSedApplication {
    static SedApplication sedApp;
    final File homeDirectory = new File(System.getProperty("user.dir"));
    final String strHomeDirectory = System.getProperty("user.home");
    static ByteArrayInputStream testIn;
    static ByteArrayOutputStream testOut;
	static ShellImpl shell;
    static final String NL = System.getProperty("line.separator");
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();
    @Before
    public void setUp() throws Exception {
        sedApp = new SedApplication();
    }
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
        String filename = Environment.currentDirectory+"//"+"hotandsexy.txt";
        if(new File(filename).exists())
        {
            resetAndDeleteFile("hotandsexy.txt");
        }
    }
    @BeforeClass
    public static void setUpOnce() {
        sedApp = new SedApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }
 
    @Test  //TEST :[arg][sed s/[^\n]+/test/ hotandsexy.txt][Test regex for any symbol]
    public void testSedArgRegexAny() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"a s d"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/[^\n]+/oneline/g","hotandsexy.txt"}, null, testOut);
        assertEquals( "oneline", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST :[arg][sed s//oneline/ hotandsexy.txt][Test regex for empty]
    public void testSedArgRegexEntireLine() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{""});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s//oneline/g","hotandsexy.txt"}, null, testOut);
        assertEquals( "oneline", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST :[arg][sed s/t/T/ hotandsexy.txt][Test regex for range of alphabet]
    public void testSedArgRegexAlphaWithRange() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"t tt t tt"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/t{1,2}/big/g","hotandsexy.txt"}, null, testOut);
        assertEquals(  "big big big big", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST :[arg][sed s/t/T/ hotandsexy.txt][Test regex for special symbol]
    public void testSedArgSpecialSymbols() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"1 2 3 4 5 6 1time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/[^0-9]/big/g","hotandsexy.txt"}, null, testOut);
        assertEquals(  "1big2big3big4big5big6big1bigbigbigbig", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST :[arg][sed s/t/T/ hotandsexy.txt][Test regex for numbers]
    public void testSedArgRegexNumbers() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"1tree 1trunk 1to 1the 1temple 1that 1time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/[0-9]/T/g","hotandsexy.txt"}, null, testOut);
        assertEquals(  "Ttree Ttrunk Tto Tthe Ttemple Tthat Ttime", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST :[arg][sed s/t/T/ hotandsexy.txt][Test multiple lines]
    public void testSedArgStdout() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time","thank one only owner okay organism"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/t/T/","hotandsexy.txt"}, null, testOut);
        assertEquals(  "Tree trunk to the temple that time"+ System.getProperty("line.separator")+"thank one only owner okay organism", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST : [stdin/arg][cat hotandsexy.txt | sed s/t/T/ test2.txt][test arg precedence (stdin<arg)]
    public void testSedAndArgPrecedence() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"sree srunk so she semple shat sime"});//createTxtFile(fileName,content[])
    	testIn = new ByteArrayInputStream("tree trunk to the temple that time".getBytes());
    	sedApp.run(new String[]{"s/t/T/","hotandsexy.txt"}, testIn, testOut);
        assertEquals( "sree srunk so she semple shaT sime", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST : [arg][sed s//T// hotandsexy.txt ][Invalid Replacement]
    public void testSedArgWithExtraSeparateSymbol() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("Invalid Replacement");
    	sedApp.run(new String[]{"s//T//","hotandsexy.txt"}, null, testOut);
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST : [arg][sed s/t/T/ aadsasdad.txt][no such dir]
    public void testSedArgFileForFileDirNotExist() throws Exception {
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("can't read " + "aadsasdad.txt" + ": No such file or directory");
    	sedApp.run(new String[]{"s/t/T/","aadsasdad.txt"}, null, testOut);
    }
    @Test  //TEST : [arg][sed s/ test.txt ][cmd doesn't exist]
    public void testSedArgInvalidCmd1() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("Invalid sed command");
    	sedApp.run(new String[]{"s/","hotandsexy.txt"}, null, testOut);
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST : [arg][sed s/t/T/a test.txt ][cmd doesn't exist]
    public void testSedArgInvalidCmd2() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("sed: Exception Caught");
    	sedApp.run(new String[]{"s/t/T/a","hotandsexy.txt"}, null, testOut);
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST : [arg][sed s/ test.txt ][cmd doesn't exist]
    public void testSedArgInvalidCmd3() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("Invalid sed command");
    	sedApp.run(new String[]{"s/","hotandsexy.txt"}, null, testOut);
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST : [arg][sed t/T test.txt ][first s not exist]
    public void testSedArgFirstSNotExist() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("Invalid s'separating symbol' not Found");
    	sedApp.run(new String[]{"t/T","hotandsexy.txt"}, null, testOut);
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 1: [arg][sed s/t/T test.txt ][need T/ follow bash]
    public void testSedArgLastCharSlashNotExist() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("sed: Exception Caught");
    	sedApp.run(new String[]{"s/t/T","hotandsexy.txt"}, null, testOut);
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 5: [arg][sed s/t/T/g/ test1.txt][no need /, just g]
    public void testSedArgFileForLastTwoCharGslashNotExist() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("Invalid Replacement");
    	sedApp.run(new String[]{"s/t/T/g/","hotandsexy.txt"}, null, testOut);
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 6: [arg][sed s/t/ test1.txt ][invalid replacement]
    public void testSedArgFileForReplacementNotExist() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("Invalid replacement");
    	sedApp.run(new String[]{"s/t/","hotandsexy.txt"}, null, testOut);
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST :[arg][sed s/t/T/ test1.txt][other separating symbols && all number->hotbaby]
    public void testSedArgWithOtherSymbol() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"1 tree 2 trunks to the 5 temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s%[0-9]%hotbaby%g","hotandsexy.txt"}, null, testOut);
        assertEquals("hotbaby tree hotbaby trunks to the hotbaby temple that time", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST :[arg][sed s/t/T/ test1.txt][all number->hotbaby]
    public void testSedArgNumberAsReplacement() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"1 tree 2 trunks to the 5 temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/[0-9]/hotbaby/g","hotandsexy.txt"}, null, testOut);
        assertEquals("hotbaby tree hotbaby trunks to the hotbaby temple that time", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST :[arg][sed s/t/T/ test1.txt][all t->hotbaby]
    public void testSedArgMultipleReplacement() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/t/hotbaby/g","hotandsexy.txt"}, null, testOut);
        assertEquals("hotbabyree hotbabyrunk hotbabyo hotbabyhe hotbabyemple hotbabyhahotbaby hotbabyime", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 8:[arg][sed s/t/T/ test1.txt][first t turn T]
    public void testSedArgRegenFirstTurnCaps() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/t/T/","hotandsexy.txt"}, null, testOut);
        assertEquals(  "Tree trunk to the temple that time", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 9:[arg][sed s/t/T/g test1.txt][all t turn T]
    public void testSedArgRegenAllTurnCaps() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/t/T/g","hotandsexy.txt"}, null, testOut);
        assertEquals( "Tree Trunk To The Temple ThaT Time", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 10:[arg][sed s/t// test1.txt][first t turn nothing]
    public void testSedArgRegenFirstTurnNothing() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/t//","hotandsexy.txt"}, null, testOut);
        assertEquals( "ree trunk to the temple that time", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 11:[arg][sed s/t//g test1.txt][all t turn nothing]
    public void testSedArgRegenAllTurnNothing() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/t//g","hotandsexy.txt"}, null, testOut);
        assertEquals( "ree runk o he emple ha ime", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 11:[arg][sed s:t::g test1.txt][all t turn nothing]
    public void testSedArgWithOtherSeparationSymbol1() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s:t::g","hotandsexy.txt"}, null, testOut);
        assertEquals( "ree runk o he emple ha ime", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 11:[arg][sed s|t||g test1.txt][all t turn nothing]
    public void testSedArgWithOtherSeparationSymbol2() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s|t||g" ,"hotandsexy.txt"}, null, testOut);
        assertEquals( "ree runk o he emple ha ime", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST 11:[arg][sed s}t}}g test1.txt][all t turn nothing]
    public void testSedArgWithOtherSeparationSymbol3() throws Exception {
    	createTxtFile("hotandsexy.txt",new String[]{"tree trunk to the temple that time"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s}t}}g","hotandsexy.txt"}, null, testOut);
        assertEquals( "ree runk o he emple ha ime", testOut.toString());
        resetAndDeleteFile("hotandsexy.txt");
    }
    @Test  //TEST :[arg][sed >>t>T> "file.txt"][Test without s]
    public void testSedArgWithSeparationUsedInReplace() throws Exception {
    	createTxtFile("file.txt",new String[]{"tree trunk to the temple that time","thank one only owner okay organism"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("sed: Invalid Replacement");
    	sedApp.run(new String[]{"s>>t>T>","file.txt"}, null, testOut);
    	resetAndDeleteFile("file.txt");
    }  
    @Test  //TEST :[arg][sed /t/T/ "file.txt"][Test without s]
    public void testSedArgWithoutS1() throws Exception {
    	createTxtFile("file.txt",new String[]{"tree trunk to the temple that time","thank one only owner okay organism"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("sed: Invalid s'separating symbol' not Found");
    	sedApp.run(new String[]{"t/T/","file.txt"}, null, testOut);
    	resetAndDeleteFile("file.txt");
    }    
    @Test  //TEST :[arg][sed /t/T/ "file.txt"][Test without s]
    public void testSedArgWithoutS2() throws Exception {
    	createTxtFile("file.txt",new String[]{"tree trunk to the temple that time","thank one only owner okay organism"});//createTxtFile(fileName,content[])
    	expectedEx.expect(SedException.class);
        expectedEx.expectMessage("sed: Invalid s'separating symbol' not Found");
    	sedApp.run(new String[]{"a/t/T/","file.txt"}, null, testOut);
    	resetAndDeleteFile("file.txt");
    }    
    //Test suite for Files
    @Test  //TEST :[arg][sed s/t/T/ "space space.txt"][Test file name with space]
    public void testSedArgFileNameWithSpace() throws Exception {
    	createTxtFile("space space.txt",new String[]{"tree trunk to the temple that time","thank one only owner okay organism"});//createTxtFile(fileName,content[])
        sedApp.run(new String[]{"s/t/T/", "space space.txt"}, null, testOut);
        assertEquals(  "Tree trunk to the temple that time"+ NL+"thank one only owner okay organism", testOut.toString());
        resetAndDeleteFile("space space.txt");
    }    
    
    @Test  //TEST :[arg][sed s/t/T/ "asdf.txt"][Test file that don't exist]
    public void testSedArgFileThatDontExist() throws Exception {
		expectedEx.expect(SedException.class);
		expectedEx.expectMessage("No such file or directory");
        sedApp.run(new String[]{"s/t/T/", "asdf.txt"}, null, testOut);
    }
    @Test  //TEST :[arg][sed s/t/T/ "asdf"][Test file that don't exist]
    public void testSedArgFileIncompleteFileName() throws Exception {
		expectedEx.expect(SedException.class);
		expectedEx.expectMessage("No such file or directory");
        sedApp.run(new String[]{"s/t/T/", "asdf"}, null, testOut);
    }
	private void createTxtFile(String fileName, String[] txtFileLines) throws UnsupportedEncodingException, FileNotFoundException, IOException {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(
	         	new FileOutputStream(fileName), "utf-8"))) {
				for(int x=0; x < txtFileLines.length ;x++){
					writer.write(txtFileLines[x]);
					if(x+1!=txtFileLines.length)
					{
				        writer.write(System.lineSeparator());
					}
				}
	        }
	}
	private static void resetAndDeleteFile(String currFileName) {
		sedApp = new SedApplication();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
		try {
			Path oldPath = FileSystems.getDefault().getPath(Environment.currentDirectory, currFileName);
            Files.deleteIfExists(oldPath);
        } catch (Exception e) {
        }	
	}
}
