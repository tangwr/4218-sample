package ef2.unit;

import static org.junit.Assert.*;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFileAttributes;
import java.nio.file.attribute.PosixFilePermission;
import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.CdException;
import sg.edu.nus.comp.cs4218.impl.app.CdApplication;

public class TestCdApplication {

	static final String TILDE = "~";
	static final String DOT = ".";
	static final String FILE_SEPARATOR = System.getProperty("file.separator"); // \
	static final String SLASH = "/"; // /
	static final String DOUBLE_FILE_SEPARATOR = FILE_SEPARATOR+FILE_SEPARATOR; // \\
	static final String ROOT = Environment.currentDirectory.split(DOUBLE_FILE_SEPARATOR)[0].toLowerCase(); // obtain: c:
	static final String ROOTWITHSLASH = ROOT.concat(SLASH); // obtain: c:/
	static final String SEMICOLON = ":";
	
	static CdApplication cdApp;
	static String txtFileName = "TextFile1.txt";
	static String fileNameAtHomeDirectory = "HomeDirectoryFolder";
	static String fileNameSpaceAtUserDirectory = "Space Space";
	static String nonFileNameAtHomeDirectory = "RandomFile";
	static String[] fileNames = { "File1", "File2", "File3", "File4", "File5" };
	static ArrayList<Path> listOfFiles;

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();
	@BeforeClass
	public static void setUpOnce() throws IOException {
		createFiles();
		createTxtFile();
		createHomeDirFile();
		createNonFile();
		createSpaceFile();
	}
	@Before
	public void setUp() throws IOException {
		cdApp = new CdApplication();
	}
	@After
	public void tearDown() {
		Environment.currentDirectory = Environment.userDirectory;
	}
	@AfterClass
	public static void tearDownOnce() throws IOException {
		deleteFiles();
	}
	private static void createSpaceFile() throws IOException {
		String userDirFolderPath = new File(Environment.userDirectory).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH) + SLASH + fileNameSpaceAtUserDirectory;
		Path path = Paths.get(userDirFolderPath);
		Files.createDirectories(path);
	}
	private static void createNonFile() throws IOException {
		String randomFile = new File(Environment.homeDirectory).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH) + SLASH + nonFileNameAtHomeDirectory;
		Path path = Paths.get(randomFile);
		Files.createDirectories(path);
	}
	private static void createHomeDirFile() throws IOException{
		String homeDirFolderPath = new File(Environment.homeDirectory).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH) + SLASH + fileNameAtHomeDirectory;
		Path path = Paths.get(homeDirFolderPath);
		Files.createDirectories(path);
	}
	private static void createTxtFile() throws UnsupportedEncodingException, FileNotFoundException, IOException {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(
	         	new FileOutputStream(txtFileName), "utf-8"))) {}
	}
	private static void deleteFiles() throws IOException {
		for (int x = 0; x < listOfFiles.size(); x++) {
			Files.deleteIfExists(listOfFiles.get(x));
		}
		resetAndDeleteFile(FileSystems.getDefault().getPath(Environment.currentDirectory, txtFileName));
		resetAndDeleteFile(Paths.get((new File(Environment.homeDirectory).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH)) + SLASH + fileNameAtHomeDirectory));
		resetAndDeleteFile(Paths.get((new File(Environment.homeDirectory).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH)) + SLASH + nonFileNameAtHomeDirectory));
		resetAndDeleteFile(Paths.get((new File(Environment.userDirectory).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH)) + SLASH + fileNameSpaceAtUserDirectory));
	}	
	private static void createFiles() throws IOException {
		listOfFiles = new ArrayList<Path>();
		for (int x = 0; x < fileNames.length; x++) {
			Path path = Paths.get(fileNames[x]);
			Files.createDirectories(path);
			listOfFiles.add(path);
		}
	}
	private static void resetAndDeleteFile(Path oldPath) {
		try {
            Files.deleteIfExists(oldPath);
        } catch (Exception e) {
            e.printStackTrace();
        }	
	}
	//Boundary Test Suite For Folder/Directory
	@Test //Test 1: cd TextFile1 [No such file or directory]
	public void testCdInvalidTypeFolder1() throws CdException {
		String[] inputArray = {"TextFile1"};
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 2: cd TextFile1.txt [No such file or directory]
	public void testCdInvalidTypeFolder2() throws CdException {
		String[] inputArray = {txtFileName};
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 3: cd IncorrectName [change to incorrect file name]
	public void testCdInvalidFolderName1() throws CdException {
		String[] inputArray = {"IncorrectName"};
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("cd: No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 4: cd IncorrectName [change to incorrect file name with space]
	public void testCdInvalidFolderName2() throws CdException {
		String[] inputArray = {"Incorrect Name"};
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 5: cd IncorrectName [change to incorrect file name with special symbol]
	public void testCdInvalidFolderName3() throws CdException {
		String[] inputArray = {"!!IncorrectName"};
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("cd: No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 6: cd ! [change to incorrect file name special symbol]
	public void testCdInvalidFolderName4() throws CdException {
		String[] inputArray = {"!"};
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("cd: No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 7: cd ..z [change to incorrect file name special symbol]
	public void testCdInvalidFolderName5() throws CdException, IOException {
		String[] inputArray = { "..z" };
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 8: cd ..z [change to incorrect file with incorrect file name in other directory]
	public void testCdInvalidFolderName6() throws CdException, IOException {
		String[] inputArray = { "../IncorrectName" };
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	//Boundary Test Suite For Cmd
	@Test //Test 1: cd ......................./ [remain on same folder/nothing will happen]
	public void testCdInvalidReturnParentFolder1() throws CdException {
		String[] inputArray = { "......................./" };
		File expDirectory = new File(Environment.currentDirectory);
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expDirectory, currDirectory);
	}
	@Test //Test 2: cd ... [remain on same folder/nothing will happen]
	public void testCdInvalidReturnParentFolder2() throws CdException {
		String[] inputArray = { "..." };
		File expDirectory = new File(Environment.currentDirectory);
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expDirectory, currDirectory);
	}
	@Test//Test 3: cd ...... [remain on same folder/nothing will happen]
	public void testCdInvalidReturnParentFolder3() throws CdException {
		String[] inputArray = { "......" };
		File expDirectory = new File(Environment.currentDirectory);
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expDirectory, currDirectory);
	}
	@Test//Test 4: cd ~!#!@#!@#!@#!@# [test ~ symbol with rubbish text after ~, remain on same folder]
	public void testCdInvalidTilde1() throws CdException {
		String[] inputArray = { "~!#!@#!@#!@#!@#" };
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test//Test 5: cd ~~ [test ~ symbol with rubbish text after ~, remain on same folder]
	public void testCdInvalidTilde2() throws CdException {
		String[] inputArray = { "~~" };
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	//Test Suite For CFG [Test all node]
	@Test //Test 1: cd  [return to home directory] NODE A0
	public void testCdEmptyArg1() throws CdException {
		String[] inputArray = { "" };
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		File userDirectory = new File(Environment.userDirectory);
		assertEquals(userDirectory, currDirectory);
	}
	@Test //Test 2: cd  [return to home directory] NODE A0
	public void testCdEmptyArg2() throws CdException {
		String[] inputArray = {};
		File expectedDirectory = new File(Environment.homeDirectory);
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expectedDirectory, currDirectory);
	}
	@Test //Test 3: cd File1 [return to home directory] A1
	public void testCdValidFile() throws CdException {
		String[] inputArray = { fileNames[0] };
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		File expDirectory = new File(Environment.userDirectory + File.separator + fileNames[0]);
		assertEquals(expDirectory, currDirectory);
	}
	@Test //Test 4: cd ../   [return to parent directory]-------------------------------------------------A1
	public void testCdPathParent() throws CdException {
		String[] inputArray = {"../"};
		File expectedDirectory = new File(Environment.currentDirectory).getParentFile();
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expectedDirectory, currDirectory);
	}
	@Test //Test 5: cd fullpath   [go to the given path]-------------------------------------------------A1
	public void testCdPathDirect() throws CdException {
		String[] inputArray = {ROOTWITHSLASH};
		File expectedDirectory = new File(ROOTWITHSLASH);
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expectedDirectory, currDirectory);
	}
	@Test //Test 6: cd 'space space' [test single quote]-------------------------------------------------A1
	public void testCdValidFileNameWithSingleQuote() throws CdException {
		String[] inputArray = {fileNameSpaceAtUserDirectory};
		File expectedDirectory = new File(Environment.userDirectory + File.separator +  fileNameSpaceAtUserDirectory);
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expectedDirectory, currDirectory);
	}
	@Test//Test 7: cd c [test full directory, with incomplete name example: c (referring to c drive)] ---A1
	public void testCdInvalidFilename0() throws CdException {
		String[] inputArray = { ROOT.replace(SEMICOLON, "") };
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 8: cd ~ asdf [return to home directory with space/s and rubbish string behind ~ ] A2
	public void testCdPathHome() throws CdException {
		String[] inputArray = { "~", "asdf" };
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		File expDirectory = new File(Environment.homeDirectory);
		assertEquals(expDirectory, currDirectory);
	}
	@Test //Test 9: cd  [change to incorrect file name] A3
	public void testCdInvalidFilename1() throws CdException {
		String[] inputArray = {"!@@##$IncorrectName"};
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("cd: No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 10: cd ~ASDF  [test ~ sybmol followed by string of rubbish, directory not found] B0
	public void testCdTildeWithExtraText1() throws CdException {
		String[] inputArray = { "~ASDF" };
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 11: cd ~./ [test ~ with rubbish text behind] B0
	public void testCdTildeWithExtraText2() throws CdException {
		String[] inputArray = { "~./" };
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 12: cd ~/HomeDirectoryFolder  [change to home dir and then specific folder] B0
	public void testCdchkExistDirExeTrue() throws CdException, IOException {
		String[] inputArray = { "~"+ SLASH + fileNameAtHomeDirectory };
		File expDirectory = new File(Environment.homeDirectory + FILE_SEPARATOR + fileNameAtHomeDirectory);
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expDirectory, currDirectory);
	}
	@Test //Test 13: cd . [Test dot, remain at the current directory] B1
	public void testCdSingleDot() throws CdException {
		String[] inputArray = { "." };
		File expDirectory = new File(Environment.currentDirectory);
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expDirectory, currDirectory);
	}
	@Test //Test 14: cd c:/  [Test path to the root] B2
	public void testCdPathRoot() throws CdException {
		String[] inputArray = {ROOT};
		File expDirectory = new File(ROOTWITHSLASH);
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expDirectory, currDirectory);
	}
	@Test //Test 15: cd ~/ [Test ~ with / behind, return to home directory] C0
	public void testCdPathHome1() throws CdException {
		String[] inputArray = { "~/" };
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		File homeDirectory = new File(Environment.homeDirectory);
		assertEquals(homeDirectory, currDirectory);
	}
	@Test //Test 16: cd ~/../~/../ [] C0
	public void testCdPathHomeParent1() throws CdException {
		String[] inputArray = { "~/../~/../" };
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		File expectedDirectory = new File(Environment.homeDirectory).getParentFile();
		assertEquals(expectedDirectory, currDirectory);
	}
	@Test //Test 17: cd ~/../~/...../ [] C0
	public void testCdInvalidPathHomeParent() throws CdException {
		String[] inputArray = { "~/../~/...../"};
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, null, null);
	}
	@Test //Test 18: cd ~/HomeDirectoryFolder [] C0
	public void testCdPathHome2() throws CdException {
		String[] inputArray = { "~/" + fileNameAtHomeDirectory };
		File expectedDirectory = new File( Environment.homeDirectory + SLASH + fileNameAtHomeDirectory );
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expectedDirectory, currDirectory);
	}
	@Test //Test 19: cd ~/.. [] C0
	public void testCdPathHomeParent2() throws CdException {
		String[] inputArray = { "~/.."};
		File expectedDirectory = new File( Environment.homeDirectory).getParentFile();
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		assertEquals(expectedDirectory, currDirectory);
	}
	@Test //Test 20: cd ~ [test ~ only, return to home directory] C1
	public void testCdPathHome3() throws CdException {
		String[] inputArray = { "~" };
		cdApp.run(inputArray, null, null);
		File currDirectory = new File(Environment.currentDirectory);
		File homeDirectory = new File(Environment.homeDirectory);
		assertEquals(homeDirectory, currDirectory);
	}
	//Test Suite for Stdin And Arg
	@Test //Test 1: cd File0 [stdin and arg both are occupied, arg has priority]
	public void testCdWithArgAndInvalidStdin() throws CdException {
		String[] inputArray = {fileNames[0]};
		cdApp.run(inputArray, new ByteArrayInputStream("hajsdhfl".getBytes()), null);
		File currDirectory = new File(Environment.currentDirectory);
		File expectedDirectory = new File(Environment.userDirectory + SLASH + fileNames[0]);
		assertEquals(expectedDirectory, currDirectory);
	}
	@Test //Test 2: cd adsffasd [Invalid stdin and Invalid arg both are occupied, arg has priority]
	public void testCdWithInvalidArgAndInvalidStdin() throws CdException {
		String[] inputArray = {"adsffasd"};
		expectedEx.expect(CdException.class);
		expectedEx.expectMessage("No such file or directory");
		cdApp.run(inputArray, new ByteArrayInputStream("hajsdhfl".getBytes()), null);
	}	
}
