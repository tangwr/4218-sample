package ef2.integration;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestSemicolonTwoCommand {

	private static final String NEW_LINE = System.getProperty("line.separator");
	private static final String TEST_FILE_1 = "test.txt";
	private static final String TEST_FILE_2 = "goToTest.txt";
	private static final String TEST_FOLDER = "temp folder";
	
	private static final String TEST_DATA_1 = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
			+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_DATA_2 = "test.txt";
	
	private static final String TEST_EXPECTED_T = "TesT 1" + NEW_LINE + "TesT 2" + NEW_LINE + "TesT 3" + NEW_LINE + "3 TesT" + NEW_LINE
			+ "2 TesT" + NEW_LINE + "1 TesT" + NEW_LINE + "\\b TesT" + NEW_LINE + "\\T TesT" + NEW_LINE + "\\n TesT" + NEW_LINE + "\\f TesT" + NEW_LINE
			+ "\\r TesT" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_EXPECTED_AR = "tear 1" + NEW_LINE + "tear 2" + NEW_LINE + "tear 3" + NEW_LINE + "3 tear" + NEW_LINE
			+ "2 tear" + NEW_LINE + "1 tear" + NEW_LINE + "\\b tear" + NEW_LINE + "\\t tear" + NEW_LINE + "\\n tear" + NEW_LINE + "\\f tear" + NEW_LINE
			+ "\\r tear" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";

	private static final String TEST_1_HEAD = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test";
	private static final String TEST_1_TAIL = "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
			+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	
	private static ShellImpl shell;
	private static ByteArrayOutputStream result;
	private static File initDirectory;

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	@BeforeClass
	public static void setUpOnce() throws FileNotFoundException {
		createTxtFile(TEST_FILE_1, TEST_DATA_1);
		createTxtFile(TEST_FILE_2, TEST_DATA_2);
		new File(TEST_FOLDER).mkdir();
		shell = new ShellImpl();
		result = new ByteArrayOutputStream();
		System.setOut(new PrintStream(result));
	}

	@AfterClass
	public static void tearDownOnce() {
		deleteFile(TEST_FILE_1);
		deleteFile(TEST_FILE_2);
		new File(TEST_FOLDER).delete();
		System.out.close();
	}

	@After
	public void tearDown() throws IOException {
		result.reset();
		Environment.currentDirectory = initDirectory.getCanonicalPath();
	}

	@Before
	public void setUp() {
		initDirectory = new File(Environment.currentDirectory);
	}

	@Test
	public void testCdSemicolonCd() throws AbstractApplicationException, ShellException {
		String cmd = "cd `echo \"\'temp folder\'\"` ; cd ../src";
		File expDirectory = new File(Environment.currentDirectory, "src");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);
		assertEquals(expDirectory, curDirectory);
	}

	@Test
	public void testCdSemicolonCat() throws AbstractApplicationException, ShellException {
		String cmd = "cd `echo test` ; cat ../test.txt";
		File expDirectory = new File(Environment.currentDirectory, "test");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(TEST_DATA_1, result.toString());
	}

	@Test
	public void testCdSemicolonEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cd `echo \"src\"` ; echo `echo `echo \"This is a little extreme\"``";
		File expDirectory = new File(Environment.currentDirectory, "src");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("echo This is a little extreme" + NEW_LINE, result.toString());
	}

	@Test
	public void testCdSemicolonPwd() throws AbstractApplicationException, ShellException {
		String cmd = "cd ~ useless ; pwd useless";
		File expDirectory = new File(System.getProperty("user.home"));
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testCdSemicolonHead() throws AbstractApplicationException, ShellException {
		String cmd = "cd \"temp folder\" ; head -n 3 ../test.txt";
		File expDirectory = new File(Environment.currentDirectory, "temp folder");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3", result.toString());
	}

	@Test
	public void testCdSemicolonTail() throws AbstractApplicationException, ShellException {
		String cmd = "cd test ; tail -n 3 ../test.txt";
		File expDirectory = new File(Environment.currentDirectory, "test");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("\\f test" + NEW_LINE + "\\r test" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"", result.toString());
	}

	@Test
	public void testCdSemicolonDate() throws AbstractApplicationException, ShellException {
		String cmd = "cd src/../test/.. ; date rubbish text that should not affect";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		String expDate = Calendar.getInstance().getTime().toString();
		assertEquals(expDate + NEW_LINE, result.toString());
		assertEquals(expDirectory, curDirectory);
	}

	@Test
	public void testCdSemicolonSed() throws AbstractApplicationException, ShellException {
		String cmd = "cd test/../src ; sed s/t/T/g ../test.txt";
		File expDirectory = new File(Environment.currentDirectory, "src");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(TEST_EXPECTED_T, result.toString());
	}

	@Test
	public void testCdSemicolonWc() throws AbstractApplicationException, ShellException {
		String cmd = "cd test ; wc -lwm ../test.txt";
		File expDirectory = new File(Environment.currentDirectory, "test");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("\t11\t23\t108 ../" + TEST_FILE_1, result.toString());
	}

	@Test
	public void testCatSemicolonCat() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt ; cat `echo \"test.txt\"`";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1 + TEST_DATA_1, result.toString());
	}

	@Test
	public void testCatSemicolonEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cat `echo 'test.txt'` ; echo !@#$%^&*()";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1 + "!@#$%^&*()" + NEW_LINE, result.toString());
	}

	@Test
	public void testCatSemicolonPwd() throws AbstractApplicationException, ShellException {
		String cmd = "cat \"test.txt\";pwd useless statement that dont affect anything";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		
		assertEquals(TEST_DATA_1 + expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testCatSemicolonHead() throws AbstractApplicationException, ShellException {
		String cmd = "cat 'test.txt';head -n 6 'test.txt'";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1 + "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE 
				+ "2 test" + NEW_LINE + "1 test", result.toString());
	}

	@Test
	public void testCatSemicolonTail() throws AbstractApplicationException, ShellException {
		String cmd = "cat 'test.txt';tail -n 6 'test.txt'";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1 + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE 
				+ "\\r test" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"", result.toString());
	}

	@Test
	public void testCatSemicolonDate() throws AbstractApplicationException, ShellException {
		String cmd = "cat `cat goToTest.txt` ; date";
		shell.parseAndEvaluate(cmd, result);
		
		String expDate = Calendar.getInstance().getTime().toString();
		assertEquals(TEST_DATA_1 + expDate + NEW_LINE, result.toString());
	}

	@Test
	public void testCatSemicolonSed() throws AbstractApplicationException, ShellException {
		String cmd = "cat goToTest.txt ; sed s/t/T/ goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_2 + "Test.txt", result.toString());
	}

	@Test
	public void testCatSemicolonWc() throws AbstractApplicationException, ShellException {
		String cmd = "cat goToTest.txt ; wc -mwl test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_2 + "\t11\t23\t108 " + TEST_FILE_1, result.toString());
	}
	
	@Test
	public void testEchoSemicolonEcho1() throws AbstractApplicationException, ShellException {
		String cmd = "echo 'asd;zxc|wtf' ; echo \"asd;zxc|wtf\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("asd;zxc|wtf" + NEW_LINE + "asd;zxc|wtf" + NEW_LINE, result.toString());
	}
	
	@Test
	public void testEchoSemicolonEcho2() throws AbstractApplicationException, ShellException {
		String cmd = "echo 'testing: `echo test`;'; echo b";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("testing: `echo test`;" + NEW_LINE + "b" + NEW_LINE, result.toString());
	}
	
	@Test
	public void testEchoSemicolonEcho3() throws AbstractApplicationException, ShellException {
		String cmd = "echo \"testing: `echo test`;\"; echo b";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("testing: test;" + NEW_LINE + "b" + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoSemicolonPwd() throws AbstractApplicationException, ShellException {
		String cmd = "echo this is so repetitive;pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals("this is so repetitive" + NEW_LINE + expDirectory.toString() +NEW_LINE, result.toString());
	}

	@Test
	public void testEchoSemicolonHead() throws AbstractApplicationException, ShellException {
		String cmd = "echo this test is ending soon;head -n 20 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("this test is ending soon" + NEW_LINE + TEST_DATA_1, result.toString());
	}

	@Test
	public void testEchoSemicolonTail() throws AbstractApplicationException, ShellException {
		String cmd = "echo I lied;tail -n 20 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("I lied" + NEW_LINE + TEST_DATA_1, result.toString());
	}

	@Test
	public void testEchoSemicolonDate() throws AbstractApplicationException, ShellException {
		String cmd = "echo test.txt ; date";
		shell.parseAndEvaluate(cmd, result);
		
		String expDate = Calendar.getInstance().getTime().toString();
		assertEquals("test.txt" + NEW_LINE + expDate + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoSemicolonSed() throws AbstractApplicationException, ShellException {
		String cmd = "echo `cat goToTest.txt` ; sed s/./-/ goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("test.txt" + NEW_LINE + "-est.txt", result.toString());
	}

	@Test
	public void testEchoSemicolonWc() throws AbstractApplicationException, ShellException {
		String cmd = "echo echo ; wc -wlm goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("echo" + NEW_LINE + "\t1\t1\t8 " + TEST_FILE_2, result.toString());
	}

	@Test
	public void testPwdSemicolonPwd() throws AbstractApplicationException, ShellException {
		String cmd = "pwd we are halfway through ; pwd come on!!!";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE + expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdSemicolonHead() throws AbstractApplicationException, ShellException {
		String cmd = "pwd .. ; head test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE + TEST_1_HEAD, result.toString());
	}

	@Test
	public void testPwdSemicolonTail() throws AbstractApplicationException, ShellException {
		String cmd = "pwd // ; tail test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE + TEST_1_TAIL, result.toString());
	}

	@Test
	public void testPwdSemicolonDate() throws AbstractApplicationException, ShellException {
		String cmd = "pwd 'pwd' ; date";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		
		String expDate = Calendar.getInstance().getTime().toString();
		assertEquals(expDirectory.toString() + NEW_LINE + expDate + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdSemicolonSed() throws AbstractApplicationException, ShellException {
		String cmd = "pwd \"pwd\" ; sed s/./-/g goToTest.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE + "--------", result.toString(), result.toString());
	}

	@Test
	public void testPwdSemicolonWc() throws AbstractApplicationException, ShellException {
		String cmd = "pwd last pwd; wc -wl goToTest.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE + "\t1\t1 " + TEST_FILE_2, result.toString());
	}

	@Test
	public void testHeadSemicolonHead() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 100 goToTest.txt ;head -n 1 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("test.txt" + "test 1" , result.toString());
	}

	@Test
	public void testHeadSemicolonTail() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 100 goToTest.txt ;tail -n 1999 goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("test.txt" + "test.txt" , result.toString());
	}

	@Test
	public void testHeadSemicolonDate() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 2 goToTest.txt ;date";
		shell.parseAndEvaluate(cmd, result);

		String expDate = Calendar.getInstance().getTime().toString();
		assertEquals("test.txt" + expDate + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadSemicolonSed() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 12 test.txt;sed s/st/ar/g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1 + TEST_EXPECTED_AR, result.toString());
	}

	@Test
	public void testHeadSemicolonWc() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 12 test.txt;wc -m test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1 + "\t108 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testTailSemicolonTail() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n 100 goToTest.txt ;tail -n 1 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("test.txt" + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"", result.toString());
	}

	@Test
	public void testTailSemicolonDate() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n 2 goToTest.txt ;date asjibaisfbsaifb";
		shell.parseAndEvaluate(cmd, result);

		String expDate = Calendar.getInstance().getTime().toString();
		assertEquals("test.txt" + expDate + NEW_LINE, result.toString());
	}

	@Test
	public void testTailSemicolonSed() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 12 test.txt;sed s/st/ar/g `echo test.txt`";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1 + TEST_EXPECTED_AR, result.toString());
	}

	@Test
	public void testTailSemicolonWc() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n 12 test.txt;wc -w test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1 + "\t23 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testDateSemicolonDate() throws AbstractApplicationException, ShellException {
		String cmd = "date 'teafaiubas';date \"asdasasdsa\"";
		shell.parseAndEvaluate(cmd, result);

		String expDate = Calendar.getInstance().getTime().toString();
		assertEquals(expDate + NEW_LINE + expDate + NEW_LINE, result.toString());
	}

	@Test
	public void testDateSemicolonSed() throws AbstractApplicationException, ShellException {
		String cmd = "date `abc`;sed s/\\./-/g goToTest.txt";
		shell.parseAndEvaluate(cmd, result);

		String expDate = Calendar.getInstance().getTime().toString();
		assertEquals(expDate + NEW_LINE + "test-txt", result.toString());
	}

	@Test
	public void testDateSemicolonWc() throws AbstractApplicationException, ShellException {
		String cmd = "date;wc -l `echo test.txt`";
		shell.parseAndEvaluate(cmd, result);

		String expDate = Calendar.getInstance().getTime().toString();
		assertEquals(expDate + NEW_LINE + "\t11 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testSedSemicolonSed() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T/g 'test.txt';sed s/st/ar/g \"test.txt\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_T + TEST_EXPECTED_AR, result.toString());
	}

	@Test
	public void testSedSemicolonWc() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/st/ar/g test.txt;wc -lm test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_AR + "\t11\t108 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testWcSemicolonWc1() throws AbstractApplicationException, ShellException {
		String cmd = "wc -ml test.txt;wc -mw goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t11\t108 " + TEST_FILE_1 + "\t1\t8 " + TEST_FILE_2, result.toString());
	}

	@Test
	public void testWcSemicolonWc2() throws AbstractApplicationException, ShellException {
		String cmd = "wc -ml test.txt;wc -lmw goToTest.txt test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t11\t108 " + TEST_FILE_1 + "\t1\t1\t8 " + TEST_FILE_2 + NEW_LINE 
				+ "\t11\t23\t108 " + TEST_FILE_1 + NEW_LINE + "\t12\t24\t116 total", result.toString());
	}

	@Test
	public void testInvalidFirstTerminatesWhole() throws AbstractApplicationException, ShellException {
		String cmd = "eccho this should stop everything else ; echo should not be printed";
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: eccho: Invalid app.", e.getMessage());
		}
		assertEquals("", result.toString());
	}

	@Test
	public void testValidFirstInvalidSecond() throws AbstractApplicationException, ShellException {
		String cmd = "echo this should be printed; Echo this will cause the error";
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: Echo: Invalid app.", e.getMessage());
		}
		assertEquals("this should be printed" + NEW_LINE, result.toString());
	}

	private static void createTxtFile(String fileName, String data) throws FileNotFoundException {
		PrintWriter writer = new PrintWriter(fileName);
		writer.print(data);
		writer.close();
	}

	private static void deleteFile(String fileName) {
		File file = new File(fileName);
		file.delete();
	}
}
