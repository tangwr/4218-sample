package ef2.integration;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestPipeTwoCommand {

	private static final String NEW_LINE = System.getProperty("line.separator");
	private static final String TEST_FILE_1 = "test.txt";
	private static final String TEST_FILE_2 = "goToTest.txt";
	private static final String TEST_FILE_3 = "temp file.txt";
	private static final String TEST_FOLDER = "temp folder";
	
	private static final String TEST_DATA_1 = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
			+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_DATA_2 = "test.txt";
	private static final String TEST_DATA_3 = "asd" + NEW_LINE + "dsa" + NEW_LINE + "sda";
	
	private static final String TEST_EXPECTED_T = "TesT 1" + NEW_LINE + "TesT 2" + NEW_LINE + "TesT 3" + NEW_LINE + "3 TesT" + NEW_LINE
			+ "2 TesT" + NEW_LINE + "1 TesT" + NEW_LINE + "\\b TesT" + NEW_LINE + "\\T TesT" + NEW_LINE + "\\n TesT" + NEW_LINE + "\\f TesT" + NEW_LINE
			+ "\\r TesT" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_EXPECTED_AR = "tear 1" + NEW_LINE + "tear 2" + NEW_LINE + "tear 3" + NEW_LINE + "3 tear" + NEW_LINE
			+ "2 tear" + NEW_LINE + "1 tear" + NEW_LINE + "\\b tear" + NEW_LINE + "\\t tear" + NEW_LINE + "\\n tear" + NEW_LINE + "\\f tear" + NEW_LINE
			+ "\\r tear" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_EXPECTED_S_S = "as sd" + NEW_LINE + "ds sa" + NEW_LINE + "s sda";

	private static final String TEST_1_HEAD = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test";
	private static final String TEST_1_TAIL = "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
			+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	
	private static ShellImpl shell;
	private static ByteArrayOutputStream result;
	private static File initDirectory;

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	@BeforeClass
	public static void setUpOnce() throws FileNotFoundException {
		createTxtFile(TEST_FILE_1, TEST_DATA_1);
		createTxtFile(TEST_FILE_2, TEST_DATA_2);
		createTxtFile(TEST_FILE_3, TEST_DATA_3);
		new File(TEST_FOLDER).mkdir();
		shell = new ShellImpl();
		result = new ByteArrayOutputStream();
		System.setOut(new PrintStream(result));
	}

	@AfterClass
	public static void tearDownOnce() {
		deleteFile(TEST_FILE_1);
		deleteFile(TEST_FILE_2);
		deleteFile(TEST_FILE_3);
		new File(TEST_FOLDER).delete();
		System.out.close();
	}

	@After
	public void tearDown() throws IOException {
		result.reset();
		Environment.currentDirectory = initDirectory.getCanonicalPath();
	}

	@Before
	public void setUp() {
		initDirectory = new File(Environment.currentDirectory);
	}

	@Test
	public void testNoSpaceBetweenPipe() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt|sed s/t/T/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_T + NEW_LINE, result.toString());
	}
	
	@Test
	public void testCdPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "cd test | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidCdPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "Cd test | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: Cd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "cd test | cd nosuchfolder";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "cd nosuchfolder | CD test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + "shell: CD: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "cd test | cat test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(TEST_DATA_1, result.toString());
	}

	@Test
	public void testInvalidCdPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "cD test | cat test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: cD: Invalid app." + NEW_LINE + TEST_DATA_1, result.toString());
	}

	@Test
	public void testCdPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "cd test | cAt test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: cAt: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "cd notest | cat test.tzt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + "cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cd test | echo Store and share";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("Store and share" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cd tets | echo !@#$%^&*()-_~+=?.,";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + "!@#$%^&*()-_~+=?.," + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cd src | EcHo Hi";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: EcHo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cd source | ECHO Hi";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + "shell: ECHO: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipePwd() throws AbstractApplicationException, ShellException {
		String currentDirectory = System.getProperty("user.dir");
		String cmd = "cd .. | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(currentDirectory + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipePwd() throws AbstractApplicationException, ShellException {
		String currentDirectory = System.getProperty("user.dir");
		String cmd = "CD test | pwd uselessArg";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: CD: Invalid app." + NEW_LINE + currentDirectory + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "cd ~ | Pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "CD test | pwD";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: CD: Invalid app." + NEW_LINE + "shell: pwD: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeHead() throws AbstractApplicationException, ShellException {
		String expected = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
				+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test";
		String cmd = "cd / | head test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(expected, result.toString());
	}

	@Test
	public void testInvalidCdPipeHead() throws AbstractApplicationException, ShellException {
		String expected = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3";
		String cmd = "cd wtbbq | head -n 3 test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + expected, result.toString());
	}

	@Test
	public void testCdPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "cd src | head -13 test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("head: invalid command format" +NEW_LINE +
				"usage: head [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "CD src | head -n test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: CD: Invalid app." + NEW_LINE + "head: illegal line count -- test.txt" +NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeTail() throws AbstractApplicationException, ShellException {
		String expected = "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
				+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
				+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
		String cmd = "cd test | tail test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(expected, result.toString());
	}

	@Test
	public void testInvalidCdPipeTail() throws AbstractApplicationException, ShellException {
		String expected = "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
				+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
		String cmd = "c_d test | tail -n 5 test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: c_d: Invalid app." + NEW_LINE + expected, result.toString());
	}

	@Test
	public void testCdPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "cd src | taiI -n 5 test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: taiI: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "cd srcs | tail -4 test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + "tail: invalid command format" + NEW_LINE
				+ "usage: tail [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "cd test | date";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(expected + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "CD test | date nonsense and useless args";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: CD: Invalid app." + NEW_LINE + expected + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "cd src | Date";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: Date: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "cd nosuchfolder | DATE just putting some args";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + "shell: DATE: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "cd `echo test`| sed s/t/T/g test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(TEST_EXPECTED_T, result.toString());
	}

	@Test
	public void testInvalidCdPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "cd 'tests' | sed s/st/ar/g test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + TEST_EXPECTED_AR, result.toString());
	}

	@Test
	public void testCdPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "cd \"test\" | sed f/t/T/g test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("sed: Invalid s\'separating symbol\' not Found" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "cd `echoo test` | sed f/t/T/g test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + "sed: Invalid s\'separating symbol\' not Found" + NEW_LINE, result.toString());
	}

	@Test
	public void testCdPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "cd 'test' | wc -mwl test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("\t11\t23\t108 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testInvalidCdPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "cd \"tests\" | wc -ml test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + "\t11\t108 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testCdPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "cd `echo \"src\"` | wC -mwl test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: wC: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCdPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "cd `echo 'srcs'` | WC -mwl test.txt";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + "shell: WC: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | cd ..";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidCatPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "cat test2.txt | cd ";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "cat `echo 'test.txt'` | cd ~sdjasbdsao";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "caat `echo 'test.txt'` | cd noSuchFileOrDirectory";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: caat: Invalid app." + NEW_LINE + "cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeCat1() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | cat `echo test.txt`";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1, result.toString());
	}

	@Test
	public void testCatPipeCat2() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | cat ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1, result.toString());
	}

	@Test
	public void testInvalidCatPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "cat text.txt | cat `echo \"test.txt\"`";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + TEST_DATA_1, result.toString());
	}

	@Test
	public void testCatPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "cat `echo 'test.txt'` | cat e";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "cat e | cat `cat e`";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "cat: Invalid file path" + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | echo hello";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("hello" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cat temp file.txt | echo `cat \'goToTest.txt\'`";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + TEST_DATA_2 + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cat \'temp file.txt\' | echo \"quote not closed";
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: Invalid syntax encountered.", e.getMessage());
		}
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidCatPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "cat tempfile.txt | echho quote not closed";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "shell: echho: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "cat \"temp file.txt\" | pwd to be ignored";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "cat \"tempfile.txt\" | pwd to be ignored";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "cat `echo \"\'temp file.txt\'\"` | pwdto be ignored";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: pwdto: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "cat `echo \"\'temp file.txt\'\" | pwdto be ignored";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE + "shell: pwdto: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeHead1() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | head ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_1_HEAD, result.toString());
	}
	
	@Test
	public void testCatPipeHead2() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | head -n 3";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3", result.toString());
	}
	
	@Test
	public void testCatPipeHead3() throws AbstractApplicationException, ShellException {
		String cmd = "cat \"temp file.txt\" | head";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_3, result.toString());
	}

	@Test
	public void testInvalidCatPipeHead1() throws AbstractApplicationException, ShellException {
		String cmd = "cat filenotfound.txt | head test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + TEST_1_HEAD, result.toString());
	}

	@Test
	public void testInvalidCatPipeHead2() throws AbstractApplicationException, ShellException {
		String cmd = "cat filenotfound.txt | head -n 3 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3", result.toString());
	}

	@Test
	public void testInvalidCatPipeHead3() throws AbstractApplicationException, ShellException {
		String cmd = "cat filenotfound.txt | head \"temp file.txt\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + TEST_DATA_3, result.toString());
	}

	@Test
	public void testCatPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | head -n a";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: illegal line count -- a" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "cat nosuchfile | head -f 3 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "head: invalid command format" + NEW_LINE
				+ "usage: head [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeTail1() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | tail ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_1_TAIL, result.toString());
	}

	@Test
	public void testCatPipeTail2() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | tail -n 3";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\\f test" + NEW_LINE + "\\r test" + NEW_LINE 
				+ "!@#$%^&*()-_`~+=/\\|<>,.?\'\"", result.toString());
	}
	
	@Test
	public void testCatPipeTail3() throws AbstractApplicationException, ShellException {
		String cmd = "cat \"temp file.txt\" | tail";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_3, result.toString());
	}

	@Test
	public void testInvalidCatPipeTail1() throws AbstractApplicationException, ShellException {
		String cmd = "cat filenotfound.txt | tail test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + TEST_1_TAIL, result.toString());
	}

	@Test
	public void testInvalidCatPipeTail2() throws AbstractApplicationException, ShellException {
		String cmd = "cat filenotfound.txt | tail -n 3 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
				+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"",result.toString());
	}

	@Test
	public void testInvalidCatPipeTail3() throws AbstractApplicationException, ShellException {
		String cmd = "cat filenotfound.txt | tail \"temp file.txt\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + TEST_DATA_3,result.toString());
	}

	@Test
	public void testCatPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | tail -n a";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: illegal offset -- a" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "cat nosuchfile | tail -f 3 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "tail: invalid command format" + NEW_LINE
				+ "usage: tail [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | date to be ignored";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals(expected + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "cat invalid | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals("cat: Could not read file" + NEW_LINE + expected + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | datet";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: datet: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "cat invalid | ddate";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "shell: ddate: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeSed1() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | sed s/t/T/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_T + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeSed2() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt|sed s/st/ar/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_AR + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeSed3() throws AbstractApplicationException, ShellException {
		String cmd = "cat \"temp file.txt\"|sed s/'s'/\"s s\"/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_S_S + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeSed4() throws AbstractApplicationException, ShellException {
		String cmd = "cat \"test.txt\"|sed \"s|t|T|g\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_T + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeSed5() throws AbstractApplicationException, ShellException {
		String cmd = "cat \"test.txt\"|sed s$st$ar$g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_AR + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.jpg|sed s/st/ar/g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + TEST_EXPECTED_AR, result.toString());
	}

	@Test
	public void testCatPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "cat goToTest.txt|sed s/st/ar/g invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: can't read invalid: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "cat invalid | sed g/t/T/s test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "sed: Invalid s'separating symbol' not Found" + NEW_LINE, result.toString());
	}

	@Test
	public void testCatPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "cat `echo \"\'temp file.txt\'\"` | wc -lwm ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t2\t3\t11", result.toString());
	}

	@Test
	public void testInvalidCatPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "cat invalid | wc -lwm \"temp file.txt\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "\t2\t3\t11 " + TEST_FILE_3, result.toString());
	}

	@Test
	public void testCatPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | wc -f ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- f" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidCatPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "cat invalid | wc -lwm invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "wc: invalid: open: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "echo nothing | cd `echo \'\"temp folder\"\'`";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidEchoPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "echo \"quote not closed | cd `echo \'\"temp folder\"\'`";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "echo echo | cd echo";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "echho echo | cd echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: echho: Invalid app." + NEW_LINE + "cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeCat1() throws AbstractApplicationException, ShellException {
		String cmd = "echo blah blah blah | cat";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("blah blah blah" + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeCat2() throws AbstractApplicationException, ShellException {
		String cmd = "echo test.txt | cat";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("test.txt" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "echho will cause invalid | cat \"temp file.txt\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: echho: Invalid app." + NEW_LINE + TEST_DATA_3, result.toString());
	}

	@Test
	public void testEchoPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "echo echo | cat invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "echho will cause invalid | cat invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: echho: Invalid app." + NEW_LINE + "cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "echo hi | echo bye";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("bye" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "Echo hi | echo bye";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Echo: Invalid app." + NEW_LINE + "bye" + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "echo hi | Echo bye";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "Echo hi | Echo bye";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Echo: Invalid app." + NEW_LINE + "shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "echo echo | pwd to be ignored";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "echo \'echo | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE + expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "echo echo | pmd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: pmd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "echo `echo |pmd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE + "shell: pmd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeHead1() throws AbstractApplicationException, ShellException {
		String cmd = "echo blah blah blah | head";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("blah blah blah", result.toString());
	}

	@Test
	public void testEchoPipeHead2() throws AbstractApplicationException, ShellException {
		String cmd = "echo blah blah blah | head -n 2";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("blah blah blah", result.toString());
	}

	@Test
	public void testInvalidEchoPipeHead() throws AbstractApplicationException, ShellException {
		String cmd = "invalid | head \'temp file.txt\'";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: invalid: Invalid app." + NEW_LINE + TEST_DATA_3, result.toString());
	}

	@Test
	public void testEchoPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "echo echo | head -m 1";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE, result.toString());
	}
	@Test
	public void testInvalidEchoPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "invalid | head -format 1";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: invalid: Invalid app." + NEW_LINE + "head: invalid command format" + NEW_LINE 
				+ "usage: head [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeTail1() throws AbstractApplicationException, ShellException {
		String cmd = "echo blah blah blah | tail";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("blah blah blah", result.toString());
	}

	@Test
	public void testEchoPipeTail2() throws AbstractApplicationException, ShellException {
		String cmd = "echo blah blah blah | tail -n 2";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("blah blah blah", result.toString());
	}

	@Test
	public void testInvalidEchoPipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "invalid | tail \'temp file.txt\'";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: invalid: Invalid app." + NEW_LINE + TEST_DATA_3, result.toString());
	}

	@Test
	public void testEchoPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "echo echo | tail -m 1";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE,
				result.toString());
	}

	@Test
	public void testInvalidEchoPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "invalid | tail -format 1";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: invalid: Invalid app." + NEW_LINE + "tail: invalid command format" + NEW_LINE
				+ "usage: tail [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "echo echo | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals(expected + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "invalid | date ignores";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals("shell: invalid: Invalid app." + NEW_LINE + expected + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "echo echo | invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: invalid: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "echo \"quotes not closed | invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE + "shell: invalid: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeSed1() throws AbstractApplicationException, ShellException {
		String cmd = "echo blah blah blah | sed s/\\s/-/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("blah-blah-blah--", result.toString());
	}

	@Test
	public void testEchoPipeSed2() throws AbstractApplicationException, ShellException {
		String cmd = "echo blah blah blah | sed s/\\s/-/";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("blah-blah blah" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "echo \"blah blah blah | sed s/\\./-/ goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE + "test-txt", result.toString());
	}

	@Test
	public void testEchoPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "echo blah blah blah | sed s/\\./-/t goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Exception Caught" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "echo \"blah blah blah | sed s/\\./-/t goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE + "sed: Exception Caught" + NEW_LINE, result.toString());
	}

	@Test
	public void testEchoPipeWc1() throws AbstractApplicationException, ShellException {
		String cmd = "echo 123456789 | wc -lwm";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t1\t1\t10", result.toString());
	}

	@Test
	public void testEchoPipeWc2() throws AbstractApplicationException, ShellException {
		String cmd = "echo 123456789| wc -lwm";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t1\t1\t10", result.toString());
	}

	@Test
	public void testInvalidEchoPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "echo \"123456789 | wc -lwm test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE + "\t11\t23\t108 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testEchoPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "echo hi | wc -format";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- format" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidEchoPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "echo \"hi | wc -format";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE + "wc: illegal option -- format" + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);
		
		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidPwdPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "pWd | cd src";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);
		
		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: pWd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | cd invalid";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);
		
		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "pWd | cd invalid";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);
		
		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: pWd: Invalid app." + NEW_LINE + "cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | cat";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "pWd | cat test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: pWd: Invalid app." + NEW_LINE + TEST_DATA_1, result.toString());
	}

	@Test
	public void testPwdPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | cat 404filenotfound.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "pWd | cat 404filenotfound.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: pWd: Invalid app." + NEW_LINE + "cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | echo ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "pwD | echo echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: pwD: Invalid app." + NEW_LINE + "echo" + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | echo \"fail";
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: Invalid syntax encountered.", e.getMessage());
		}
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidPwdPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "pwD | Echo echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: pwD: Invalid app." + NEW_LINE + "shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "Pwd | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE + expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | Pwd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "Pwd | Pwd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE + "shell: Pwd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeHead() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | head";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString(), result.toString());
	}

	@Test
	public void testInvalidPwdPipeHead() throws AbstractApplicationException, ShellException {
		String cmd = "Pwd | head goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE + TEST_DATA_2, result.toString());
	}

	@Test
	public void testPwdPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | head invalidFile";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalidFile: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "Pwd | head -n p";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE + "head: illegal line count -- p" + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | tail";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString(), result.toString());
	}

	@Test
	public void testInvalidPwdPipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "Pwd | tail goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE + TEST_DATA_2, result.toString());
	}

	@Test
	public void testPwdPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | tail invalidFile";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalidFile: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "Pwd | tail -n p";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE + "tail: illegal offset -- p" + NEW_LINE,
				result.toString());
	}

	@Test
	public void testPwdPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals(expected.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "PWD | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals("shell: PWD: Invalid app." + NEW_LINE + expected.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | DATE";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: DATE: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "PWD | DATE";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: PWD: Invalid app." + NEW_LINE + "shell: DATE: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | sed s/CS4218-Shell/CS4218-Sheaven/";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.getParent() + "\\CS4218-Sheaven" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "Pwd | sed s/st/ar/g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE + TEST_EXPECTED_AR, result.toString());
	}

	@Test
	public void testPwdPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | sed g/st/ar/";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Invalid s'separating symbol' not Found" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "Pwd | sed g/st/ar/ test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE + "sed: Invalid s'separating symbol' not Found" + NEW_LINE, result.toString());
	}

	@Test
	public void testPwdPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | wc -l";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t1", result.toString());
	}

	@Test
	public void testInvalidPwdPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "PWD | wc -lmw \"temp file.txt\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: PWD: Invalid app." + NEW_LINE + "\t2\t3\t11 " + TEST_FILE_3, result.toString());
	}

	@Test
	public void testPwdPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | wc -format";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- format" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidPwdPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "PWD | wc -format";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: PWD: Invalid app." + NEW_LINE + "wc: illegal option -- format" + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidHeadPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "head invalid.txt | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("head: invalid.txt: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | cd invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "head -m 7 test.txt | cd invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE 
				+ "cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | cat";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_1_HEAD, result.toString());
	}

	@Test
	public void testInvalidHeadPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "head -m 6 test.txt | cat test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE 
				+ TEST_DATA_1, result.toString());
	}

	@Test
	public void testHeadPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | cat invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "head test | cat invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: Error reading test" + NEW_LINE + "cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "head -format test.txt|echo hi";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE 
				+ "hi" + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "head goToTest.txt | Echo echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "head invalid | Echo hi";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid: No such file or directory" + NEW_LINE + "shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "head \"temp file.txt\" | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "head \"invalid\" | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid: No such file or directory" + NEW_LINE + expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | Pwd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 6t test.txt | Pwd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: illegal line count -- 6t" + NEW_LINE + "shell: Pwd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeHead1() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | head";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_1_HEAD, result.toString());
	}

	@Test
	public void testHeadPipeHead2() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | head -n 3";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("test 1" + NEW_LINE + "test 2" + NEW_LINE  + "test 3", result.toString());
	}

	@Test
	public void testHeadPipeHead3() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 15 test.txt | head -n 15";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1, result.toString());
	}

	@Test
	public void testInvalidHeadPipeHead() throws AbstractApplicationException, ShellException {
		String cmd = "head -g test.txt | head test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE 
				+ TEST_1_HEAD, result.toString());
	}

	@Test
	public void testHeadPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | head invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "head invalid | head -g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid: No such file or directory" + NEW_LINE + 
				"head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE, result.toString());
	}

	 @Test
	 public void testHeadPipeTail1() throws AbstractApplicationException, ShellException {
	  String cmd = "head test.txt | tail";
	  shell.parseAndEvaluate(cmd, result);
	  assertEquals(TEST_1_HEAD, result.toString());
	 }

	 @Test
	 public void testHeadPipeTail2() throws AbstractApplicationException, ShellException {
	  String cmd = "head test.txt | tail -n 3";
	  shell.parseAndEvaluate(cmd, result);
	  assertEquals("\\t test" + NEW_LINE + "\\n test" + NEW_LINE  + "\\f test", result.toString());
	 }

	 @Test
	 public void testHeadPipeTail3() throws AbstractApplicationException, ShellException {
	  String cmd = "head -n 15 test.txt | tail -n 15";
	  shell.parseAndEvaluate(cmd, result);
	  assertEquals(TEST_DATA_1, result.toString());
	 }

	 @Test
	 public void testInvalidHeadPipeTail() throws AbstractApplicationException, ShellException {
	  String cmd = "head -g test.txt | tail test.txt";
	  shell.parseAndEvaluate(cmd, result);
	  assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE 
	    + TEST_1_TAIL, result.toString());
	 }

	 @Test
	 public void testHeadPipeInvalidTail() throws AbstractApplicationException, ShellException {
	  String cmd = "head test.txt | tail invalid";
	  shell.parseAndEvaluate(cmd, result);
	  assertEquals("tail: invalid: No such file or directory" + NEW_LINE, result.toString());
	 }

	 @Test
	 public void testInvalidHeadPipeInvalidTail() throws AbstractApplicationException, ShellException {
	  String cmd = "head invalid | tail -g test.txt";
	  shell.parseAndEvaluate(cmd, result);
	  assertEquals("head: invalid: No such file or directory" + NEW_LINE + 
	    "tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE, result.toString());
	 }


	@Test
	public void testHeadPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals(expected.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "head invalid.txt | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals("head: invalid.txt: No such file or directory" + NEW_LINE +expected.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | dATe";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: dATe: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "head -format invalid.txt | Date";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE 
				+ "shell: Date: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeSed1() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 13 test.txt | sed s/t/T/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_T + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeSed2() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 1 test.txt | sed s/t/T/";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("Test 1" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "head -n1 test.txt | sed s/test/tear/g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE 
				+ TEST_EXPECTED_AR, result.toString());
	}

	@Test
	public void testHeadPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | sed g/t/T";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Invalid s'separating symbol' not Found" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "head invalid.txt | sed s/t/t/g invalid.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid.txt: No such file or directory" + NEW_LINE + 
				"sed: can't read invalid.txt: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testHeadPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 15 test.txt | wc -lmw";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t11\t23\t108", result.toString());
	}

	@Test
	public void testInvalidHeadPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "head -m 15 test.txt | wc -lmw test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE  + 
				"\t11\t23\t108 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testHeadPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt | wc -format test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- format" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidHeadPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "head invalid | wc -lmw invalid.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid: No such file or directory" + NEW_LINE + 
				"wc: invalid.txt: open: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testTailPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidTailPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "tail invalid.txt | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("tail: invalid.txt: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testTailPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | cd invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "tail -m 7 test.txt | cd invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE
				+ "cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testTailPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | cat";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_1_TAIL, result.toString());
	}

	@Test
	public void testInvalidTailPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "tail -m 6 test.txt | cat test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" 
				+ NEW_LINE + TEST_DATA_1,result.toString());
	}

	@Test
	public void testTailPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | cat invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "tail test | cat invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: Error reading test" + NEW_LINE + "cat: Could not read file" + NEW_LINE,
				result.toString());
	}

	@Test
	public void testTailPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "tail -format test.txt|echo hi";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE + "hi"
				+ NEW_LINE, result.toString());
	}

	@Test
	public void testTailPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "tail goToTest.txt | Echo echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "tail invalid | Echo hi";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid: No such file or directory" + NEW_LINE + "shell: Echo: Invalid app." + NEW_LINE,
				result.toString());
	}

	@Test
	public void testTailPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "tail \"temp file.txt\" | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "tail \"invalid\" | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid: No such file or directory" + NEW_LINE + expDirectory.toString() + NEW_LINE,
				result.toString());
	}

	@Test
	public void testTailPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | Pwd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n 6t test.txt | Pwd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: illegal offset -- 6t" + NEW_LINE + "shell: Pwd: Invalid app." + NEW_LINE,
				result.toString());
	}

	@Test
	public void testTailPipeHead1() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | head";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_1_TAIL, result.toString());
	}

	@Test
	public void testTailPipeHead2() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | head -n 3";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test", result.toString());
	}

	@Test
	public void testTailPipeHead3() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n 15 test.txt | head -n 15";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1, result.toString());
	}

	@Test
	public void testInvalidTailPipeHead() throws AbstractApplicationException, ShellException {
		String cmd = "tail -g test.txt | head test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" 
				+ NEW_LINE + TEST_1_HEAD,result.toString());
	}

	@Test
	public void testTailPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | head invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "tail invalid | head -g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid: No such file or directory" + NEW_LINE + "head: invalid command format" + NEW_LINE
				+ "usage: head [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testTailPipeTail1() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | tail";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_1_TAIL, result.toString());
	}

	@Test
	public void testTailPipeTail2() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | tail -n 3";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\\f test" + NEW_LINE + "\\r test" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"", result.toString());
	}

	@Test
	public void testTailPipeTail3() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n 15 test.txt | tail -n 15";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_DATA_1, result.toString());
	}

	@Test
	public void testInvalidTailPipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "tail -g test.txt | tail test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE 
				+ TEST_1_TAIL,result.toString());
	}

	@Test
	public void testTailPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | tail invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "tail invalid | tail -g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid: No such file or directory" + NEW_LINE + "tail: invalid command format" + NEW_LINE
				+ "usage: tail [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testTailPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals(expected.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "tail invalid.txt | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals("tail: invalid.txt: No such file or directory" + NEW_LINE + expected.toString() + NEW_LINE,
				result.toString());
	}

	@Test
	public void testTailPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | dATe";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: dATe: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "tail -format invalid.txt | Date";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE
				+ "shell: Date: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testTailPipeSed1() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n 13 test.txt | sed s/t/T/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_T + NEW_LINE, result.toString());
	}

	@Test
	public void testTailPipeSed2() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n 1 test.txt | sed s/t/T/";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("!@#$%^&*()-_`~+=/\\|<>,.?\'\"" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n1 test.txt | sed s/test/tear/g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE
				+ TEST_EXPECTED_AR, result.toString());
	}

	@Test
	public void testTailPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | sed g/t/T";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Invalid s'separating symbol' not Found" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "tail invalid.txt | sed s/t/t/g invalid.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid.txt: No such file or directory" + NEW_LINE
				+ "sed: can't read invalid.txt: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testTailPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "tail -n 15 test.txt | wc -lmw";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t11\t23\t108", result.toString());
	}

	@Test
	public void testInvalidTailPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "tail -m 15 test.txt | wc -lmw test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE
				+ "\t11\t23\t108 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testTailPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "tail test.txt | wc -format test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- format" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidTailPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "tail invalid | wc -lmw invalid.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid: No such file or directory" + NEW_LINE + "wc: invalid.txt: open: No such file or directory"
				+ NEW_LINE, result.toString());
	}

	@Test
	public void testDatePipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "date | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidDatePipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "DaTe | cd src";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: DaTe: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testDatePipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "date | cd invalid";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "DaTe | cd invalid";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("shell: DaTe: Invalid app." + NEW_LINE + "cd: No such file or directory" + NEW_LINE,
				result.toString());
	}

	@Test
	public void testDatePipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "date | cat";
		String expected = Calendar.getInstance().getTime().toString();
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expected + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "DaTe | cat test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: DaTe: Invalid app." + NEW_LINE + TEST_DATA_1, result.toString());
	}

	@Test
	public void testDatePipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "date | cat 404filenotfound.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "DaTe | cat 404filenotfound.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: DaTe: Invalid app." + NEW_LINE + "cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testDatePipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "date | echo ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "DaTE | echo echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: DaTE: Invalid app." + NEW_LINE + "echo" + NEW_LINE, result.toString());
	}

	@Test
	public void testDatePipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "date | echo \"fail";
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: Invalid syntax encountered.", e.getMessage());
		}
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidDatePipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "DaTE | Echo echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: DaTE: Invalid app." + NEW_LINE + "shell: Echo: Invalid app." + NEW_LINE,
				result.toString());
	}

	@Test
	public void testDatePipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "date | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "Date | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE + expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testDatePipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "date | Date";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "Date | Date";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE + "shell: Date: Invalid app." + NEW_LINE,
				result.toString());
	}

	@Test
	public void testDatePipeHead() throws AbstractApplicationException, ShellException {
		String cmd = "date | head";
		String expected = Calendar.getInstance().getTime().toString();
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expected, result.toString());
	}

	@Test
	public void testInvalidDatePipeHead() throws AbstractApplicationException, ShellException {
		String cmd = "Date | head goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE + TEST_DATA_2, result.toString());
	}

	@Test
	public void testDatePipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "date | head invalidFile";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalidFile: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "Date | head -n p";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE + "head: illegal line count -- p" + NEW_LINE,
				result.toString());
	}

	@Test
	public void testDatePipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "date | tail";
		String expected = Calendar.getInstance().getTime().toString();
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expected, result.toString());
	}

	@Test
	public void testInvalidDatePipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "Date | tail goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE + TEST_DATA_2, result.toString());
	}

	@Test
	public void testDatePipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "date | tail invalidFile";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalidFile: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "Date | tail -n p";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE + "tail: illegal offset -- p" + NEW_LINE,
				result.toString());
	}

	@Test
	public void testDatePipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "date | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals(expected.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "PWD | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals("shell: PWD: Invalid app." + NEW_LINE + expected.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testDatePipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "date | DATE";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: DATE: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "PWD | DATE";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: PWD: Invalid app." + NEW_LINE + "shell: DATE: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testDatePipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "date | sed s/./-/";
		String expected = "-" + Calendar.getInstance().getTime().toString().substring(1);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expected + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "Date | sed s/st/ar/g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE + TEST_EXPECTED_AR, result.toString());
	}

	@Test
	public void testDatePipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "date | sed g/st/ar/";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Invalid s'separating symbol' not Found" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "Date | sed g/st/ar/ test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE + "sed: Invalid s'separating symbol' not Found" + NEW_LINE,
				result.toString());
	}

	@Test
	public void testDatePipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "date | wc -l";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t1", result.toString());
	}

	@Test
	public void testInvalidDatePipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "PWD | wc -lmw \"temp file.txt\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: PWD: Invalid app." + NEW_LINE + "\t2\t3\t11 " + TEST_FILE_3, result.toString());
	}

	@Test
	public void testDatePipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "date | wc -format";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- format" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidDatePipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "PWD | wc -format";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: PWD: Invalid app." + NEW_LINE + "wc: illegal option -- format" + NEW_LINE,
				result.toString());
	}

	@Test
	public void testSedPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/./t/ test.txt | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);
		
		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidSedPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/./ test.txt | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);
		
		assertEquals(expDirectory, curDirectory);
		assertEquals("sed: Invalid replacement" + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/././ test.txt | cd invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/./ test.txt | cd invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Invalid replacement" + NEW_LINE + "cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T/g test.txt | cat";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_T, result.toString());
	}

	@Test
	public void testInvalidSedPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/. test.txt | cat test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Exception Caught" + NEW_LINE + TEST_DATA_1, result.toString());
	}

	@Test
	public void testSedPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/././ test.txt | cat test";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: This is a directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/. test.txt | cat test";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Exception Caught" + NEW_LINE + "cat: This is a directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/// test.txt | echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/././ test | echo huh?";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: This is a directory" + NEW_LINE + "huh?" + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/// test.txt | Echo echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/././ test | Echo echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: This is a directory" + NEW_LINE + "shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T/ goToTest.txt | pwd";
		shell.parseAndEvaluate(cmd, result);
		File expDirectory = new File(Environment.currentDirectory);
		assertEquals(expDirectory + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T goToTest.txt | pwd";
		shell.parseAndEvaluate(cmd, result);
		File expDirectory = new File(Environment.currentDirectory);
		assertEquals("sed: Exception Caught" + NEW_LINE + expDirectory + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T/g goToTest.txt | PwD";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: PwD: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T goToTest.txt | pwD";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Exception Caught" + NEW_LINE + "shell: pwD: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/^\\w+/false/g test.txt | tail -n 3";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\\f test" + NEW_LINE + "\\r test" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"", result.toString());
	}

	@Test
	public void testInvalidSedPipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/^\\w+/false test.txt | tail -n 3 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Exception Caught" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test" + NEW_LINE + 
				"!@#$%^&*()-_`~+=/\\|<>,.?\'\"",result.toString());
	}

	@Test
	public void testSedPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/^\\w+/false/ test.txt | tail 2 text.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE,
				result.toString());
	}

	@Test
	public void testInvalidSedPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/^\\w+/false test.txt | tail 2 text.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Exception Caught" + NEW_LINE + "tail: invalid command format" + NEW_LINE
				+ "usage: tail [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T/ goToTest.txt | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals(expected + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T goToTest.txt | date";
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		assertEquals("sed: Exception Caught" + NEW_LINE + expected + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T/g goToTest.txt | Date";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T goToTest.txt | Date";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Exception Caught" + NEW_LINE + "shell: Date: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T/g goToTest.txt | sed s/\\./-/";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("TesT-TxT" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T/g goToTest | sed s/\\./-/  goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: can't read goToTest: No such file or directory" + NEW_LINE + "test-txt" , result.toString());
	}

	@Test
	public void testSedPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/t/T/g goToTest.txt | sed s/\\./-/ test";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: This is a directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/\\./-/ test | sed t/t/t/ test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: This is a directory" + NEW_LINE + "sed: Invalid s'separating symbol' not Found" + NEW_LINE, result.toString());
	}

	@Test
	public void testSedPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/st/ar/g test.txt | wc -l";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t11", result.toString());
	}

	@Test
	public void testInvalidSedPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/\\./-/ test | wc -l test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: This is a directory" + NEW_LINE + "\t11 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testSedPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/\\./-/ test.txt | wc -k ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- k" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidSedPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/\\./-/ test | wc -k test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: This is a directory" + NEW_LINE + "wc: illegal option -- k" + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw test.txt | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}

	@Test
	public void testInvalidWcPipeCd() throws AbstractApplicationException, ShellException {
		String cmd = "wc -k test.txt | cd test";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("wc: illegal option -- k" + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw test.txt | cd invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeInvalidCd() throws AbstractApplicationException, ShellException {
		String cmd = "wc -k test.txt | cd invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- k" + NEW_LINE + "cd: No such file or directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw \"temp file.txt\" | cat";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t2\t3\t11 " + TEST_FILE_3, result.toString());
	}

	@Test
	public void testInvalidWcPipeCat() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw test | cat \"temp file.txt\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE + TEST_DATA_3, result.toString());
	}

	@Test
	public void testWcPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw \"temp file.txt\" | cat test";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: This is a directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeInvalidCat() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw test | cat test";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE + "cat: This is a directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw test.txt | echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeEcho() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test | echo echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE +"echo" + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lcm \"temp file.txt\" | Echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- c" + NEW_LINE + "shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeInvalidEcho() throws AbstractApplicationException, ShellException {
		String cmd = "wc -k \"temp file.txt\" | Echo";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- k" + NEW_LINE + "shell: Echo: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw goToTest.txt | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipePwd() throws AbstractApplicationException, ShellException {
		String cmd = "wc -k test.txt | pwd";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- k" + NEW_LINE + expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw test.txt | Pwd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Pwd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeInvalidPwd() throws AbstractApplicationException, ShellException {
		String cmd = "wc -k test.txt | Pwd";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- k" + NEW_LINE + "shell: Pwd: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeHead() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw test.txt | head";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t11\t23\t108 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testInvalidWcPipeHead() throws AbstractApplicationException, ShellException {
		String cmd = "wc -m test | head test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE + TEST_1_HEAD, result.toString());
	}

	@Test
	public void testWcPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test.txt | head -m 77 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("head: invalid command format" + NEW_LINE + "usage: head [-n lines] [file]" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeInvalidHead() throws AbstractApplicationException, ShellException {
		String cmd = "wc -m test | head test";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE + "head: Error reading test" + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw test.txt | tail";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t11\t23\t108 " + TEST_FILE_1, result.toString());
	}

	@Test
	public void testInvalidWcPipeTail() throws AbstractApplicationException, ShellException {
		String cmd = "wc -m test | tail test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE + TEST_1_TAIL, result.toString());
	}

	@Test
	public void testWcPipeInvalidTail() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test.txt | tail -m 77 test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: invalid command format" + NEW_LINE + "usage: tail [-n lines] [file]" + NEW_LINE,
				result.toString());
	}

	@Test
	 public void testInvalidWcPipeInvalidTail() throws AbstractApplicationException, ShellException {
	  String cmd = "wc -m test | tail test";
	  shell.parseAndEvaluate(cmd, result);
	  assertEquals("wc: test: read: Is a directory" + NEW_LINE + "tail: Error reading test" + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw goToTest.txt | date";
		String expected = Calendar.getInstance().getTime().toString();
		shell.parseAndEvaluate(cmd, result);
		assertEquals(expected + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeDate() throws AbstractApplicationException, ShellException {
		String cmd = "wc -k test.txt | date";
		String expected = Calendar.getInstance().getTime().toString();
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- k" + NEW_LINE + expected + NEW_LINE,
				result.toString());
	}

	@Test
	public void testWcPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw test.txt | Date";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: Date: Invalid app." + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeInvalidDate() throws AbstractApplicationException, ShellException {
		String cmd = "wc -k test.txt | Date";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: illegal option -- k" + NEW_LINE + "shell: Date: Invalid app." + NEW_LINE,
				result.toString());
	}

	@Test
	public void testWcPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test.txt | sed s/t/T/";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t11 Test.txt" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeSed() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test | sed s/^t/T/ goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE + "Test.txt", result.toString());
	}

	@Test
	public void testWcPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test.txt | sed s/^t/ goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("sed: Invalid replacement" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeInvalidSed() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test | sed s/^t/ goToTest.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE + "sed: Invalid replacement" + NEW_LINE, result.toString());
	}

	@Test
	public void testWcPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test.txt | wc -l";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t1", result.toString());
	}

	@Test
	public void testInvalidWcPipeWc() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test | wc -lmw \"temp file.txt\"";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE + "\t2\t3\t11 " + TEST_FILE_3, result.toString());
	}

	@Test
	public void testWcPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "wc -lmw \"temp file.txt\" | wc -l test";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE, result.toString());
	}

	@Test
	public void testInvalidWcPipeInvalidWc() throws AbstractApplicationException, ShellException {
		String cmd = "wc -l test | wc -l invalid";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("wc: test: read: Is a directory" + NEW_LINE + "wc: invalid: open: No such file or directory" + NEW_LINE, result.toString());
	}

	private static void createTxtFile(String fileName, String data) throws FileNotFoundException {
		PrintWriter writer = new PrintWriter(fileName);
		writer.print(data);
		writer.close();
	}

	private static void deleteFile(String fileName) {
		File file = new File(fileName);
		file.delete();
	}
}
