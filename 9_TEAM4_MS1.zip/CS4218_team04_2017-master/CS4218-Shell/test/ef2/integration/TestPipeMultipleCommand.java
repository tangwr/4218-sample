package ef2.integration;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestPipeMultipleCommand {
	private static final String NEW_LINE = System.getProperty("line.separator");
	private static final String TEST_FILE_1 = "test.txt";
	private static final String TEST_FILE_2 = "goToTest.txt";

	private static final String TEST_DATA_1 = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
			+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_DATA_2 = "test.txt";

	private static final String TEST_EXPECTED_T = "TesT 1" + NEW_LINE + "TesT 2" + NEW_LINE + "TesT 3" + NEW_LINE + "3 TesT" + NEW_LINE
			+ "2 TesT" + NEW_LINE + "1 TesT" + NEW_LINE + "\\b TesT" + NEW_LINE + "\\T TesT" + NEW_LINE + "\\n TesT" + NEW_LINE + "\\f TesT" + NEW_LINE
			+ "\\r TesT" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_EXPECTED_AR = "tear 1" + NEW_LINE + "tear 2" + NEW_LINE + "tear 3" + NEW_LINE + "3 tear" + NEW_LINE
			+ "2 tear" + NEW_LINE + "1 tear" + NEW_LINE + "\\b tear" + NEW_LINE + "\\t tear" + NEW_LINE + "\\n tear" + NEW_LINE + "\\f tear" + NEW_LINE
			+ "\\r tear" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_EXPECTED_DASH = "------" + NEW_LINE + "------" + NEW_LINE + "------" + NEW_LINE + "------" + NEW_LINE + "------"
			+ NEW_LINE + "------" + NEW_LINE + "-------" + NEW_LINE + "-------" + NEW_LINE + "-------" + NEW_LINE + "-------" + NEW_LINE + "-------"
			+ NEW_LINE + "--------------------------";

	private static final String TEST_1_HEAD = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test";
	private static final String TEST_1_TAIL = "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test" + NEW_LINE + "1 test" + NEW_LINE + "\\b test"
			+ NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test" + NEW_LINE
			+ "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";

	private static ShellImpl shell;
	private static ByteArrayOutputStream result;
	private static File initDirectory;

	// cd cat echo pwd head tail date sed wc

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	@BeforeClass
	public static void setUpOnce() throws FileNotFoundException {
		createTxtFile(TEST_FILE_1, TEST_DATA_1);
		createTxtFile(TEST_FILE_2, TEST_DATA_2);
		shell = new ShellImpl();
		result = new ByteArrayOutputStream();
		System.setOut(new PrintStream(result));
	}

	@AfterClass
	public static void tearDownOnce() {
		deleteFile(TEST_FILE_1);
		deleteFile(TEST_FILE_2);
		System.out.close();
	}

	@After
	public void tearDown() throws IOException {
		result.reset();
		Environment.currentDirectory = initDirectory.getCanonicalPath();
	}

	@Before
	public void setUp() {
		initDirectory = new File(Environment.currentDirectory);
	}

	@Test
	public void testPipeThreeCommands() throws AbstractApplicationException, ShellException {
		String cmd = "cd test | cat test.txt | sed s/t/T/g";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(TEST_EXPECTED_T + NEW_LINE, result.toString());
	}

	@Test
	public void testPipeThreeCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "cd temp | cat test.txt | sed s/t/T/g";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("cd: No such file or directory" + NEW_LINE + TEST_EXPECTED_T + NEW_LINE, result.toString());
	}

	@Test
	public void testPipeFourCommands() throws AbstractApplicationException, ShellException {
		String cmd = "echo 1 | pwd | cat test.txt | sed s/./-/g ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_DASH + NEW_LINE, result.toString());
	}

	@Test
	public void testPipeFourCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "echo 1 | pwd | cat text.txt | sed s/./-/g ";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE, result.toString());
	}

	@Test
	public void testPipeFiveCommands() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt | sed s/t/T/g | cat | sed s/sT/ar/g | sed s/T/t/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_AR + NEW_LINE, result.toString());
	}

	@Test
	public void testPipeFiveCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "cat test1.txt | sed s/t/T/g | eccho etes | cat goToTest.txt | sed s/\\./-/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "shell: eccho: Invalid app." + NEW_LINE + "test-txt" 
				+ NEW_LINE, result.toString());
	}

	@Test
	public void testPipeSixCommands() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 9 test.txt | tail -n 8 | head -n 7 | tail -n 6 | head -n 5 | tail -n 4";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("3 test" + NEW_LINE + "2 test" + NEW_LINE + "1 test" + NEW_LINE  + "\\b test", result.toString());
	}

	@Test
	public void testPipeSixCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "head -n 9 test.txt | tail -n a | head -n 7 | tail -n 6 test.txt | head -n 2 | tail -n 4";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("tail: illegal offset -- a" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test", result.toString());
	}

	@Test
	public void testPipeSevenCommands() throws AbstractApplicationException, ShellException {
		String cmd = "echo hi | cat test.txt | sed s/t/T/g | cat | sed s/./-/g | cat | sed s///";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_EXPECTED_DASH + NEW_LINE, result.toString());
	}

	@Test
	public void testPipeSevenCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "echo hi | cat tempFile.txt | sed s/t/T/g hi | cat pmet.txt | sed s/t/T/g bye | cat test.txt | sed s/t/T/g";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "sed: can't read hi: No such file or directory" + NEW_LINE  
				+ "cat: Could not read file" + NEW_LINE + "sed: can't read bye: No such file or directory" + NEW_LINE 
				+ TEST_EXPECTED_T + NEW_LINE, result.toString());
	}

	@Test
	public void testPipeEightCommands() throws AbstractApplicationException, ShellException {
		String cmd = "pwd | date | echo Hey |cat|sed s/H/h/|cat|cd ~| head test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals(TEST_1_HEAD, result.toString());
	}

	@Test
	public void testPipeEightCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "pWd | daTe | Echo Hey |cAt|sed s/H/h/ fileNotFound|caT|cd ~| tail test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("shell: pWd: Invalid app." + NEW_LINE + "shell: daTe: Invalid app." + NEW_LINE 
				+ "shell: Echo: Invalid app." + NEW_LINE + "shell: cAt: Invalid app." + NEW_LINE 
				+ "sed: can't read fileNotFound: No such file or directory" + NEW_LINE 
				+ "shell: caT: Invalid app." + NEW_LINE + TEST_1_TAIL, result.toString());
	}

	@Test
	public void testPipeNineCommands() throws AbstractApplicationException, ShellException {
		String cmd = "cd test | echo Piping 9 commands |date|pwd|cat test.txt|head -n 3|tail|sed s/t/T/g|wc -l";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("\t2", result.toString());
	}
	
	@Test
	public void testPipeNineCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "cd ~ | echo Piping 9 commands |date|pwd|cat text.txt|head -n 7|tail -n p|sed s/t/T/g|wc -f";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("cat: Could not read file" + NEW_LINE + "tail: illegal offset -- p" + NEW_LINE 
				+ "wc: illegal option -- f" + NEW_LINE, result.toString());
	}

	private static void createTxtFile(String fileName, String data) throws FileNotFoundException {
		PrintWriter writer = new PrintWriter(fileName);
		writer.print(data);
		writer.close();
	}

	private static void deleteFile(String fileName) {
		File file = new File(fileName);
		file.delete();
	}

}
