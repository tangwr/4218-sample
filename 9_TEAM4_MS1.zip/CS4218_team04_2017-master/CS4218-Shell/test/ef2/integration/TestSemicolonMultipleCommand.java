package ef2.integration;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestSemicolonMultipleCommand {
	private static final String NEW_LINE = System.getProperty("line.separator");
	private static final String TEST_FILE_1 = "test.txt";
	private static final String TEST_FILE_2 = "goToTest.txt";

	private static final String TEST_DATA_1 = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
			+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_DATA_2 = "test.txt";

	private static final String TEST_EXPECTED_AR = "tear 1" + NEW_LINE + "tear 2" + NEW_LINE + "tear 3" + NEW_LINE + "3 tear" + NEW_LINE
			+ "2 tear" + NEW_LINE + "1 tear" + NEW_LINE + "\\b tear" + NEW_LINE + "\\t tear" + NEW_LINE + "\\n tear" + NEW_LINE + "\\f tear" + NEW_LINE
			+ "\\r tear" + NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_EXPECTED_DASH = "------" + NEW_LINE + "------" + NEW_LINE + "------" + NEW_LINE + "------" + NEW_LINE + "------"
			+ NEW_LINE + "------" + NEW_LINE + "-------" + NEW_LINE + "-------" + NEW_LINE + "-------" + NEW_LINE + "-------" + NEW_LINE + "-------"
			+ NEW_LINE + "--------------------------";

	private static final String TEST_1_HEAD = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test";
	private static final String TEST_1_TAIL = "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test" + NEW_LINE + "1 test" + NEW_LINE + "\\b test"
			+ NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test" + NEW_LINE
			+ "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";

	private static ShellImpl shell;
	private static ByteArrayOutputStream result;
	private static File initDirectory;

	// cd cat echo pwd head tail date sed wc

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	@BeforeClass
	public static void setUpOnce() throws FileNotFoundException {
		createTxtFile(TEST_FILE_1, TEST_DATA_1);
		createTxtFile(TEST_FILE_2, TEST_DATA_2);
		shell = new ShellImpl();
		result = new ByteArrayOutputStream();
		System.setOut(new PrintStream(result));
	}

	@AfterClass
	public static void tearDownOnce() {
		deleteFile(TEST_FILE_1);
		deleteFile(TEST_FILE_2);
		System.out.close();
	}

	@After
	public void tearDown() throws IOException {
		result.reset();
		Environment.currentDirectory = initDirectory.getCanonicalPath();
	}

	@Before
	public void setUp() {
		initDirectory = new File(Environment.currentDirectory);
	}

	@Test
	public void testSemicoloThreeCommands() throws AbstractApplicationException, ShellException {
		String cmd = "cd test; pwd; cd ..";
		File expDirectory = new File(Environment.currentDirectory);
		File pwdDirectory = new File(Environment.currentDirectory, "test");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(pwdDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testSemicoloThreeCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "cd test; invalid; cd ..";
		File expDirectory = new File(Environment.currentDirectory, "test");
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: invalid: Invalid app.", e.getMessage());
		}
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
	}

	@Test
	public void testSemicoloFourCommands() throws AbstractApplicationException, ShellException {
		String cmd = "echo test; head -n 1 test.txt; tail -n 1 test.txt; sed s/./-/g test.txt";
		shell.parseAndEvaluate(cmd, result);
		assertEquals("test" + NEW_LINE + "test 1" + "!@#$%^&*()-_`~+=/\\|<>,.?'\"" + TEST_EXPECTED_DASH, result.toString());
	}

	@Test
	public void testSemicoloFourCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "date; cat test.txt; invalid; cat goToTest.txt";
		String date = Calendar.getInstance().getTime().toString();
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: invalid: Invalid app.", e.getMessage());
		}
		assertEquals(date + NEW_LINE + TEST_DATA_1, result.toString());
	}

	@Test
	public void testSemicoloFiveCommands() throws AbstractApplicationException, ShellException {
		String cmd = "cd `echo \"test\"`; pwd; cd ../src; pwd; cd `echo '../test'`";
		File expDirectory = new File(Environment.currentDirectory, "test");
		File pwdDirectory = new File(Environment.currentDirectory, "src");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(expDirectory.toString() + NEW_LINE + pwdDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testSemicoloFiveCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "date; wc -lmw test.txt; cat test.txt; invalid; echo failed to run this";
		String date = Calendar.getInstance().getTime().toString();
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: invalid: Invalid app.", e.getMessage());
		}
		
		assertEquals(date + NEW_LINE + "\t11\t23\t108 " + TEST_FILE_1 + TEST_DATA_1, result.toString());
	}

	@Test
	public void testSemicoloSixCommands() throws AbstractApplicationException, ShellException {
		String cmd = "sed s/./K/ goToTest.txt; echo two; echo `cat goToTest.txt`; pwd; cd test; pwd";
		File expDirectory1 = new File(Environment.currentDirectory);
		File expDirectory2 = new File(Environment.currentDirectory, "test");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory2, curDirectory);
		assertEquals("Kest.txt" + "two" + NEW_LINE + TEST_DATA_2 + NEW_LINE + expDirectory1.toString() + 
				NEW_LINE + expDirectory2.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testSemicoloSixCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "echo `sed s/t/T/g goToTest.txt`; date; echo `date`; echo `pwd`; invalid; cd ~";
		String date = Calendar.getInstance().getTime().toString();
		File expDirectory = new File(Environment.currentDirectory);
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: invalid: Invalid app.", e.getMessage());
		}
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("TesT.TxT" + NEW_LINE + date + NEW_LINE + date + NEW_LINE + expDirectory.toString() + NEW_LINE, result.toString());
	}

	@Test
	public void testSemicoloSevenCommands() throws AbstractApplicationException, ShellException {
		String cmd = "cd ..; pwd; cd ..; pwd; cd ..; pwd; cd ~";
		
		String userHome = System.getProperty("user.home");
		File initDirectory = new File(Environment.currentDirectory);
		String expDirectory1 = initDirectory.getParent();
		File nextDirectory1 = new File(expDirectory1);
		String expDirectory2 = nextDirectory1.getParent();
		File nextDirectory2 = new File(expDirectory2);
		String expDirectory3 = nextDirectory2.getParent();
		
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(userHome, curDirectory.toString());
		assertEquals(expDirectory1 + NEW_LINE + expDirectory2 + NEW_LINE + expDirectory3 + NEW_LINE, result.toString());
	}

	@Test
	public void testSemicoloSevenCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "echo Hello; date; echo Welcome; pwd; echo This is End; echo `cat test.txt`; echo not printed";
		String date = Calendar.getInstance().getTime().toString();
		File expDirectory = new File(Environment.currentDirectory);
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: Invalid syntax encountered.", e.getMessage());
		}
		
		assertEquals("Hello" + NEW_LINE + date + NEW_LINE + "Welcome" + NEW_LINE + expDirectory.toString() + 
				NEW_LINE + "This is End" + NEW_LINE, result.toString());
		
	}

	@Test
	public void testSemicoloEightCommands() throws AbstractApplicationException, ShellException {
		String cmd = "head test.txt; tail test.txt; cd test; pwd; date; cd ..; head test.txt; tail test.txt";
		String date = Calendar.getInstance().getTime().toString();
		File expDirectory = new File(Environment.currentDirectory, "test");
		shell.parseAndEvaluate(cmd, result);

		assertEquals(TEST_1_HEAD + TEST_1_TAIL + expDirectory.toString() + NEW_LINE + date + NEW_LINE + 
				TEST_1_HEAD + TEST_1_TAIL, result.toString());
	}

	@Test
	public void testSemicoloEightCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "echo `sed s/txt/jpg/ goToTest.txt` ; date ; pwd; echo fourth command; cd test; cd ../src; cd..; echo eight";
		String date = Calendar.getInstance().getTime().toString();
		File expDirectory1 = new File(Environment.currentDirectory);
		File expDirectory2 = new File(Environment.currentDirectory, "src");
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: cd..: Invalid app.", e.getMessage());
		}
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory2, curDirectory);
		assertEquals("test.jpg" + NEW_LINE + date + NEW_LINE + expDirectory1.toString() + NEW_LINE + 
				"fourth command" + NEW_LINE, result.toString());
	}

	@Test
	public void testSemicoloNineCommands() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt; cd test/..; date; echo all commands; head goToTest.txt; pwd;"
				+ " sed s/st/ar/g test.txt; tail goToTest.txt; wc -lm goToTest.txt";
		String date = Calendar.getInstance().getTime().toString();
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(TEST_DATA_1 + date + NEW_LINE + "all commands" + NEW_LINE + TEST_DATA_2 + expDirectory.toString() + 
				NEW_LINE + TEST_EXPECTED_AR + TEST_DATA_2 + "\t1\t8 " + TEST_FILE_2, result.toString());
	}

	@Test
	public void testSemicoloNineCommandsWithInvalid() throws AbstractApplicationException, ShellException {
		String cmd = "cat test.txt; cd test/..; date; echo all commands; head goToTest.txt; pwd;"
				+ " sed s/st/ar/g test.txt; tail -n 0 goToTest.txt; wc -lm goToTest.txt";
		String date = Calendar.getInstance().getTime().toString();
		File expDirectory = new File(Environment.currentDirectory);
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("tail: illegal line count -- 0", e.getMessage());
		}
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(TEST_DATA_1 + date + NEW_LINE + "all commands" + NEW_LINE + TEST_DATA_2 + expDirectory.toString() + 
				NEW_LINE + TEST_EXPECTED_AR + "\t1\t8 " + TEST_FILE_2 , result.toString());
	}

	private static void createTxtFile(String fileName, String data) throws FileNotFoundException {
		PrintWriter writer = new PrintWriter(fileName);
		writer.print(data);
		writer.close();
	}

	private static void deleteFile(String fileName) {
		File file = new File(fileName);
		file.delete();
	}

}
