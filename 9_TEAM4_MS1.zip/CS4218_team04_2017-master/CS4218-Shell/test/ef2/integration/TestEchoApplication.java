package ef2.integration;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestEchoApplication {
    static ShellImpl shell;
    static ByteArrayOutputStream testOut;
    private static final String NEW_LINE = System.getProperty("line.separator");
    
    @Rule
    public ExpectedException expectedEx = ExpectedException.none();
    
    @Test
    public void testEchoNoArg() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo", testOut);
        assertEquals(NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoNoArgWithSpaces() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo   ", testOut);
        assertEquals(NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoSingleArgUnquoted() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo test", testOut);
        assertEquals("test" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoSingleArgSingleQuoted() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo \'some text\'", testOut);
        assertEquals("some text" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoSingleArgSingleQuotedWithSpecialCharacters() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo \'some text`\'", testOut);
        assertEquals("some text`" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoSingleArgSingleQuotedWithBackQuote() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo \'some `text`\'", testOut);
        assertEquals("some `text`" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoSingleArgDoubleQuoted() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo \"some text\"", testOut);
        assertEquals("some text" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoMultipleArgsUnquoted() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo some text", testOut);
        assertEquals("some text" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoMultipleArgsSingleQuoted() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo \'some text\' \'more text\'", testOut);
        assertEquals("some text more text" + NEW_LINE, testOut.toString());
    }
    
    @Test
    public void testEchoMultipleArgsDoubleQuoted() throws AbstractApplicationException, ShellException {
        shell.parseAndEvaluate("echo \"some text\" \"more text\"", testOut);
        assertEquals("some text more text" + NEW_LINE, testOut.toString());
    }
    
    @BeforeClass
    public static void setUpOnce() {
        shell = new ShellImpl();
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }
    
    @AfterClass
    public static void tearDownOnce() {
        System.setOut(null);
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        testOut.reset();
    }
}
