package ef2.integration;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.ShellException;
import sg.edu.nus.comp.cs4218.impl.ShellImpl;

public class TestCommandWithPipeAndSemicolon {
	private static final String NEW_LINE = System.getProperty("line.separator");
	private static final String TEST_FILE_1 = "test.txt";
	private static final String TEST_FILE_2 = "goToTest.txt";
	private static final String TEST_FOLDER = "temp folder";

	private static final String TEST_DATA_1 = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test"
			+ NEW_LINE + "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";
	private static final String TEST_DATA_2 = "test.txt";

	private static final String TEST_EXPECTED_DASH = "------" + NEW_LINE + "------" + NEW_LINE + "------" + NEW_LINE + "------" + NEW_LINE + "------"
			+ NEW_LINE + "------" + NEW_LINE + "-------" + NEW_LINE + "-------" + NEW_LINE + "-------" + NEW_LINE + "-------" + NEW_LINE + "-------"
			+ NEW_LINE + "--------------------------";

	private static final String TEST_1_HEAD = "test 1" + NEW_LINE + "test 2" + NEW_LINE + "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test"
			+ NEW_LINE + "1 test" + NEW_LINE + "\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test";
	private static final String TEST_1_TAIL = "test 3" + NEW_LINE + "3 test" + NEW_LINE + "2 test" + NEW_LINE + "1 test" + NEW_LINE + "\\b test"
			+ NEW_LINE + "\\t test" + NEW_LINE + "\\n test" + NEW_LINE + "\\f test" + NEW_LINE + "\\r test" + NEW_LINE
			+ "!@#$%^&*()-_`~+=/\\|<>,.?\'\"";

	private static ShellImpl shell;
	private static ByteArrayOutputStream result;
	private static File initDirectory;

	// cd cat echo pwd head tail date sed wc

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	@BeforeClass
	public static void setUpOnce() throws FileNotFoundException {
		createTxtFile(TEST_FILE_1, TEST_DATA_1);
		createTxtFile(TEST_FILE_2, TEST_DATA_2);
		new File(TEST_FOLDER).mkdir();
		shell = new ShellImpl();
		result = new ByteArrayOutputStream();
		System.setOut(new PrintStream(result));
	}

	@AfterClass
	public static void tearDownOnce() {
		deleteFile(TEST_FILE_1);
		deleteFile(TEST_FILE_2);
		new File(TEST_FOLDER).delete();
		System.out.close();
	}

	@After
	public void tearDown() throws IOException {
		result.reset();
		Environment.currentDirectory = initDirectory.getCanonicalPath();
	}

	@Before
	public void setUp() {
		initDirectory = new File(Environment.currentDirectory);
	}

	@Test
	public void testPipeThenSemicolon() throws AbstractApplicationException, ShellException {
		String cmd = "date | sed \"s|.|-|\"; cd \"temp folder\"";
		File expDirectory = new File(Environment.currentDirectory, TEST_FOLDER);
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("-" + expected.substring(1) + NEW_LINE, result.toString());
	}
	
	@Test
	public void testSemicolonThenPipe() throws AbstractApplicationException, ShellException {
		String cmd = "cd test ; head -n 9 ../test.txt | tail -n 6";
		File expDirectory = new File(Environment.currentDirectory, "test");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("3 test" + NEW_LINE + "2 test" + NEW_LINE + "1 test" + NEW_LINE + 
				"\\b test" + NEW_LINE + "\\t test" + NEW_LINE + "\\n test", result.toString());
	}
	
	@Test
	public void testPipeAndSemicolonVariation1() throws AbstractApplicationException, ShellException {
		String cmd = "cd test ; echo Thisis something fun | sed s/^([\\w\\-]+)/\"This is\"/ ; pwd | cat ; cd ..";
		File expDirectory1 = new File(Environment.currentDirectory, "test");
		File expDirectory2 = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory2, curDirectory);
		assertEquals("This is something fun" + NEW_LINE + expDirectory1.toString() + NEW_LINE, result.toString());
	}
	
	@Test
	public void testPipeAndSemicolonVariation2() throws AbstractApplicationException, ShellException {
		String cmd = "pwd ; cat goToTest.txt | cat | sed s/./-/g ; head test.txt ; cd ~ | cd test | tail test.txt ; date";
		File expDirectory = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(expDirectory.toString() + NEW_LINE + "--------" + NEW_LINE + TEST_1_HEAD + TEST_1_TAIL + 
				expected + NEW_LINE, result.toString());
	}

	@Test
	public void testPipeAndSemicolonVariation3() throws AbstractApplicationException, ShellException {
		String cmd = "sed s$.$-$g test.txt; head -n 6 test.txt | tail -n 3 | cat | echo | pwd | wc -l ; cd ~";
		String homeDirectory = System.getProperty("user.home");
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(homeDirectory, curDirectory.toString());
		assertEquals(TEST_EXPECTED_DASH + "\t1", result.toString());
	}
	
	@Test
	public void testPipeAndSemicolonVariation4() throws AbstractApplicationException, ShellException {
		String cmd = "cd test ; cd .. | echo Last Test Here | cat ; cd .. | pwd ; cd .. ; date \"to be ignored\"";
		File expDirectory1 = new File(Environment.currentDirectory);
		File expDirectory2 = new File(Environment.currentDirectory, "test");
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory1, curDirectory);
		assertEquals("Last Test Here" + NEW_LINE + expDirectory2.toString() + NEW_LINE + expected + NEW_LINE, result.toString());
	}
	
	@Test
	public void testPipeAndSemicolonVariationWithInvalid1() throws AbstractApplicationException, ShellException {
		String cmd = "cd `echo test` ; echo Thisis something fun | sed s/^([\\w\\-]+)/\"This is\" ; pwd | cat ; cd ..";
		File expDirectory1 = new File(Environment.currentDirectory, "test");
		File expDirectory2 = new File(Environment.currentDirectory);
		shell.parseAndEvaluate(cmd, result);
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory2, curDirectory);
		assertEquals("shell: Invalid syntax encountered." + NEW_LINE + expDirectory1.toString() + NEW_LINE, result.toString());
	}
	
	@Test
	public void testPipeAndSemicolonVariationWithInvalid2() throws AbstractApplicationException, ShellException {
		String cmd = "pwd ; cat goToTest.txt | cat | sed s/./-/g ; head test.txt ; cd ~ | cd NoSuchFileOfFolder | tail test.txt ; datE";
		File expDirectory = new File(Environment.currentDirectory);
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: datE: Invalid app." ,e.getMessage());
		}
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(expDirectory.toString() + NEW_LINE + "--------" + NEW_LINE + TEST_1_HEAD + "cd: No such file or directory" 
				+ NEW_LINE + TEST_1_TAIL, result.toString());
	}

	@Test
	public void testPipeAndSemicolonVariationWithInvalid3() throws AbstractApplicationException, ShellException {
		String cmd = "sed s$.$-$g test.txt; head -n 6 test.txt | tail -n 3 | Cat | echo | Pwd | wc -k ; cd~";
		File expDirectory = new File(Environment.currentDirectory);
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("shell: cd~: Invalid app." ,e.getMessage());
		}
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals(TEST_EXPECTED_DASH + "shell: Cat: Invalid app." + NEW_LINE + "shell: Pwd: Invalid app." 
				+ NEW_LINE + "wc: illegal option -- k" + NEW_LINE, result.toString());
	}
	
	@Test
	public void testPipeAndSemicolonVariationWithInvalid4() throws AbstractApplicationException, ShellException {
		String cmd = "sed $.$-$g test.txt; head -n 6 test.txt | tail -n 3 | Cat | echo | pwd | wc -l ; cd~";
		File expDirectory = new File(Environment.currentDirectory);
		try {
			shell.parseAndEvaluate(cmd, result);
		} catch (Exception e) {
			assertEquals("sed: Invalid s'separating symbol' not Found" ,e.getMessage());
		}
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory, curDirectory);
		assertEquals("", result.toString());
	}
	
	@Test
	public void testPipeAndSemicolonVariationWithInvalid5() throws AbstractApplicationException, ShellException {
		String cmd = "cd test ; cd .. | echo `echo Last Test Here` | cat ; cd.. | pwd ; cd .. ; date \"to be ignored\"";
		File expDirectory1 = new File(Environment.currentDirectory);
		File expDirectory2 = new File(Environment.currentDirectory, "test");
		shell.parseAndEvaluate(cmd, result);
		String expected = Calendar.getInstance().getTime().toString();
		File curDirectory = new File(Environment.currentDirectory);

		assertEquals(expDirectory1, curDirectory);
		assertEquals("Last Test Here" + NEW_LINE + "shell: cd..: Invalid app." + NEW_LINE + expDirectory2.toString() + 
				NEW_LINE + expected + NEW_LINE, result.toString());
	}

	private static void createTxtFile(String fileName, String data) throws FileNotFoundException {
		PrintWriter writer = new PrintWriter(fileName);
		writer.print(data);
		writer.close();
	}

	private static void deleteFile(String fileName) {
		File file = new File(fileName);
		file.delete();
	}
}
