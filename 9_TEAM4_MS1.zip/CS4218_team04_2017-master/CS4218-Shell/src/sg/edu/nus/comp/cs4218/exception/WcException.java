/**
 * 
 */
package sg.edu.nus.comp.cs4218.exception;

/**
 * @author pixelducky
 *
 */
public class WcException extends AbstractApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8535567786679220113L;

	/**
	 * @param message
	 */
	public WcException(String message) {
		super("wc: " + message);
	}

}
