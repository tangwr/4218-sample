package sg.edu.nus.comp.cs4218.impl.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.app.Sed;
import sg.edu.nus.comp.cs4218.exception.SedException;

public class SedApplication implements Sed{
	// cd /c/users/chiang-dell/desktop/development
	// sed s/t/T/ test1.txt
	String currSymbol=null;
	String contentToAppend="";
	String result = "";
	String regex="";
	String replacement="";
	public SedApplication(){}
	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws SedException {
		//	cd /c/users/chiang-dell/desktop/development
		// TEST 1 : sed s/t/T test.txt 							 [not accepted][supported][need T/ follow bash]
		// TEST 2 : sed s/t/T/ development/test1.txt 			 [not accepted][supported][no such dir follow bash]
		// TEST 3 : sed s/t/T/ /development/test1.txt 			 [not accepted][supported][no such dir follow bash]
		// TEST 4 : sed s/t/T/ ../development/test1.txt 		 [not accepted][from diff directory][supported]
		// TEST 5 : sed s/t/T/g/ test1.txt 						 [not accepted][supported][no need /, just g]
		// TEST 6 : sed s/t/ test1.txt 							 [not accepted][wrong replacement rule]

		// TEST 7 : sed s/t/T/ ../development/test1.txt 		 [accepted][from same directory][supported]
		// TEST 8 : sed s/t/T/ test1.txt 						 [accepted][supported][first t turn T]
		// TEST 9 : sed s/t/T/g test1.txt 						 [accepted][supported][all t turn T]
		// TEST 10: sed s/t// test1.txt 						 [accepted][supported][first t turn nothing]
		// TEST 11: sed s/t//g test1.txt 						 [accepted][supported][all t turn nothing]

		// TEST 12: sed s/t/T/ ../development/"test1 test1".txt  [accepted][not supported][space havent fix]
		// TEST 13: sed s/t/T/ ../development/"test1 test1.txt"  [accepted][not supported][space havent fix]
		// TEST 14: sed s/t/t/ ../development/test1\ test1.txt 	 [accepted][not supported][christina say this command invalid]
		// TEST 15: cat test1.txt | sed s/t/T/ test2.txt
		// TEST 16: cat test1.txt | sed s/t/T/ "test1 test1".txt [accepted][not supported]["test1 test1 will be executed"]
		
		if (args == null || args.length == 0) {
			throw new SedException("Exception Caught");
		}
		else if((args.length==1 && stdin!=null)) //REPLACEMENT and [stdin's content]
		{
			
			try {
				contentToAppend = readFromStream(stdin);
			} catch (IOException e) {}
			currSymbol = extractCurrSymbol(args[0]);
			checkS(args[0]);//[Check First 2 chars]
			if( checkEndSlashG(args[0]) ){//[Check Last 2 chars]
				String trimmedReplacement=args[0].substring(2, args[0].length()-2);
				process(trimmedReplacement,"stdinforall");
			}
			else if( checkEndSlash(args[0]) ){//[Check Last Char]
				String trimmedReplacement=args[0].substring(2, args[0].length()-1);
				process(trimmedReplacement,"stdinforfirst");
			}
			else
			{
				throw new SedException("Exception Caught");
			}
		}
		else if(args.length==2)//REPLACEMENT and [FILE]
		{
			//System.out.println("here");
			File file = checkTextFileExistence(args[1]);
			
			try {
				contentToAppend = readFromFile(file);
			} catch (IOException e) {}
			currSymbol = extractCurrSymbol(args[0]);
			checkS(args[0]);//[Check First 2 chars]
			if( checkEndSlashG(args[0]) ) {//[Check Last 2 chars]
				String trimmedReplacement=args[0].substring(2, args[0].length()-2);
				process(trimmedReplacement,"argforall");
			}
			else if( checkEndSlash(args[0]) ){//[Check Last Char]
				String trimmedReplacement=args[0].substring(2, args[0].length()-1);
				process(trimmedReplacement,"argforfirst");
			}
			else{
				throw new SedException("Exception Caught");
			}
		}
		else
		{
			throw new SedException("Exception Caught");
		}
		writeToStdOut(stdout);
	}
	private void process(String trimmedReplacement,String strIdentity) throws SedException {
		checks(trimmedReplacement);

		if(strIdentity.equals("stdinforall")){
			result = replaceAllSubstringsInStdin(trimmedReplacement);// s/t/T/g -> t/T		
		}
		else if(strIdentity.equals("stdinforfirst")){
			result = replaceFirstSubStringFromStdin(trimmedReplacement);// s/t/T/g -> t/T		
		}
		else if(strIdentity.equals("argforfirst")){
			result = replaceFirstSubStringInFile(trimmedReplacement);// s/t/T/g -> t/T		
		}
		else if(strIdentity.equals("argforall")){
			result = replaceAllSubstringsInFile(trimmedReplacement);// s/t/T/g -> t/T		
		}
		else{
			throw new SedException("Invalid replacement");
		}
	}
	private void checks(String trimmedReplacement) throws SedException {
		int posOfCuttingSymbol = trimmedReplacement.indexOf(currSymbol);
		if(posOfCuttingSymbol==-1){
			throw new SedException("Invalid replacement");
		}
		regex = trimmedReplacement.substring(0, posOfCuttingSymbol);
		replacement = trimmedReplacement.substring(posOfCuttingSymbol+1,trimmedReplacement.length());
		if(regex.length()>1 && replacement.length()>1)
		{
			if( regex.substring(0,1).equals("'") && regex.substring(regex.length()-1,regex.length()).equals("'")&& !currSymbol.equals("'") 
				|| 
			regex.substring(0,1).equals("\"") && regex.substring(regex.length()-1,regex.length()).equals("\"")&& !currSymbol.equals("\"")){
			regex = regex.substring(1,regex.length()-1);
			}
			if(replacement.substring(0,1).equals("'") && replacement.substring(replacement.length()-1,replacement.length()).equals("'") && !currSymbol.equals("'")
					|| 
					replacement.substring(0,1).equals("\"") && replacement.substring(replacement.length()-1,replacement.length()).equals("\"")&& !currSymbol.equals("\"")){
				replacement = replacement.substring(1,replacement.length()-1);
			}
		}
		
		checkOnlyOneSlash(trimmedReplacement);
		checkRegex(regex);
		checkReplacement(replacement);		
	}
	private void writeToStdOut(OutputStream stdout) {
		//System.out.println(result); //sed s/t/T/ hotandsexy.txt
		try {
			stdout.write(result.getBytes());
			stdout.flush();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private String matchAndReplace(String regex, String replacement,boolean firstOrAll) {
		
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(contentToAppend);
		if(firstOrAll==true){//true=first
			return matcher.replaceFirst(replacement);		
		}
		else{//false=all
			return matcher.replaceAll(replacement);		
		}
	}
	@Override
	public String replaceFirstSubStringInFile(String args) {
		//[sed s/t/T/ test1.txt ] -> [t/T]
		//[sed s/t// test1.txt  ] -> [t/]
		//System.out.println("1");
		//System.out.println(args);
		return matchAndReplace(regex,replacement,true);
	}
	@Override
	public String replaceAllSubstringsInFile(String args) {
		//[sed s/t/T/g test1.txt] -> [t/T]
		//[sed s/t//g test1.txt ] -> [t/]
		//System.out.println("2");
		//System.out.println(args);
		return matchAndReplace(regex,replacement,false);
	}
	@Override
	public String replaceFirstSubStringFromStdin(String args) {
		//System.out.println("3");
		//System.out.println(args);
		return matchAndReplace(regex,replacement,true);
	}
	@Override
	public String replaceAllSubstringsInStdin(String args) {
		//System.out.println("4");
		//System.out.println(args);
		return matchAndReplace(regex,replacement,false);
	}
	private void checkOnlyOneSlash(String args) throws SedException {
		int count = args.length() - args.replace(currSymbol, "").length();
		if(count>1){
			throw new SedException("Invalid Replacement");	
		}
	}
	private void checkRegex(String regex) {
		if(regex.contains(currSymbol))
		{
			replaceSubstringWithInvalidRegex(currSymbol);
		}
	}
	private void checkReplacement(String replacement) {
		if(replacement.contains(currSymbol))
		{
			replaceSubstringWithInvalidReplacement(currSymbol);
		}
	}
	@Override
	public String replaceSubstringWithInvalidReplacement(String args) {
		try {
			throw new SedException("Invalid Replacement, contains: " + args);
		} catch (SedException e) {
			System.out.println("not catching exception");
		}
		return null;

	}
	@Override
	public String replaceSubstringWithInvalidRegex(String args) {
		try {
			throw new SedException("Invalid Regex, contains: " + args);
		} catch (SedException e) {
			System.out.println("not catching exception");
		}
		return null;

	}
	private boolean checkEndSlash(String args) throws SedException {
		
		if(args.length()<1){
			throw new SedException("Invalid sed command");
		}
		if(args.substring(args.length()-1,args.length()).equals(currSymbol)==false){
			return false;
		}		
		else{
			return true;
		}
		
	}
	private boolean checkEndSlashG(String args) throws SedException {
		if(args.length()<2){
			throw new SedException("Invalid sed command");
		}
		if(args.substring(args.length()-2,args.length()).equals(currSymbol+"g")==false){
			return false;
		}		
		else{
			return true;
		}
	}
	private boolean checkS(String args) throws SedException {
		if(args.length()==2)
		{
			throw new SedException("Invalid sed command");
		}
		if( args.substring(0,2).equals("s"+currSymbol)==false)
		{
			throw new SedException("Invalid s'separating symbol' not Found");
		}		
		else
		{
			return true;
		}
	}
	private String extractCurrSymbol(String args) {

		String currSymbol=null;
		if(args.length()>2)
		{
			currSymbol = args.substring(1,2);
		}
		else
		{
			try {
				throw new SedException("Wrong replacement symbol");
			} catch (SedException e) {}
		}
		return currSymbol;

		
	}
	private File checkTextFileExistence(String fileName) throws SedException  {
		//sed s/t/T/g ~/desktop/development/test1.txt
		
		Path filePath;
		String tempFileName = fileName;
		if(tempFileName.length()>1 && tempFileName.substring(0,1).equals("~"))
		{
			String root = System.getProperty("user.home");
			tempFileName = root + tempFileName.substring(1);
		}
		try {
			Path currentDir = Paths.get(Environment.currentDirectory);
			filePath = currentDir.resolve(tempFileName);
		} catch (Exception exFile) {
            throw new SedException("Invalid file path");
        }
		File newFile = filePath.toFile();		
		if(newFile.exists()==false)
		{
            throw new SedException("can't read " + newFile.getName() + ": No such file or directory");
		}
		if(!Files.isExecutable(newFile.toPath())) {
			throw new SedException("Permission: No such file or directory.");
		}
		if (Files.isDirectory(newFile.toPath())) {
			throw new SedException("This is a directory");
		}	   
		return newFile;
	}
	private String readFromStream(InputStream in) throws IOException
	{
	    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
	    StringBuilder out = new StringBuilder();
	    String newLine = System.getProperty("line.separator");
	    String line;
	    while ((line = reader.readLine()) != null) {
	        out.append(line);
	        out.append(newLine);
	    }
	    reader.close();
	    return out.toString();
	}
	private String readFromFile(File file) throws IOException, SedException {
		 
		StringBuilder fileContents = new StringBuilder((int)file.length());
	    Scanner scanner = new Scanner(file);
	    String lineSeparator = System.getProperty("line.separator");
	    ArrayList<String> list = new ArrayList<String>();
	    try {
	        while(scanner.hasNextLine()) {
	        	list.add(scanner.nextLine());
	        }
	        for(int x=0;x<list.size();x++)
	        {
	        	if(x<list.size()-1){
		        	fileContents.append(list.get(x)+lineSeparator);
	        	}
	        	else
	        	{
		        	fileContents.append(list.get(x));

	        	}
	        }
	        //System.out.println(fileContents.toString());
	        return fileContents.toString();
	    }
	    finally {
	        scanner.close();
	    }
	}
}