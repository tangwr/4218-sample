package sg.edu.nus.comp.cs4218.impl.app;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.exception.CdException;

public class CdApplication implements Application {

	static final String TILDE = "~";
	static final String DOT = ".";
	static final String FILE_SEPARATOR = System.getProperty("file.separator"); // \
	static final String DOUBLE_FILE_SEPARATOR = FILE_SEPARATOR+FILE_SEPARATOR; // \\
	static final String SLASH = "/"; // /

	public CdApplication() {
	}
	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws CdException {
		String currRoot = Environment.currentDirectory.split(DOUBLE_FILE_SEPARATOR)[0].toLowerCase(); // obtain: c:
		String currRootWithSlash = currRoot.concat(SLASH); // obtain: c:/
		if(args.length==0){ // [cd]
			Environment.currentDirectory = Environment.homeDirectory;
		}
		else if(args.length==1){
			if(args[0].length()>0 && args[0].substring(0, 1).equals(TILDE)){ // [cd ~{} ][home directory]
				if(args[0].length()>1 && args[0].substring(1, 2).equals(SLASH)){ //[cd ~/ ][cd ~/some folder ]
					args[0]= new File(Environment.homeDirectory + args[0].substring(1)+FILE_SEPARATOR).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH);
				}
				else if(args[0].equals(TILDE)){//[cd ~ ]
					args[0]= new File(Environment.homeDirectory).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH);
				}
			}
			else if(args[0].equals(DOT)){ //[cd .][curr directory]
				args[0] = new File(Environment.currentDirectory + FILE_SEPARATOR).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH);
			}
			else if(args[0].equals(currRoot)){
				args[0] = currRootWithSlash;
			}
			checks(args);
		}
		else if(args.length>1 && args[0].length()>0 && args[0].substring(0, 1).equals(TILDE)){
			args[0]= new File(Environment.homeDirectory).getPath().replaceAll(DOUBLE_FILE_SEPARATOR, SLASH);
			checks(args);
		}
		else{
			throw new CdException("No such file or directory");
		}
	}
	private void checks(String[] args) throws CdException {
		File newFile = resolveToFile(args);
		chkExist(newFile);
		chkDir(newFile);
		chkExe(newFile);
	}
	private File resolveToFile(String[] args) throws CdException {
		Path filePath;
		File newFile = null;
		try {
			Path currentDir = Paths.get(Environment.currentDirectory);
			filePath = currentDir.resolve(args[0]);
			newFile = filePath.toFile();		
		} catch (Exception exFile) {
		       throw new CdException("No such file or directory");
		}
		return newFile;
	}
	private void chkExe(File newFile) throws CdException {
		if(!Files.isExecutable(newFile.toPath())) {
			throw new CdException("Permission: No such file or directory.");
		}
		try {
			Environment.currentDirectory = newFile.getCanonicalPath();
		} catch (IOException e) {}
	}
	private void chkDir(File newFile) throws CdException {
		if(newFile.isDirectory()==false){
		    throw new CdException("No such file or directory");
		}
	}
	private void chkExist(File newFile) throws CdException {
		if(newFile.exists()==false){
		    throw new CdException("No such file or directory");

		}
	}



}