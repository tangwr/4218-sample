package sg.edu.nus.comp.cs4218.impl.app;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.Environment;

public class PwdApplication implements Application {
	public PwdApplication() {
	}

	public String currDir;

	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) {
		currDir = Environment.currentDirectory + System.lineSeparator();

		try {

			stdout.write(currDir.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
