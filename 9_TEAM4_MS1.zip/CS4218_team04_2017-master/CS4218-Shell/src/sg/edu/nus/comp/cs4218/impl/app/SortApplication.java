package sg.edu.nus.comp.cs4218.impl.app;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.app.Sort;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;
import sg.edu.nus.comp.cs4218.exception.SedException;
import sg.edu.nus.comp.cs4218.exception.SortException;

public class SortApplication implements Sort{
	
	String contentToAppend="";
	String result="";
	ArrayList<String> listToAppend = new ArrayList<String>();
	static final String NL = System.getProperty("line.separator");
	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws AbstractApplicationException {
		//System.out.println(args[0]);
		
		if(stdin!=null && args.length==0){
			
		}
		else if(stdin!=null && args.length==1){
			
		}
		else if(stdin==null && args.length==1){
			
			/*File file = checkTextFileExistence(args[0]);
			
			try {
				contentToAppend = readFromFile(file);
			} catch (IOException e) {}
			
			Collections.sort(listToAppend);
			StringBuilder sb = new StringBuilder();
			for (int x=0;x<listToAppend.size();x++)
			{
			    sb.append(listToAppend.get(x));
			    if(x+1<listToAppend.size())
			    {
				    sb.append(NL);
			    }
			}
			result = sb.toString();
			try {
				stdout.write(result.getBytes());
			} catch (IOException e) {
			}*/

		}
		else if(stdin==null && args.length==2){
			
		}
		else if(stdin==null && args.length==1){
			
		}
		else
		{
			throw new SortException("No such command");
		}

	}



	private File checkTextFileExistence(String fileName) throws SedException, SortException  {
		String[] splitFileNames = fileName.split("/");
		File newFile=null;
		if(splitFileNames.length==1)
		{
			String currDir = Environment.currentDirectory;
			newFile = new File(currDir,splitFileNames[0]);
		}
		else if(splitFileNames.length==3 
				&& splitFileNames[0].equals("..") 
				&& splitFileNames[1].equals(new File(Environment.currentDirectory).getName().toLowerCase()))
		{
			String currDir = Environment.currentDirectory;
			newFile = new File(currDir,splitFileNames[2]);
		}
		else
		{
			throw new SortException("No such file or directory");
		}		
		if(newFile.exists()==false)
		{
			throw new SortException("No such file or directory");
		}
		return newFile;
	}
	private String readFromFile(File file) throws IOException {

	    StringBuilder fileContents = new StringBuilder((int)file.length());
	    Scanner scanner = new Scanner(file);
	    String lineSeparator = System.getProperty("line.separator");
	    ArrayList<String> list = new ArrayList<String>();
	    try {
	        while(scanner.hasNextLine()) {
	        	list.add(scanner.nextLine());
	        }
	        for(int x=0;x<list.size();x++)
	        {
	        	if(x<list.size()-1){
		        	fileContents.append(list.get(x)+lineSeparator);
	        	}
	        	else
	        	{
		        	fileContents.append(list.get(x));
	        	}
	        	listToAppend.add(list.get(x));
	        }
	        //System.out.println(fileContents.toString());
	        return fileContents.toString();
	    }
	    finally {
	        scanner.close();
	    }
	}

	@Override
	public String sortStringsSimple(String toSort) {
		

		return null;
	}

	@Override
	public String sortStringsCapital(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortNumbers(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortSpecialChars(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortSimpleCapital(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortSimpleNumbers(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortSimpleSpecialChars(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortCapitalNumbers(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortCapitalSpecialChars(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortNumbersSpecialChars(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortSimpleCapitalNumber(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortSimpleCapitalSpecialChars(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortSimpleNumbersSpecialChars(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortCapitalNumbersSpecialChars(String toSort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sortAll(String toSort) {
		
		
		return null;
		
	}

}
