package sg.edu.nus.comp.cs4218.impl.app;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import sg.edu.nus.comp.cs4218.Application;
import sg.edu.nus.comp.cs4218.Environment;
import sg.edu.nus.comp.cs4218.app.Wc;
import sg.edu.nus.comp.cs4218.exception.WcException;

public class WcApplication implements Application, Wc {
	private static final String CHAR_WHITESPACE = " ";
	private static final String CHAR_PIPE = "|";
	private static final String CHAR_HYPHEN = "-";
	private static final String CHAR_SPACE = " ";
	private static final String CHAR_TAB = "\t";
	private static final String CHAR_QUOTE = "\\\"";
	private static final String STRING_SEPARATOR = CHAR_WHITESPACE + CHAR_PIPE + CHAR_WHITESPACE;
	private static final String NEWLINE = System.getProperty("line.separator");
	private static final int NEWLINE_VALUE = 10;
	private static final int SPACE_VALUE = 32;
	private static final int CARRIAGE_RETURN_VALUE = 13;
	private static final int NO_ARGUMENTS_SPECIFIED = 0;
	private static final char OPTION_LINE_COUNT = 'l';
	private static final char OPTION_WORD_COUNT = 'w';
	private static final char OPTION_CHAR_COUNT = 'm';

	private static final String STRING_INVALID_FILE_OR_DIR = "No such file or directory";
	private static final String STRING_IS_A_DIRECTORY = "Is a directory";
	private static final String STRING_PERMISSION_DENIED = "Permission denied";
	private static final String STRING_ILLEGAL_OPTION = "illegal option";
	private static final String STRING_STANDARD_STREAMS_IS_NULL = "stdin is null | stdout is null";
	private static final String ERROR_READING = "Error reading %s";
	private static final String ERROR_PERMISSION_DENIED = "%s: open: Permission denied";
	private static final String ERROR_INVALID_FILE_OR_DIR = "%s: open: No such file or directory";
	private static final String ERROR_IS_A_DIRECTORY = "%s: read: Is a directory";
	private static final String ERROR_ILLEGAL_OPTION = "illegal option -- %s";
	private static final String ERROR_USAGE = "usage: wc [-lmw] [file ...]";
	private static final String ERROR_NULL_STDIN = "stdin is null";
	private static final String ERROR_NULL_STDOUT = "stdout is null";
	private static final String ERROR_NULL_ARGS = "args is null";

	private int lineCount;
	private int wordCount;
	private int charCount;
	private int totalLineCount;
	private int totalWordCount;
	private int totalCharCount;
	private String fileName;
	private int fileCount;

	private boolean hasLineCountOption;
	private boolean hasWordCountOption;
	private boolean hasCharCountOption;

	private String illegalOption;

	public WcApplication() {
		lineCount = 0;
		wordCount = 0;
		charCount = 0;
		totalLineCount = 0;
		totalWordCount = 0;
		totalCharCount = 0;
	}

	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws WcException {
		// TODO Auto-generated method stub

		if (hasNoArguments(args) && stdout == null) {
			// TODO consider throwing a relevant message
			throw new WcException(ERROR_NULL_STDOUT);
		}

		if (hasNoArguments(args)) {
			try {
				// TODO refactor magic number
				String output = printAllCountsInStdin(stdin, "-lwm");
				stdout.write(output.getBytes());
			} catch (IOException ioe) {
				throw new WcException(ioe.getMessage());
			}

			return;
		}

		String[] argsCopy = new String[args.length];

		for (int i = 0; i < args.length; i++) {
			argsCopy[i] = transformFileName(args[i]);
		}

		String arguments = Arrays.stream(argsCopy).collect(Collectors.joining(CHAR_WHITESPACE));

		/** print counts for stdin */
		if (isFileExistInArguments(args)) {
			try {
				String output = printAllCountsInFile(arguments);

				if (output.contains(STRING_IS_A_DIRECTORY)) {
					throw new WcException(output);
				}

				if (output.contains(STRING_INVALID_FILE_OR_DIR)) {
					throw new WcException(output);
				}
				if (output.contains(STRING_PERMISSION_DENIED)) {
					throw new WcException(output);
				}
				if (output.contains(STRING_ILLEGAL_OPTION)) {
					throw new WcException(output);
				}

				stdout.write(output.getBytes());
			} catch (IOException ioe) {
				throw new WcException(ioe.getMessage());
			}

			return;
		}

		// iterate to keep track of valid option present
		for (String arg : args) {
			if (!isOptionValid(arg)) {
				throw new WcException(String.format(ERROR_ILLEGAL_OPTION, illegalOption));
			}
		}

		try {
			processAllCountFromStdin(stdin);
			StringBuilder sb = new StringBuilder();
			if (hasLineCountOption) {
				sb.append("\t");
				sb.append(lineCount);
			}
			if (hasWordCountOption) {
				sb.append("\t");
				sb.append(wordCount);
			}
			if (hasCharCountOption) {
				sb.append("\t");
				sb.append(charCount);
			}

			String output = sb.toString();
			stdout.write(output.getBytes());
		} catch (StandardStreamsNotFoundException | IOException e) {
			throw new WcException(e.getMessage());
		}

	}

	private boolean isFileExistInArguments(String[] args) {
		boolean found = false;
		for (String arg : args) {
			if (!arg.startsWith(CHAR_HYPHEN)) {
				found = true;
				break;
			}
		}
		return found;
	}

	private String transformFileName(String arg) {
		if (arg.startsWith(CHAR_HYPHEN)) {
			return arg;
		}
		String stringInBackQuotes = "\\\"%s\\\"";
		return String.format(stringInBackQuotes, arg);
	}

	private boolean hasNoArguments(String[] args) {
		return args == null || args.length == NO_ARGUMENTS_SPECIFIED || args[0].trim().length() == 0;
	}

	private boolean hasNoStandardStreams(InputStream stdin, OutputStream stdout) {
		return stdin == null || stdout == null;
	}

	private void processAllCountFromStdin(InputStream stdin) throws StandardStreamsNotFoundException, IOException {
		// some form of assertion here
		if (stdin == null) {
			throw new StandardStreamsNotFoundException(ERROR_NULL_STDIN + STRING_SEPARATOR + ERROR_NULL_STDOUT);
		}

		resetCount();

		try (Scanner sc = new Scanner(stdin)) {
			while (sc.hasNextLine()) {
				charCount++;
				lineCount++;
				String line = sc.nextLine();
				charCount += line.length();
				wordCount += line.trim().split("\\s+").length;
				//TODO - hackish, to be fixed in next iteration
				if (!sc.hasNextLine() && lineCount>1){
					charCount--;
					lineCount--;
				}
				
//				lineCount++;
//				String line = sc.nextLine();
//				for (char c : line.toCharArray()) {
//					charCount++;
//					
//					if (c == SPACE_VALUE) {
//						wordCount++;
//					}
//				}
//				wordCount++;
			}

		}
		// try {
		// int character;
		// while ((character = stdin.read()) != -1) {
		// if (character != CARRIAGE_RETURN_VALUE) {
		// charCount++;
		// }
		//
		// if (character == SPACE_VALUE) {
		// wordCount++;
		// } else if (character == NEWLINE_VALUE) {
		// lineCount++;
		// wordCount++;
		// }
		// }
		//
		// wordCount++; // last line without a newline char
		//
		// } catch (IOException ioe) {
		// throw ioe;
		// }

	}

	private Path resolveFullPath(String arg) {
		Path currentDir = Paths.get(Environment.currentDirectory);
		Path path = currentDir.resolve(arg);
		return path;
	}

	private boolean fileNotExist(String arg) {
		Path path = resolveFullPath(arg);
		return Files.notExists(path);
	}

	private boolean isDirectory(String arg) {
		Path path = resolveFullPath(arg);
		return Files.isDirectory(path);
	}

	private boolean fileNotReadable(String arg) {
		Path path = resolveFullPath(arg);
		return !Files.isReadable(path);
	}

	@Override
	public String printNewlineCountInFile(String args) {
		String trimmed = trimWhiteSpaces(args);
		String regex = "(\\s(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)(?=(?:[^\']*\'[^\']*\')*[^\']*$))";
		String[] arguments = trimmed.split(regex);

		List<String> results = new ArrayList<>();

		// TODO refactor. use constants and String.format
		for (String arg : arguments) {

			if (arg.startsWith(CHAR_HYPHEN)) {
				if (!isOptionValid(arg)) {
					return String.format(ERROR_ILLEGAL_OPTION, illegalOption);
				}
			} else {
				try {
					processAllCountFromFile(arg);
					String result = CHAR_TAB + lineCount + CHAR_SPACE + fileName;
					results.add(result);
					fileCount++;
				} catch (FileNotExistException | FileReadErrorException | FilePermissionDeniedException
						| IOException e) {
					results.add(e.getMessage());
				}
			}
		}

		if (fileCount > 1) {
			String resultSummary = CHAR_TAB + totalLineCount + CHAR_SPACE + "total";
			results.add(resultSummary);
		}

		String result = results.stream().collect(Collectors.joining(NEWLINE));
		return result;
	}

	@Override
	public String printWordCountInFile(String args) {
		String trimmed = trimWhiteSpaces(args);
		String regex = "(\\s(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)(?=(?:[^\']*\'[^\']*\')*[^\']*$))";
		String[] arguments = trimmed.split(regex);

		List<String> results = new ArrayList<>();

		// TODO refactor. use constants and String.format
		for (String arg : arguments) {

			if (arg.startsWith(CHAR_HYPHEN)) {
				if (!isOptionValid(arg)) {
					return String.format(ERROR_ILLEGAL_OPTION, illegalOption);
				}
			} else {
				try {
					processAllCountFromFile(arg);
					String result = CHAR_TAB + wordCount + CHAR_SPACE + fileName;
					results.add(result);
					fileCount++;
				} catch (FileNotExistException | FileReadErrorException | FilePermissionDeniedException
						| IOException e) {
					results.add(e.getMessage());
				}
			}
		}

		if (fileCount > 1) {
			String resultSummary = CHAR_TAB + totalWordCount + CHAR_SPACE + "total";
			results.add(resultSummary);
		}

		String result = results.stream().collect(Collectors.joining(NEWLINE));
		return result;
	}

	@Override
	public String printCharacterCountInFile(String args) {
		String trimmed = trimWhiteSpaces(args);
		String regex = "(\\s(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)(?=(?:[^\']*\'[^\']*\')*[^\']*$))";
		String[] arguments = trimmed.split(regex);

		List<String> results = new ArrayList<>();

		// TODO refactor. use constants and String.format
		for (String arg : arguments) {

			if (arg.startsWith(CHAR_HYPHEN)) {
				if (!isOptionValid(arg)) {
					return String.format(ERROR_ILLEGAL_OPTION, illegalOption);
				}
			} else {
				try {
					processAllCountFromFile(arg);
					String result = CHAR_TAB + charCount + CHAR_SPACE + fileName;
					results.add(result);
					fileCount++;
				} catch (FileNotExistException | FileReadErrorException | FilePermissionDeniedException
						| IOException e) {
					results.add(e.getMessage());
				}
			}
		}

		if (fileCount > 1) {
			String resultSummary = CHAR_TAB + totalCharCount + CHAR_SPACE + "total";
			results.add(resultSummary);
		}

		String result = results.stream().collect(Collectors.joining(NEWLINE));
		return result;
	}

	@Override
	public String printAllCountsInFile(String args) {
		if (args == null) {
			return ERROR_NULL_ARGS;
		}

		String trimmed = trimWhiteSpaces(args);
		String regex = "(\\s(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)(?=(?:[^\']*\'[^\']*\')*[^\']*$))";
		String[] arguments = trimmed.split(regex);

		List<String> results = new ArrayList<>();

		// TODO refactor. use constants and String.format
		for (String arg : arguments) {

			if (arg.startsWith(CHAR_HYPHEN)) {
				if (!isOptionValid(arg)) {
					return String.format(ERROR_ILLEGAL_OPTION, illegalOption);
				}
			} else {
				try {
					processAllCountFromFile(arg);
					StringBuilder sb = new StringBuilder();

					if (hasLineCountOption) {
						sb.append(CHAR_TAB);
						sb.append(lineCount);
					}
					if (hasWordCountOption) {
						sb.append(CHAR_TAB);
						sb.append(wordCount);
					}
					if (hasCharCountOption) {
						sb.append(CHAR_TAB);
						sb.append(charCount);
					}
					if (!hasLineCountOption && !hasWordCountOption && !hasCharCountOption) {
						sb.append(CHAR_TAB);
						sb.append(lineCount);
						sb.append(CHAR_TAB);
						sb.append(wordCount);
						sb.append(CHAR_TAB);
						sb.append(charCount);
					}

					sb.append(CHAR_WHITESPACE + fileName);
					String result = sb.toString();
					results.add(result);
					fileCount++;
				} catch (FileNotExistException | FileReadErrorException | FilePermissionDeniedException
						| IOException e) {
					results.add(e.getMessage());
				}
			}
		}

		if (fileCount > 1) {
			String resultSummary = CHAR_TAB + totalLineCount + CHAR_TAB + totalWordCount + CHAR_TAB + totalCharCount
					+ CHAR_SPACE + "total";
			results.add(resultSummary);
		}

		String result = results.stream().collect(Collectors.joining(NEWLINE));
		fileCount = 0; // TODO will refactor this.
		return result;

	}

	@Deprecated
	@Override
	public String printNewlineCountInStdin(String args) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Alternate method for
	 * {@link sg.edu.nus.comp.cs4218.app.Wc#printNewlineCountInStdin(java.lang.String)}.
	 * 
	 * @param stdin
	 *            {@link InputStream}
	 * @param args
	 *            {@link String} containing arguments
	 */
	public String printNewlineCountInStdin(InputStream stdin, String args) {
		if (stdin == null) {
			return ERROR_NULL_STDIN;
		}

		String trimmed = trimWhiteSpaces(args);
		if (trimmed.length() < 2) {
			return null;
		}

		String[] arguments = trimmed.split("\\s+");
		for (String arg : arguments) {
			if (!isOptionValid(arg)) {
				return String.format(ERROR_ILLEGAL_OPTION, illegalOption);
			}
		}

		String result = null;
		try {
			processAllCountFromStdin(stdin);
			result = CHAR_TAB + lineCount;
		} catch (StandardStreamsNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * Alternate method for
	 * {@link sg.edu.nus.comp.cs4218.app.Wc#printWordCountInStdin(java.lang.String)}.
	 * 
	 * @param stdin
	 *            {@link InputStream}
	 * @param args
	 *            {@link String} containing arguments
	 */
	public String printWordCountInStdin(InputStream stdin, String args) {
		if (stdin == null) {
			return ERROR_NULL_STDIN;
		}
		String trimmed = trimWhiteSpaces(args);
		if (trimmed.length() < 2) {
			return null;
		}

		String[] arguments = trimmed.split("\\s+");
		for (String arg : arguments) {
			if (!isOptionValid(arg)) {
				return String.format(ERROR_ILLEGAL_OPTION, illegalOption);
			}
		}

		String result = null;
		try {
			processAllCountFromStdin(stdin);
			result = CHAR_TAB + wordCount;
		} catch (StandardStreamsNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * Alternate method for
	 * {@link sg.edu.nus.comp.cs4218.app.Wc#printCharacterCountInStdin(java.lang.String)}.
	 * 
	 * @param stdin
	 *            {@link InputStream}
	 * @param args
	 *            {@link String} containing arguments
	 */
	public String printCharacterCountInStdin(InputStream stdin, String args) {
		if (stdin == null) {
			return ERROR_NULL_STDIN;
		}
		String trimmed = trimWhiteSpaces(args);
		if (trimmed.length() < 2) {
			return null;
		}

		String[] arguments = trimmed.split("\\s+");
		for (String arg : arguments) {
			if (!isOptionValid(arg)) {
				return String.format(ERROR_ILLEGAL_OPTION, illegalOption);
			}
		}

		String result = null;
		try {
			processAllCountFromStdin(stdin);
			result = CHAR_TAB + charCount;
		} catch (StandardStreamsNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Deprecated
	@Override
	public String printWordCountInStdin(String args) {
		// TODO Auto-generated method stub
		return null;
	}

	@Deprecated
	@Override
	public String printCharacterCountInStdin(String args) {
		// TODO Auto-generated method stub
		return null;
	}

	@Deprecated
	@Override
	public String printAllCountsInStdin(String args) {
		return null;
	}

	/**
	 * Alternate method for
	 * {@link sg.edu.nus.comp.cs4218.app.Wc#printAllCountInStdin(java.lang.String)}.
	 * 
	 * @param stdin
	 *            {@link InputStream}
	 * @param args
	 *            {@link String} containing arguments
	 */
	public String printAllCountsInStdin(InputStream stdin, String args) {
		if (stdin == null) {
			return ERROR_NULL_STDIN;
		}

		String trimmed = trimWhiteSpaces(args);
		String regex = "(\\s(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)(?=(?:[^\']*\'[^\']*\')*[^\']*$))";
		String[] arguments = trimmed.split(regex);

		List<String> results = new ArrayList<>();

		if (arguments.length <= 0) {
			String result = null;
			try {
				processAllCountFromStdin(stdin);
				StringBuilder sb = new StringBuilder();

				if (hasLineCountOption) {
					sb.append(CHAR_TAB);
					sb.append(lineCount);
				}
				if (hasWordCountOption) {
					sb.append(CHAR_TAB);
					sb.append(wordCount);
				}
				if (hasCharCountOption) {
					sb.append(CHAR_TAB);
					sb.append(charCount);
				}
				if (!hasLineCountOption && !hasWordCountOption && !hasCharCountOption) {
					sb.append(CHAR_TAB);
					sb.append(lineCount);
					sb.append(CHAR_TAB);
					sb.append(wordCount);
					sb.append(CHAR_TAB);
					sb.append(charCount);
				}

				result = sb.toString();
			} catch (StandardStreamsNotFoundException | IOException e) {
				e.printStackTrace();
			}
			return result;
		}

		for (String arg : arguments) {
			if (!isOptionValid(arg)) {
				return String.format(ERROR_ILLEGAL_OPTION, illegalOption);
			}
		}

		String result = null;
		try {
			processAllCountFromStdin(stdin);
			result = CHAR_TAB + lineCount + CHAR_TAB + wordCount + CHAR_TAB + charCount;
		} catch (StandardStreamsNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	private String trimWhiteSpaces(String args) {
		String trimmed = args.trim();
		return trimmed;
	}

	private boolean isOptionValid(String arg) {

		// TODO hacky check. will improve the regex. consider using matcher
		if (arg.length() < 2) {
			illegalOption = arg;
			return false;
		}

		String validRegex = "^(-)([lwm]+)(?!-)";

		// only interested in group 2. i.e. (group1)(group2)..(groupN)
		String option = arg.replaceAll(validRegex, "$2");

		if (option.contains(CHAR_HYPHEN)) {
			String updated = arg.replaceAll(CHAR_HYPHEN, "");
			illegalOption = updated;
			return false;
		}

		// TODO refactor. this violate SRP
		// iterate every char to test validity
		for (char c : option.toCharArray()) {
			if (optionNotExist(c)) {
				illegalOption = String.valueOf(c);
				return false;
			}

			updateOptionFlags(c);
		}

		return true;
	}

	private void updateOptionFlags(char option) {
		switch (option) {

		case OPTION_LINE_COUNT:
			hasLineCountOption = true;
			break;
		case OPTION_WORD_COUNT:
			hasWordCountOption = true;
			break;
		case OPTION_CHAR_COUNT:
			hasCharCountOption = true;
			break;
		default:
			hasLineCountOption = false;
			hasWordCountOption = false;
			hasCharCountOption = false;
		}
	}

	private boolean optionNotExist(char c) {

		switch (c) {
		case OPTION_LINE_COUNT:
			return false;
		case OPTION_WORD_COUNT:
			return false;
		case OPTION_CHAR_COUNT:
			return false;
		default:
			return true;
		}

	}

	private void resetCount() {
		lineCount = 0;
		wordCount = 0;
		charCount = 0;
	}

	private void processAllCountFromFile(String filePath)
			throws FileNotExistException, FileReadErrorException, FilePermissionDeniedException, IOException {
		fileName = filePath;

		if (filePath.contains(CHAR_QUOTE)) {
			fileName = filePath.substring(2, filePath.length() - 2);
		}

		if (fileNotExist(fileName)) {
			throw new FileNotExistException(String.format(ERROR_INVALID_FILE_OR_DIR, fileName));
		}

		if (isDirectory(fileName)) {
			throw new FileReadErrorException(String.format(ERROR_IS_A_DIRECTORY, fileName));
		}

		if (fileNotReadable(fileName)) {
			throw new FilePermissionDeniedException(String.format(ERROR_PERMISSION_DENIED, fileName));
		}

		resetCount();

		Path path = resolveFullPath(fileName);
		try (BufferedReader br = Files.newBufferedReader(path)) {

			int character;
			while ((character = br.read()) != -1) {

				if (character != CARRIAGE_RETURN_VALUE) {
					charCount++;
				}

				if (character == SPACE_VALUE) {
					wordCount++;
				} else if (character == NEWLINE_VALUE) {
					lineCount++;
					wordCount++;
				}
			}

		} catch (IOException ioe) {
			throw ioe;
		}

		wordCount++; // last line without a newline char

		if (wordCount > 0 && lineCount == 0) {
			// TODO hacky. will refactor
			// update line count since the above iteration does not handle
			lineCount++;
		}

		updateTotalCount();
	}

	private void updateTotalCount() {
		totalLineCount += lineCount;
		totalWordCount += wordCount;
		totalCharCount += charCount;
	}

	class FileNotExistException extends Exception {

		/**
		 * @param message
		 */
		public FileNotExistException(String message) {
			super(message);
		}

	}

	class FileReadErrorException extends Exception {

		/**
		 * @param message
		 */
		public FileReadErrorException(String message) {
			super(message);
		}

	}

	class FilePermissionDeniedException extends Exception {

		/**
		 * @param message
		 */
		public FilePermissionDeniedException(String message) {
			super(message);
		}

	}

	class StandardStreamsNotFoundException extends Exception {

		/**
		 * @param message
		 */
		public StandardStreamsNotFoundException(String message) {
			super(message);
		}

	}

	class IllegalOptionException extends Exception {
		/**
		 * @param message
		 */
		public IllegalOptionException(String message) {
			super(message);
		}

	}

}
