package sg.edu.nus.comp.cs4218.impl.app;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import sg.edu.nus.comp.cs4218.app.Date;
import sg.edu.nus.comp.cs4218.exception.DateException;

public class DateApplication implements Date {

	private static final String NEW_LINE = System.getProperty("line.separator");
	
	public DateApplication(){}

	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws DateException {
		try {
			stdout.write(printCurrentDate("").getBytes());
		} catch (IOException e) {
			throw new DateException("IOException");
		}
	}

	@Override
	public String printCurrentDate(String args) {
		String output = "";
		java.util.Date date = new java.util.Date();
		output = date.toString() + NEW_LINE;
		return output;
	}
}
