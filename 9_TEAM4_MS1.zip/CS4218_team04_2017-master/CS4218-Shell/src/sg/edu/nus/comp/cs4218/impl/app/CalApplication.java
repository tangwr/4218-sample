package sg.edu.nus.comp.cs4218.impl.app;

import java.io.InputStream;
import java.io.OutputStream;

import sg.edu.nus.comp.cs4218.app.Cal;
import sg.edu.nus.comp.cs4218.exception.AbstractApplicationException;

public class CalApplication implements Cal {

	@Override
	public void run(String[] args, InputStream stdin, OutputStream stdout) throws AbstractApplicationException {
		// TODO Auto-generated method stub

	}

	@Override
	public String printCal(String args) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String printCalWithMondayFirst(String args) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String printCalForMonthYear(String args) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String printCalForYear(String args) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String printCalForMonthYearMondayFirst(String args) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String printCalForYearMondayFirst(String args) {
		// TODO Auto-generated method stub
		return null;
	}

}
